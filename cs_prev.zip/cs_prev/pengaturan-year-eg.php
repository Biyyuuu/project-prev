<?php
include '../koneksi.php';

$waktu_indonesia = time() + (60 * 60 * 7);
$tanggal = gmdate('Y-m-d', $waktu_indonesia);
$bulan = gmdate('m', $waktu_indonesia);
$tahun = gmdate('Y-m', $waktu_indonesia);
$tahunan = gmdate('Y', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////

if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
} else {
  $bulancari = $tahun;
}
$blnx[1] = '01';
$blnx[2] = '02';
$blnx[3] = '03';
$blnx[4] = '04';
$blnx[5] = '05';
$blnx[6] = '06';
$blnx[7] = '07';
$blnx[8] = '08';
$blnx[9] = '09';
$blnx[10] = '10';
$blnx[11] = '11';
$blnx[12] = '12';
for ($t = 13; $t <= 48; $t++) {
  $blnx[$t] = $t;
}

$blnz = substr($bulancari, 5);
$thnz = substr($bulancari, 0, 4);

$con_id = pg_query($koneksi, "SELECT COUNT(id) as jml_id FROM dbmaintenance_assy.mesin_prev ");
while ($row = pg_fetch_array($con_id)) {
  $jml_id = $row['jml_id'];
}

///////////////////////////////////////////////////////////////////////////////////////////////
$ckck = 0;
$panggil_mesin = pg_query($koneksi, "SELECT shop,line,mesin From dbmaintenance_assy.mesin_prev");
while ($row_mesin = pg_fetch_array($panggil_mesin)) {
  $ckck++;
  $shop_mesin[$ckck] = $row_mesin['shop'];
  $line_mesin[$ckck] = $row_mesin['line'];
  $mesin_mesin[$ckck] = $row_mesin['mesin'];
}
////////////////////////////////////////////////////////////////////////////////////////////////

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(id) as tot_plan FROM dbmaintenance_assy.tb_planprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan[$j] = $row['tot_plan'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_item FROM dbmaintenance_assy.tb_planprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_item[$j] = $row['tot_item'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_mesin) as tot_mesin FROM dbmaintenance_assy.tb_planprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_mesin[$j] = $row['tot_mesin'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(id) as tot_act FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act[$j] = $row['tot_act'];
  }
}

for ($k = 1; $k <= 48; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]' AND extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan[$k][$j] = $row['jml_item'];
      $periode_plan[$k][$j] = $row['periode'];
    }
  }
}

for ($k = 1; $k <= 48; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT periode,hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]' AND extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act[$k][$j] = $row['hasil'];
      $periode_act[$k][$j] = $row['periode'];
    }
  }
}

for ($k = 1; $k <= 48; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]'  ");
    while ($row = pg_fetch_array($hasili)) {
      $tot_act[$k][$j] = $row['hasil'];
    }
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
