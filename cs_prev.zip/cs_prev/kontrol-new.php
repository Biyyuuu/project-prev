<?php
include '../koneksi.php';
include 'pengaturan-new.php';
switch ($blnz) {
  case '01':
    $bln_se = 'Januari';
    break;
  case '02':
    $bln_se = 'Februari';
    break;
  case '03':
    $bln_se = 'Maret';
    break;
  case '04':
    $bln_se = 'April';
    break;
  case '05':
    $bln_se = 'Mei';
    break;
  case '06':
    $bln_se = 'Juni';
    break;
  case '07':
    $bln_se = 'Juli';
    break;
  case '08':
    $bln_se = 'Agustus';
    break;
  case '09':
    $bln_se = 'September';
    break;
  case '10':
    $bln_se = 'Oktober';
    break;
  case '11':
    $bln_se = 'November';
    break;
  case '12':
    $bln_se = 'Desember';
    break;
}
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Kontrol Preventive</title>
  <link rel="stylesheet" href="fix/bulma-with-sticky-table.css">
</head>
<style type="text/css">
  .tableFixHead {
    overflow-y: auto;
    height: 77%;
  }

  .col-id-no {
    position: sticky;
  }

  .col-first-name {
    left: 0;
    position: sticky;
  }
  .col-plan-cok {
    left: 80px;
    position: sticky;
  }

  .fixed-header {
    position: sticky;
    top: 0;
    background-color: green;
    color: white;
    z-index: 100;
    white-space: nowrap;
    min-width: 100px;
  }

  table {
    border-collapse: separate;
    width: 5%;

  }

  td {
    padding: 0;
    outline: 1px solid #ccc;
    border: none;
    outline-offset: -1px;
    padding-left: 5px;
  }

  th {
    background: #ffffff;
    padding: 0;
    outline: 1px solid #ccc;
    border: none;
    outline-offset: -1px;
    padding-left: 5px;
    position: sticky;
  }
  .footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 1000px;
    background: #6cf;
  }

</style>

<body>
  <div class="wrapper theme-1-active pimary-color-blue">
    <div class="row">
      <div class="col-sm-12">
        <div class="panel panel-default card-view">
          <div class="panel-heading">
            <div class="panel-wrapper collapse in">
              <div class="panel-body">
                <div class="table-wrap">
                  <h1 style="text-align:center; font-size: x-large;">KALENDER CONTROL KERJA PREVENTIVE MAINTENANCE ASSY YIMM-WJ FACTORY</h1>
                  <h3 style="text-align:center;  font-size: x-large;"><?= $shop_assy ?> Line <?= $line_assy ?></h3>
                  <h5 style="text-align:center;  font-size: x-large;">(<?= $thnz ?>)</h5>
                  <div id="cari">
                    <form method="post">
                      <td>Tahun : </td>
                      <select name="cari">
                        <?php
                        if($thnz !== NULL){
                          $thnzo = $thnz; 
                        }else{
                          $thnzo = 'Pilih Tahun..';
                        }
                        ?>
                        <option value=""><?=$thnzo?></option>
                        <option value="<?=$tahun3?>"><?=$tahun3?></option>
                        <option value="<?=$tahun2?>"><?=$tahun2?></option>
                        <option value="<?=$tahun1?>"><?=$tahun1?></option>
                        <option value="<?=$tahunan?>"><?=$tahunan?></option>
                        <option value="<?=$tahun11?>"><?=$tahun11?></option>
                        <option value="<?=$tahun12?>"><?=$tahun12?></option>
                      </select>
                      <input type="submit" value="Cari">
                    </form>
                  </div>
                  <div class="table-wrap mt-1" style="margin-top:100px;">
                    <div class="table-responsive">
                      <div class="tableFixHead">
                        <table style="position: absolute;top: 15%;right: 1%;border: 1px solid #000; font-weight:bold; ">
                          <td style="text-align:center; color: white; background-color:blue;">1 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:LawnGreen;">3 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:orange; ">6 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:cyan;">1 Tahunan</td>
                        </table>
                        <table class="table is-striped is-bordered is-narrow is-hoverable is-fullwidth has-sticky-header has-sticky-footer has-sticky-column" id="demo-table">
                          <thead>
                            <tr>
                              <th rowspan="2" style="text-align: center; width:5px; height:1px;background-color:green; color:white; position:relative;">No</th>
                              <th rowspan="2" style="text-align: center; position:relative; width:5px; height:1px;background-color:green; color:white;">LINE</th>
                              <th rowspan="2" style="text-align: center; position:relative; width:5px; height:1px;background-color:green; color:white; ">SPESIFIK MESIN</th>
                              <th rowspan="2" style="text-align: center; width:1px; height:1px; background-color:green; position:relative; color:white;">JML MESIN</th>
                              <th rowspan="2" style="text-align: center; width:5px; height:1px;background-color:green; position:relative;color:white;">JML ITEM </th>
                              <th rowspan="2" style="text-align: center; width:5px; height:1px;background-color:green;  position:relative;color:white;">SHOP/LINE</th>
                              <th rowspan="1" style="text-align: center; position:relative; width:5px; height:1px;background-color:green; color:white;">PLAN</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Jan</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Feb</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Mar</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Apr</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Mei</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Jun</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Jul</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Ags</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Sep</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Okt</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Nov</th>
                              <th colspan="5" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Des</th>
                              <th rowspan="2" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Total</th>
                            </tr>
                            <tr>
                              <th colspan="1" style="text-align: center; position:relative; width:5px; height:1px;background-color:green; color:white;">ACTUAL</th>
                              <?php
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?></th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?></th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?></th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?></th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?></th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              for ($xi = 1; $xi <= 5; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; width:10px; height:10px; background-color:rgba(39, 166, 245, 0.8); color:black; top:5%;"><?= $xi ?> </th>
                              <?php
                              }
                              ?>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $z = 1;
                            $tahun_cari;
                            for ($i = 1; $i <= $jml_id; $i++) {
                            ?>

                              <tr>
                                <td rowspan="2" align="center" style="font-weight:bold;"><?= $z++ ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $line_mesin[$i]; ?></td>
                                <td rowspan="2" align="center" class="col-first-name" style="text-align: left; vertical-align: middle; font-weight:bold; background-color:white"><?= $mesin_mesin[$i]; ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $tot_mesin[$i]; ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $tot_item[$i]; ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $shop_mesin[$i]; ?></td>
                                <td align="center" class="col-id-no" style="left:140px; vertical-align: middle; font-weight:bold; background-color:white;">PLAN</td><!------// PLAN  //------->

                                <?php
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_jan[$x][$i] == '1M') {
                                    $coloring_jan[$x][$i] = 'blue';
                                    $line_plan_jan[$x][$i] = $line_plan_jan[$x][$i];
                                    $fontnya_jan[$x][$i] = 'white';
                                  } elseif ($periode_plan_jan[$x][$i] == '3M') {
                                    $coloring_jan[$x][$i] = 'LawnGreen';
                                    $line_plan_jan[$x][$i] = $line_plan_jan[$x][$i];
                                    $fontnya_jan[$x][$i] = 'black';
                                  } elseif ($periode_plan_jan[$x][$i] == '6M') {
                                    $line_plan_jan[$x][$i] = $line_plan_jan[$x][$i];
                                    $coloring_jan[$x][$i] = 'orange';
                                    $fontnya_jan[$x][$i] = 'black';
                                  } elseif ($periode_plan_jan[$x][$i] == '1Y') {
                                    $coloring_jan[$x][$i] = 'cyan';
                                    $line_plan_jan[$x][$i] = $line_plan_jan[$x][$i];
                                    $fontnya_jan[$x][$i] = 'black';
                                  } else {
                                    $line_plan_jan[$x][$i] = '';
                                  }
                                ?>
                                  <td style=" background-color:<?= $coloring_jan[$x][$i] ?>; "><a style="color:<?= $fontnya_jan[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>&tanggal=<?= $buatget ?>"><?= $line_plan_jan[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_feb[$x][$i] == '1M') {
                                    $coloring_feb[$x][$i] = 'blue';
                                    $fontnya_feb[$x][$i] = 'white';
                                    $line_plan_feb[$x][$i] = $line_plan_feb[$x][$i];
                                  } elseif ($periode_plan_feb[$x][$i] == '3M') {
                                    $coloring_feb[$x][$i] = 'LawnGreen';
                                    $line_plan_feb[$x][$i] = $line_plan_feb[$x][$i];
                                    $fontnya_feb[$x][$i] = 'black';
                                  } elseif ($periode_plan_feb[$x][$i] == '6M') {
                                    $line_plan_feb[$x][$i] = $line_plan_feb[$x][$i];
                                    $coloring_feb[$x][$i] = 'orange';
                                    $fontnya_feb[$x][$i] = 'black';
                                  } elseif ($periode_plan_feb[$x][$i] == '1Y') {
                                    $coloring_feb[$x][$i] = 'cyan';
                                    $line_plan_feb[$x][$i] = $line_plan_feb[$x][$i];
                                    $fontnya_feb[$x][$i] = 'black';
                                  } else {
                                    $line_plan_feb[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_feb[$x][$i] ?>;"><a style="color:<?= $fontnya_feb[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_feb[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_mar[$x][$i] == '1M') {
                                    $coloring_mar[$x][$i] = 'blue';
                                    $line_plan_mar[$x][$i] = $line_plan_mar[$x][$i];
                                    $fontnya_mar[$x][$i] = 'white';
                                  } elseif ($periode_plan_mar[$x][$i] == '3M') {
                                    $coloring_mar[$x][$i] = 'LawnGreen';
                                    $line_plan_mar[$x][$i] = $line_plan_mar[$x][$i];
                                    $fontnya_mar[$x][$i] = 'black';
                                  } elseif ($periode_plan_mar[$x][$i] == '6M') {
                                    $coloring_mar[$x][$i] = 'orange';
                                    $line_plan_mar[$x][$i] = $line_plan_mar[$x][$i];
                                    $fontnya_mar[$x][$i] = 'black';
                                  } elseif ($periode_plan_mar[$x][$i] == '1Y') {
                                    $coloring_mar[$x][$i] = 'cyan';
                                    $line_plan_mar[$x][$i] = $line_plan_mar[$x][$i];
                                    $fontnya_mar[$x][$i] = 'black';
                                  } else {
                                    $line_plan_mar[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_mar[$x][$i] ?>;"><a style="color:<?= $fontnya_mar[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_mar[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_apr[$x][$i] == '1M') {
                                    $coloring_apr[$x][$i] = 'blue';
                                    $line_plan_apr[$x][$i] = $line_plan_apr[$x][$i];
                                    $fontnya_apr[$x][$i] = 'white';
                                  } elseif ($periode_plan_apr[$x][$i] == '3M') {
                                    $coloring_apr[$x][$i] = 'LawnGreen';
                                    $line_plan_apr[$x][$i] = $line_plan_apr[$x][$i];
                                    $fontnya_apr[$x][$i] = 'black';
                                  } elseif ($periode_plan_apr[$x][$i] == '6M') {
                                    $coloring_apr[$x][$i] = 'orange';
                                    $line_plan_apr[$x][$i] = $line_plan_apr[$x][$i];
                                    $fontnya_apr[$x][$i] = 'black';
                                  } elseif ($periode_plan_apr[$x][$i] == '1Y') {
                                    $coloring_apr[$x][$i] = 'cyan';
                                    $line_plan_apr[$x][$i] = $line_plan_apr[$x][$i];
                                    $fontnya_apr[$x][$i] = 'black';
                                  } else {
                                    $line_plan_apr[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_apr[$x][$i] ?>;"><a style="color:<?= $fontnya_apr[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_apr[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_mei[$x][$i] == '1M') {
                                    $coloring_mei[$x][$i] = 'blue';
                                    $line_plan_mei[$x][$i] = $line_plan_mei[$x][$i];
                                    $fontnya_mei[$x][$i] = 'white';
                                  } elseif ($periode_plan_mei[$x][$i] == '3M') {
                                    $coloring_mei[$x][$i] = 'LawnGreen';
                                    $line_plan_mei[$x][$i] = $line_plan_mei[$x][$i];
                                    $fontnya_mei[$x][$i] = 'black';
                                  } elseif ($periode_plan_mei[$x][$i] == '6M') {
                                    $coloring_mei[$x][$i] = 'orange';
                                    $line_plan_mei[$x][$i] = $line_plan_mei[$x][$i];
                                    $fontnya_mei[$x][$i] = 'black';
                                  } elseif ($periode_plan_mei[$x][$i] == '1Y') {
                                    $coloring_mei[$x][$i] = 'cyan';
                                    $line_plan_mei[$x][$i] = $line_plan_mei[$x][$i];
                                    $fontnya_mei[$x][$i] = 'black';
                                  } else {
                                    $line_plan_mei[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_mei[$x][$i] ?>;"><a style="color:<?= $fontnya_mei[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_mei[$x][$i] ?></a></td>
                                <?php
                                }

                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_jun[$x][$i] == '1M') {
                                    $coloring_jun[$x][$i] = 'blue';
                                    $line_plan_jun[$x][$i] = $line_plan_jun[$x][$i];
                                    $fontnya_jun[$x][$i] = 'white';
                                  } elseif ($periode_plan_jun[$x][$i] == '3M') {
                                    $coloring_jun[$x][$i] = 'LawnGreen';
                                    $line_plan_jun[$x][$i] = $line_plan_jun[$x][$i];
                                    $fontnya_jun[$x][$i] = 'black';
                                  } elseif ($periode_plan_jun[$x][$i] == '6M') {
                                    $coloring_jun[$x][$i] = 'orange';
                                    $line_plan_jun[$x][$i] = $line_plan_jun[$x][$i];
                                    $fontnya_jun[$x][$i] = 'black';
                                  } elseif ($periode_plan_jun[$x][$i] == '1Y') {
                                    $coloring_jun[$x][$i] = 'cyan';
                                    $line_plan_jun[$x][$i] = $line_plan_jun[$x][$i];
                                    $fontnya_jun[$x][$i] = 'black';
                                  } else {
                                    $line_plan_jun[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_jun[$x][$i] ?>;"><a style="color:<?= $fontnya_jun[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_jun[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_jul[$x][$i] == '1M') {
                                    $coloring_jul[$x][$i] = 'blue';
                                    $line_plan_jul[$x][$i] = $line_plan_jul[$x][$i];
                                    $fontnya_jul[$x][$i] = 'white';
                                  } elseif ($periode_plan_jul[$x][$i] == '3M') {
                                    $coloring_jul[$x][$i] = 'LawnGreen';
                                    $line_plan_jul[$x][$i] = $line_plan_jul[$x][$i];
                                    $fontnya_jul[$x][$i] = 'black';
                                  } elseif ($periode_plan_jul[$x][$i] == '6M') {
                                    $coloring_jul[$x][$i] = 'orange';
                                    $line_plan_jul[$x][$i] = $line_plan_jul[$x][$i];
                                    $fontnya_jul[$x][$i] = 'black';
                                  } elseif ($periode_plan_jul[$x][$i] == '1Y') {
                                    $coloring_jul[$x][$i] = 'cyan';
                                    $line_plan_jul[$x][$i] = $line_plan_jul[$x][$i];
                                    $fontnya_jul[$x][$i] = 'black';
                                  } else {
                                    $line_plan_jul[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_jul[$x][$i] ?>;"><a style="color:<?= $fontnya_jul[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_jul[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_ags[$x][$i] == '1M') {
                                    $coloring_ags[$x][$i] = 'blue';
                                    $line_plan_ags[$x][$i] = $line_plan_ags[$x][$i];
                                    $fontnya_ags[$x][$i] = 'white';
                                  } elseif ($periode_plan_ags[$x][$i] == '3M') {
                                    $coloring_ags[$x][$i] = 'LawnGreen';
                                    $line_plan_ags[$x][$i] = $line_plan_ags[$x][$i];
                                    $fontnya_ags[$x][$i] = 'black';
                                  } elseif ($periode_plan_ags[$x][$i] == '6M') {
                                    $coloring_ags[$x][$i] = 'orange';
                                    $line_plan_ags[$x][$i] = $line_plan_ags[$x][$i];
                                    $fontnya_ags[$x][$i] = 'black';
                                  } elseif ($periode_plan_ags[$x][$i] == '1Y') {
                                    $coloring_ags[$x][$i] = 'cyan';
                                    $line_plan_ags[$x][$i] = $line_plan_ags[$x][$i];
                                    $fontnya_ags[$x][$i] = 'black';
                                  } else {
                                    $line_plan_ags[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_ags[$x][$i] ?>;"><a style="color:<?= $fontnya_ags[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_ags[$x][$i] ?></a></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_sep[$x][$i] == '1M') {
                                    $coloring_sep[$x][$i] = 'blue';
                                    $line_plan_sep[$x][$i] = $line_plan_sep[$x][$i];
                                    $fontnya_sep[$x][$i] = 'white';
                                  } elseif ($periode_plan_sep[$x][$i] == '3M') {
                                    $coloring_sep[$x][$i] = 'LawnGreen';
                                    $line_plan_sep[$x][$i] = $line_plan_sep[$x][$i];
                                    $fontnya_sep[$x][$i] = 'black';
                                  } elseif ($periode_plan_sep[$x][$i] == '6M') {
                                    $coloring_sep[$x][$i] = 'orange';
                                    $line_plan_sep[$x][$i] = $line_plan_sep[$x][$i];
                                    $fontnya_sep[$x][$i] = 'black';
                                  } elseif ($periode_plan_sep[$x][$i] == '1Y') {
                                    $coloring_sep[$x][$i] = 'cyan';
                                    $line_plan_sep[$x][$i] = $line_plan_sep[$x][$i];
                                    $fontnya_sep[$x][$i] = 'black';
                                  } else {
                                    $line_plan_sep[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_sep[$x][$i] ?>;"><a style="color:<?= $fontnya_sep[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_sep[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_okt[$x][$i] == '1M') {
                                    $coloring_okt[$x][$i] = 'blue';
                                    $line_plan_okt[$x][$i] = $line_plan_okt[$x][$i];
                                    $fontnya_okt[$x][$i] = 'white';
                                  } elseif ($periode_plan_okt[$x][$i] == '3M') {
                                    $coloring_okt[$x][$i] = 'LawnGreen';
                                    $line_plan_okt[$x][$i] = $line_plan_okt[$x][$i];
                                    $fontnya_okt[$x][$i] = 'black';
                                  } elseif ($periode_plan_okt[$x][$i] == '6M') {
                                    $coloring_okt[$x][$i] = 'orange';
                                    $line_plan_okt[$x][$i] = $line_plan_okt[$x][$i];
                                    $fontnya_okt[$x][$i] = 'black';
                                  } elseif ($periode_plan_okt[$x][$i] == '1Y') {
                                    $coloring_okt[$x][$i] = 'cyan';
                                    $line_plan_okt[$x][$i] = $line_plan_okt[$x][$i];
                                    $fontnya_okt[$x][$i] = 'black';
                                  } else {
                                    $line_plan_okt[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_okt[$x][$i] ?>;"><a style="color:<?= $fontnya_okt[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_okt[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_nov[$x][$i] == '1M') {
                                    $coloring_nov[$x][$i] = 'blue';
                                    $line_plan_nov[$x][$i] = $line_plan_nov[$x][$i];
                                    $fontnya_nov[$x][$i] = 'white';
                                  } elseif ($periode_plan_nov[$x][$i] == '3M') {
                                    $coloring_nov[$x][$i] = 'LawnGreen';
                                    $line_plan_nov[$x][$i] = $line_plan_nov[$x][$i];
                                    $fontnya_nov[$x][$i] = 'black';
                                  } elseif ($periode_plan_nov[$x][$i] == '6M') {
                                    $coloring_nov[$x][$i] = 'orange';
                                    $line_plan_nov[$x][$i] = $line_plan_nov[$x][$i];
                                    $fontnya_nov[$x][$i] = 'black';
                                  } elseif ($periode_plan_nov[$x][$i] == '1Y') {
                                    $coloring_nov[$x][$i] = 'cyan';
                                    $line_plan_nov[$x][$i] = $line_plan_nov[$x][$i];
                                    $fontnya_nov[$x][$i] = 'black';
                                  } else {
                                    $line_plan_nov[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_nov[$x][$i] ?>;"><a style="color:<?= $fontnya_nov[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_nov[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                  if ($periode_plan_des[$x][$i] == '1M') {
                                    $coloring_des[$x][$i] = 'blue';
                                    $line_plan_des[$x][$i] = $line_plan_des[$x][$i];
                                    $fontnya_des[$x][$i] = 'white';
                                  } elseif ($periode_plan_des[$x][$i] == '3M') {
                                    $coloring_des[$x][$i] = 'LawnGreen';
                                    $line_plan_des[$x][$i] = $line_plan_des[$x][$i];
                                    $fontnya_des[$x][$i] = 'black';
                                  } elseif ($periode_plan_des[$x][$i] == '6M') {
                                    $coloring_des[$x][$i] = 'orange';
                                    $line_plan_des[$x][$i] = $line_plan_des[$x][$i];
                                    $fontnya_des[$x][$i] = 'black';
                                  } elseif ($periode_plan_des[$x][$i] == '1Y') {
                                    $coloring_des[$x][$i] = 'cyan';
                                    $line_plan_des[$x][$i] = $line_plan_des[$x][$i];
                                    $fontnya_des[$x][$i] = 'black';
                                  } else {
                                    $line_plan_des[$x][$i] = '';
                                  }
                                ?>
                                  <td style="background-color:<?= $coloring_des[$x][$i] ?>;"><a style="color:<?= $fontnya_des[$x][$i] ?>;" href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=<?= $shop_assy1 ?>"><?= $line_plan_des[$x][$i] ?></td>
                                <?php
                                }
                                ?>

                                <!-- <td style="text-align: center;">IP</td> -->
                                <td rowspan="1" align="center" style="text-align: center;"><?= $tot_plan[$i] ?></td>

                              </tr>

                              <tr>

                                <td align="center" class="col-plan-cok" style="left:140px; vertical-align: middle; font-weight:bold; background-color:white;">ACTUAL </td>
                                <?php
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_jan[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_feb[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_mar[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_apr[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_mei[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_jun[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_jul[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_ags[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_sep[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_okt[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td><?= $line_act_nov[$x][$i] ?></td>
                                <?php
                                }
                                for ($x = 1; $x <= 5; $x++) {
                                ?>
                                  <td style=""><?= $line_act_des[$x][$i] ?></td>
                                <?php
                                }
                                ?>

                                <td rowspan="1" align="center" style="text-align: center;"><?= $tot_acto[$i] ?></td>
                              </tr>
                            <?php
                            }
                            ?>
                            <!-- <tfoot> -->

                            <tr>
                              <th colspan="3" rowspan="2" style="font-weight: bold; font-size:50px; position:relative;">TOTAL</th>
                              <th colspan="1" rowspan="2"><?= $tot_mesin_thn ?></th>
                              <th colspan="1" rowspan="2"><?= $tot_item_thn ?></th>
                              <th colspan="2" align="center" style="text-align: left; font-weight:bold; background-color:white; font-size:20px;position:relative;">PLAN</th>
                              <?php
                              for ($i = 1; $i <= 5; $i++) { ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_jan[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_feb[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_mar[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_apr[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_mei[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_jun[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_jul[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_ags[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_sep[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_okt[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_nov[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: red;font-weight: bolder;"><?= $tot_plan_des[$i] ?></th>
                              <?php
                              }
                              ?>
                              <th style="color: red;font-weight: bolder;font-style: italic;"><?= $tot_plan_tot ?></th>
                            </tr>

                            <tr>
                              <th align="center" colspan="2" style="text-align: left; font-weight:bold; background-color:white; font-size:20px; position:relative;">ACTUAL</th>
                              <?php
                              for ($i = 1; $i <= 5; $i++) { ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_jan[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_feb[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_mar[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_apr[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_mei[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_jun[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_jul[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_ags[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_sep[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_okt[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_nov[$i] ?></th>
                              <?php
                              }
                              for ($i = 1; $i <= 5; $i++) {
                              ?>
                                <th style="color: green;font-weight: bolder;"><?= $tot_act_des[$i] ?></th>
                              <?php
                              }
                              ?>
                              <th style="color: green;font-weight: bolder;font-style: italic;"><?= $tot_actot ?></th>
                            </tr>
                            <!-- </tfoot> -->

                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const toggleClassFn = (clickEvent) => {
        const buttonElement = clickEvent.currentTarget;
        document.getElementById("demo-table").classList.toggle(buttonElement.dataset.toggleClass);
        buttonElement.classList.toggle("is-info");
      };
      const toggleButtons = document.getElementsByClassName("toggle-button");
      for (let index = 1; index < toggleButtons.length; index += 1) {
        toggleButtons[index].addEventListener("click", toggleClassFn);
      };
    </script>

</body>


</html>