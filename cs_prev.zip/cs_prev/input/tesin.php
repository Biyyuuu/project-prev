<style>
    .freeze-table {
        border-spacing: 0;
        font-family: "Segoe UI", sans-serif, "Helvetica Neue";
        font-size: 14px;
        padding: 0;
        border: 1px solid #ccc;
    }

    thead th {
        top: 0;
        position: sticky;
        background-color: #666;
        color: #fff;
        z-index: 20;
        min-height: 30px;
        height: 30px;
        text-align: left;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    th,
    td {
        padding: 0;
        outline: 1px solid #ccc;
        border: none;
        outline-offset: -1px;
        padding-left: 5px;
    }

    tr {
        min-height: 25px;
        height: 25px;
    }

    .col-id-no {
        left: 0;
        position: sticky;
    }

    .col-first-name {
        left: 80px;
        position: sticky;
    }

    .fixed-header {
        /* z-index: 50; */
    }

    tr:nth-child(even) td [scope=row] {
        background-color: #f2f2f2;
    }

    tr:nth-child(odd) td [scope=row] {
        background-color: white;
    }
</style>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div style="width: 500px; height: 300px; overflow: auto; margin-left: 50px; border: 1px solid;">
        <table class="freeze-table" width="700px">
            <thead>
                <tr>
                    <th style="min-width: 75px; width:75px;" class="col-id-no fixed-header">Id Number</th>
                    <th style="min-width: 100px; width:100px;" class="col-first-name fixed-header">First Name</th>
                    <th style="min-width: 100px; width:100px;">Last Name</th>
                    <th style="min-width: 300px; width:300px;">Address</th>
                    <th style="min-width: 100px; width:100px;">Phone</th>
                    <th style="min-width: 75px; width:75px;">DOB</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="col-id-no" scope="row">31213131</td>
                    <td class="col-first-name" scope="row">Barry</td>
                    <td>Allen</td>
                    <td>Florida, United States of America</td>
                    <td>22111111</td>
                    <td>02-02-1983</td>
                </tr>
                <tr>
                    <td class="col-id-no" scope="row">2234324</td>
                    <td class="col-first-name" scope="row">Bruce</td>
                    <td>Banner</td>
                    <td>London, United Kingdom</td>
                    <td>11133111</td>
                    <td>14-04-1987</td>
                </tr>
                <tr>
                    <td class="col-id-no" scope="row">64646464</td>
</body>

</html>