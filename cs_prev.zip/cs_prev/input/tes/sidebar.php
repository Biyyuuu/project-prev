<div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <!-- <div class="image">
          <img src="/iotmtc/dist/img/icon.png" class="img-circle elevation-2" alt="User Image">
        </div> -->
        <div class="info">
          <a href="index.php" class="d-block">User Maintenance</a>
        </div>
      </div>
 <!--Sidebar Menu-->
 <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Absensi
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="/iotmtc/assy/absen/absen.php" class="nav-link">
                 <p>Daftar hadir</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Preventive
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/preventive/index.php" class="nav-link">
                 <p>Preventive</p>
                </a>
              </li>
          </ul>
          </li>
          
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Preventive (ASSY)
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="#" class="nav-link">
                  <p>
                  Kontrol Preventive 1 Bulanan
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=BE" class="nav-link">
                      <p>Big Engine Line F</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=bdc" class="nav-link">
                      <p>Body Assy Line C</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=bdd" class="nav-link">
                      <p>Body Assy Line D</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=bde" class="nav-link">
                      <p>Body Assy Line E</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=egg" class="nav-link">
                      <p>Engine Assy Line G</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=egl" class="nav-link">
                      <p>Engine Assy Line L</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=egc" class="nav-link">
                      <p>Engine Assy Line C</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=egd" class="nav-link">
                      <p>Engine Assy Line D</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=ege" class="nav-link">
                      <p>Engine Assy Line E</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=spoke" class="nav-link">
                      <p>Spoke Line</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=pckd" class="nav-link">
                      <p>P.CKD</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=pcbu" class="nav-link">
                      <p>P.CBU</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=lc" class="nav-link">
                      <p>LC LINE</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-bln-new?shop=gtc" class="nav-link">
                      <p>GTC Line</p>
                    </a>
                  </li>
                </ul>
              </li>
          </ul>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="#" class="nav-link">
                  <p>
                  Kontrol Preventive 1 Tahunan
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=BE" class="nav-link">
                      <p>Big Engine Line F</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=bdc" class="nav-link">
                      <p>Body Assy Line C</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=bdd" class="nav-link">
                      <p>Body Assy Line D</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=bde" class="nav-link">
                      <p>Body Assy Line E</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=egg" class="nav-link">
                      <p>Engine Assy Line G</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=egl" class="nav-link">
                      <p>Engine Assy Line L</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=egc" class="nav-link">
                      <p>Engine Assy Line C</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=egd" class="nav-link">
                      <p>Engine Assy Line D</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=ege" class="nav-link">
                      <p>Engine Assy Line E</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=spoke" class="nav-link">
                      <p>Spoke Line</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=pckd" class="nav-link">
                      <p>P.CKD</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=pcbu" class="nav-link">
                      <p>P.CBU</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=lc" class="nav-link">
                      <p>LC LINE</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/iotmtc/assy/cs_prev/kontrol-new?shop=gtc" class="nav-link">
                      <p>GTC Line</p>
                    </a>
                  </li>
                </ul>
              </li>
          </ul>
          
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Master Mesin
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/bd1/index.php" class="nav-link">
                 <p>Body Assy 1st</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/bd2/index.php" class="nav-link">
                 <p>Body Assy 2nd</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/eg1/index.php" class="nav-link">
                 <p>Engine Assy 1st</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/eg2/index.php" class="nav-link">
                 <p>Engine Assy 2nd</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/beex/index.php" class="nav-link">
                 <p>BIG Engine assy Export</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/egex/index.php" class="nav-link">
                 <p>Engine Assy Export</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/tambah_mesin/pack/index.php" class="nav-link">
                 <p>Packing</p>
                </a>
              </li>
            </ul>
             <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="" onclick="tambahMesin() " class="nav-link">
                 <p>Tambah Mesin</p>
                </a>
              </li>
            </ul>
            <script>
function tambahMesin() {
  var myWindow = window.open("/iotmtc/assy/tambah_mesin/bd1/form_tambah.php", "", "width=500,height=500");
}
</script>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Hiyari
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/form_hiyari/isi_hiyari.php" class="nav-link">
                 <p>Isi Hiyari</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/list_hiyari/index.php" class="nav-link">
                 <p>List Hiyari</p>
                </a>
              </li>
            </ul>
            </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                History Mesin
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/perbaikan_mtc_assy/index.php" class="nav-link">
                 <p>PDLP / History Mesin</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="/iotmtc/assy/temuan_abnormal_assy/index.php" class="nav-link">
                 <p>Temuan Abnormal</p>
                </a>
              </li>
              <!-- <li class="nav-item">
                <a href="/iotmtc/assy/temuan_shop/index.php" class="nav-link">
                 <p>Temuan Abnormal Shop</p>
                </a>
              </li> -->
              <li class="nav-item">
                <a href="/iotmtc/assy/preventive1_assy/index.php" class="nav-link">
                 <p>Temuan Preventive</p>
                </a>
              </li>
            </ul>
            <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-cogs"></i>
              <p>
                Spare Part
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/stok_spare/index.php" class="nav-link">
                 <p>Stok Spare Part</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="/iotmtc/assy/sparepart/index.php" class="nav-link">
                 <p>Order Spare Part Manual</p>
                </a>
              </li>
          </li>
        </ul>
        <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-cogs"></i>
              <p>
                Warehouse Assy
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/whs_assy/whs/stok_spare/index.php" class="nav-link">
                 <p>Data Spare Part</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/whs_assy/whs/data_msk/index.php" class="nav-link">
                 <p>Cek Barang Masuk</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/whs_assy/whs/data_keluar/index.php" class="nav-link">
                 <p>Cek Barang Keluar</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/assy/whs_assy/whs/order_spare/index.php" class="nav-link">
                 <p>Order Spare Part</p>
                </a>
              </li>
            </ul>
            <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="/iotmtc/login/2/logout.php" class="nav-link">
                 <p>Logout</p>
                </a>
              </li>
               
            </ul>
          </li>
      </nav>
      </div>
      <!-- /.sidebar-menu -->