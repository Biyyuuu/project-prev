 <?php
error_reporting(0);
$e = 1;

include '../../koneksi.php';
$data31 = $_POST['shop'];
$data1 = $_POST['line'];
$data5 = $_POST['pic_prev'];

 $jml = pg_query($koneksi,"SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.mesin_prev where shop = '$data31' AND line = '$data1' ");
 while ($row = pg_fetch_array($jml)) {
  $jumlah_satu_month = $row['jumlah_satu_month'];
 }

 $itung=0;
 $panggil_db = pg_query($koneksi,"SELECT * FROM dbmaintenance_assy.mesin_prev where shop = '$data31' AND line = '$data1' ");
 while ($row = pg_fetch_array($panggil_db)) {
  $itung++;
  $bagian[$itung] = $row['bagian'];
  $line[$itung] = $row['line'];
  $mesin[$itung] = $row['mesin'];
  $jml_mesin[$itung] = $row['jml_mesin'];
  $jml_item[$itung] = $row['jml_item'];
 }

 ?>
  <!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>dashboard - maintenance Smart factory</title>
  <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <div class="row">
        <div class="col-md-12">
      <div class="alert alert-info" role="alert">
          <i class="fas fa-edit"></i> Input Data Preventive
      </div>
      <form method="post" method="get">
      <div class="card">
          <div class="card-body">
            <form class="needs-validation"  method="post" enctype="multipart/form-data" novalidate>

      <label>Shop</label>
      <td>
        <select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
          <option value="<?=  $data31 ?>"><?=  $data31 ?></option>
          <?php 
          $sql2 = pg_query($koneksi, "SELECT shop FROM dbmaintenance_assy.mesin_prev group by shop");
                  while ($data = pg_fetch_array($sql2)) {
                  $code_shop = $data['shop']; ?>
                  <option value="<?=  $code_shop ?>"><?php echo $data['shop'] ?></option>

              <?php }  ?>
        </select>
      <div class="invalid-feedback">Mesin tidak boleh kosong.</div>

      <label>Line</label>
      <td>
        <select name="line" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
          <option value="<?=  $data1 ?>"><?=  $data1 ?></option>
          <?php 
          $sql2 = pg_query($koneksi, "SELECT line FROM dbmaintenance_assy.mesin_prev where shop = '$data31' group by line");
                  while ($data = pg_fetch_array($sql2)) {
                  $linein = $data['line']; ?>
                  <option value="<?=  $linein ?>"><?= $linein ?></option>

              <?php }  ?>
        </select>
      <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
        
      <label>Pic</label>
            <select name="pic_prev" class="form-control">
              <option value="<?=  $data5 ?>"><?=  $data5 ?></option>
                <?php 
                  $pic = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' AND jabatan = 'Leader' ");
                        while ($ddd = pg_fetch_array($pic)) {
                        $nama = $ddd['nama']; ?>
              <option value="<?=  $nama ?>"><?php echo $ddd['nama'] ?></option>
                <?php }  ?>
          </select>

         <br/>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class="no" style="width: 1%; text-align: center;">No</th>
                  <th class="item" style="width: 5%; text-align: center;">Shop / Line</th>
                  <th class="item" style="width: 1%; text-align: center;">Line</th>
                  <th class="jud" style="width: 5%; text-align: center;">Mesin</th>
                  <th class="jud" style="width: 3%; text-align: center;">Jumlah Mesin</th>
                  <th class="jud" style="width: 1%; text-align: center;">Tgl Plan 1M</th>
                  <th class="jud" style="width: 3%; text-align: center;">Jml Plan 1M</th>
                  <th class="jud" style="width: 1%; text-align: center;">Tgl Plan 3M</th>
                  <th class="jud" style="width: 3%; text-align: center;">Jml Plan 3M</th>
                  <th class="jud" style="width: 1%; text-align: center;">Tgl Plan 6M</th>
                  <th class="jud" style="width: 3%; text-align: center;">Jml Plan 6M</th>
                  <th class="jud" style="width: 1%; text-align: center;">Tgl Plan 1Y</th>
                  <th class="jud" style="width: 3%; text-align: center;">Jml Plan 1Y</th>
                </tr>
                </thead>
                <tbody>
              <?php
                $z=1;
                $ko = $z++;
                for($x=1;$x<=$jumlah_satu_month;$x++){
              ?>
<tr>
      <td>
          <input type="text" class="form-control" name="noi<?= $x ?>" value="<?= $nok[$x] ?>" hidden=""><?= $e++ ?>
      </td>
      <td align="center" style="text-align: left;">
        <input type="text" name="bagianin<?= $x ?>" value="<?= $bagian[$x] ?>" hidden=""><?= $bagian[$x] ?>
      </td>
      <td align="center" style="text-align: left;">
        <input type="text" name="linein<?= $x ?>" value="<?= $line[$x] ?>" hidden=""><?= $line[$x] ?>
      </td>
      <td align="center" style="text-align: left;">
        <input type="text" name="mesinin<?= $x ?>" value="<?= $mesin[$x] ?>" hidden=""><?= $mesin[$x] ?>
      </td>
      <td align="center" style="text-align: left;">
        <input type="text" name="jml_mesinin<?= $x ?>" value="<?= $jml_mesin[$x] ?>" hidden=""><?= $jml_mesin[$x] ?>
      </td>
      <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="tgl_1m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="number" class="form-control" name="jml_1m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="tgl_3m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="number" class="form-control" name="jml_3m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="tgl_6m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="number" class="form-control" name="jml_6m<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="tgl_1y<?= $x ?>">
      </td>
      <td align="center" style="text-align: left;">
        <input type="number" class="form-control" name="jml_1y<?= $x ?>">
      </td>
    <?php
    }
    ?>
      </tr>
        </tbody>
        </table>
         </div> 
              <div class="my-md-4 pt-md-1 border-top"> </div>
            <div class="form-group col-md-5">
              <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim"> 
              </div>
          </form>
          <?php

    if (isset($_POST['kirim'])) {
       $waktu_indonesia = time() + (60 * 60 * 7);
       $tanggal = gmdate('Y-m-d', $waktu_indonesia);
       for ($i=1;$i<=$jumlah_satu_month;$i++) {
       $bagianin[$i]    = $_POST['bagianin'.$i];
       $linein[$i]      = $_POST['linein'.$i];
       $mesinin[$i]     = $_POST['mesinin'.$i];
       $jml_mesinin[$i] = $_POST['jml_mesinin'.$i];
       $jml_item[$i]    = $_POST['jml_itemin'.$i];
       $satu_bln[$i]    = $_POST['tgl_1m'.$i];
       $tiga_bln[$i]    = $_POST['tgl_3m'.$i];
       $enam_bln[$i]    = $_POST['tgl_6m'.$i];
       $satu_thn[$i]    = $_POST['tgl_1y'.$i];
       $jml_1m[$i]    = $_POST['jml_1m'.$i];
       $jml_3m[$i]    = $_POST['jml_3m'.$i];
       $jml_6m[$i]    = $_POST['jml_6m'.$i];
       $jml_1y[$i]    = $_POST['jml_1y'.$i];
       for ($z=0; $z <= 12 ; $z++) { 
        $ambil_thn_1thn[$i] = date('Y', strtotime($satu_thn[$i]));
        //1M
       $tgl_satu_bln[$i]   = date('d', strtotime($satu_bln[$i]));
       $ambil_thn_1bln[$i] = date('Y', strtotime($satu_bln[$i]));
       
        //3M
       $tiga_bln0[$i]      = date('m', strtotime($tiga_bln[$i]));
       $tiga_bln1[$i]      = date('m', strtotime($tiga_bln[$i]. ' + 3 months'));
       $tiga_bln2[$i]      = date('m', strtotime($tiga_bln[$i]. ' + 6 months'));
       $tiga_bln3[$i]      = date('m', strtotime($tiga_bln[$i]. ' + 9 months'));
       $ambil_thn_3bln[$i] = date('Y', strtotime($tiga_bln[$i]));
       $tgl_tiga_bln[$i]   = date('d', strtotime($tiga_bln[$i]));
       ///////////////////////////////////////////////
       //6m
       $tgl_enam_bln[$i]   = date('d', strtotime($enam_bln[$i]));
       $ambil_thn_6bln[$i] = date('Y', strtotime($enam_bln[$i]));
       $enam_bln0[$i]      = date('m', strtotime($enam_bln[$i]));
       $enam_bln1[$i]      = date('m', strtotime($enam_bln[$i]. ' + 6 months'));
       ///////////////////////////////////////////////
       //1M
         $tglani[$i] = $ambil_thn_1bln[$i].'-'.$z.'-'.$tgl_satu_bln[$i];
         $minggu_thn_1bln[$i] = date("W", strtotime($tglani[$i]));
       //3M
         $blnan3[$i]  = $ambil_thn_3bln[$i].'-'.$tiga_bln0[$i].'-'.$tiga_bln0[$i].'-'.$tgl_tiga_bln[$i];
         $minggu_thn_3bln[$i] = date("W", strtotime($blnan3[$i]));
         $blnan31[$i] = $ambil_thn_3bln[$i].'-'.$tiga_bln1[$i].'-'.$tgl_tiga_bln[$i];
         $minggu_thn_3bln1[$i] = date("W", strtotime($blnan31[$i]));
         $blnan32[$i] = $ambil_thn_3bln[$i].'-'.$tiga_bln2[$i].'-'.$tgl_tiga_bln[$i];
         $minggu_thn_3bln2[$i] = date("W", strtotime($blnan32[$i]));
         $blnan33[$i] = $ambil_thn_3bln[$i].'-'.$tiga_bln3[$i].'-'.$tgl_tiga_bln[$i];
         $minggu_thn_3bln3[$i] = date("W", strtotime($blnan33[$i]));
       //6m
         $tglani6[$i]  = $ambil_thn_6bln[$i].'-'.$enam_bln0[$i].'-'.$tgl_enam_bln[$i];
         $minggu_thn_6bln1[$i] = date("W", strtotime($tglani6[$i]));
         $tglani1[$i] = $ambil_thn_6bln[$i].'-'.$enam_bln1[$i].'-'.$tgl_enam_bln[$i];  
         $minggu_thn_6bln2[$i] = date("W", strtotime($tglani1[$i]));
              
          
       $minggu_thn_1y[$i] = date("W", strtotime($satu_thn[$i]));

       //1M
       $no_check_1m[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'1M'.'-'.$tglani[$i];
       //3M
       $no_check_3m[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'3M'.'-'.$ambil_thn_3bln[$i];
       $no_check_3m1[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'3M'.'-'.$ambil_thn_3bln[$i];
       $no_check_3m2[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'3M'.'-'.$ambil_thn_3bln[$i];
       $no_check_3m3[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'3M'.'-'.$ambil_thn_3bln[$i];
       //6M
       $no_check_6m[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'6M'.'-'.$ambil_thn_6bln[$i];
       $no_check_6m1[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'6M'.'-'.$ambil_thn_6bln[$i];
       //1Y
       $no_check_1y[$i]   = $data31.'-'.$bagianin[$i].'-'.$linein[$i].'-'.$mesinin[$i].'1Y'.'-'.$ambil_thn_1thn[$i];
       ///////////////////////////////////////////////////////////////////////////////

       if($satu_bln[$i] !== NULL){
       $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_1m[$i],'$data5','1M','$tglani[$i]','$no_check_1m[$i]',$minggu_thn_1bln[$i])");
       $deletin = pg_query($koneksi,"DELETE FROM dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '1970' ");
      }if($tiga_bln[$i] !== NULL){
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_3m[$i],'$data5','3M','$blnan3[$i]','$no_check_3m[$i]',$minggu_thn_3bln[$i])");
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_3m[$i],'$data5','3M','$blnan31[$i]','$no_check_3m1[$i]',$minggu_thn_3bln1[$i])");
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_3m[$i],'$data5','3M','$blnan32[$i]','$no_check_3m2[$i]',$minggu_thn_3bln2[$i])");
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_3m[$i],'$data5','3M','$blnan33[$i]','$no_check_3m3[$i]',$minggu_thn_3bln3[$i])");
        $deletin = pg_query($koneksi,"DELETE FROM dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '1970' ");
       }if($enam_bln[$i] !== NULL){
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_6m[$i],'$data5','6M','$tglani6[$i]','$no_check_6m[$i]',$minggu_thn_6bln1[$i])");
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_6m[$i],'$data5','6M','$tglani1[$i]','$no_check_6m1[$i]',$minggu_thn_6bln2[$i])");
        $deletin = pg_query($koneksi,"DELETE FROM dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '1970' ");
       }if($satu_thn[$i] !== NULL){
        $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planing (shop,bagian,line,mesin,jml_mesin,jml_item,pic,periode,tgl_plan,no_check,week_thn) VALUES ('$data31','$bagianin[$i]','$linein[$i]','$mesinin[$i]',$jml_mesinin[$i],$jml_1y[$i],'$data5','1Y','$satu_thn[$i]','$no_check_1y[$i]',$minggu_thn_1y[$i])");
        $deletin = pg_query($koneksi,"DELETE FROM dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '1970' ");
       }
       
        //  pg_close($koneksi);
      }
    }
      
        }
        exit;
      pg_close($koneksi);
   
?>
          </div>
      </div>
        </div>
  </div>
  <div id="footer"></div>
</html>