<?php
include '../koneksi.php';
include 'pengaturan-new.php';
switch ($blnz) {
case '01':
  $bln_se = 'Januari';
  break;
case '02':
  $bln_se = 'Februari';
  break;
case '03':
  $bln_se = 'Maret';
  break;
case '04':
  $bln_se = 'April';
  break;
case '05':
  $bln_se = 'Mei';
  break;
case '06':
  $bln_se = 'Juni';
  break;
case '07':
  $bln_se = 'Juli';
  break;
case '08':
  $bln_se = 'Agustus';
  break;
 case '09':
  $bln_se = 'September';
  break;
  case '10':
  $bln_se = 'Oktober';
  break;
  case '11':
  $bln_se = 'November';
  break;
  case '12':
  $bln_se = 'Desember';
  break;   
} 
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Kontrol Preventive</title>
  <link href="/iotmtc/weld/cs_prev/dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>
<style type="text/css">
	.tableFixHead {
        overflow-y: auto;
        height: 1000px;
      }
      .tableFixHead thead th {
        position: sticky;
        top: 0;
      }
      table {
        border-collapse: separate;
        width: 100%;
      }
      
      th {
        background: #ffffff;
      }
      thead {
  position: sticky;
  top: 0;
  background: #eee;
}
      img{
      width: 17px;
      height: 17px;
    }
	.footer {
    position:absolute;
   bottom:0;
   width:100%;
   height:1000px;   /* tinggi dari footer */
   background:#6cf;
   }
</style>

<body>
      <div class="wrapper theme-1-active pimary-color-blue">
      
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                  <h1 style="text-align:center; font-size: x-large;">KALENDER CONTROL KERJA PREVENTIVE MAINTENANCE ASSY YIMM-WJ FACTORY</h1>
                  <h3 style="text-align:center;  font-size: x-large;"><?=$shop_assy?> Line <?=$line_assy?></h3>
                  <h5 style="text-align:center;  font-size: x-large;">(<?=$tahunan?>)</h5>
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
   <br/>
  <table style="float:right;margin-right:30px;font-weight: bold; width:100px; border: 1px solid #000;">
        <tr style="text-align:center;">
          <td style="text-align:center; color: white; background-color:blue;" >1 Bulanan</td>
        </tr>
        <tr style="text-align:center;">
          <td style="text-align:center; color: black; background-color:LawnGreen;" >3 Bulanan</td>
        </tr>
        <tr style="text-align:center;">
          <td style="text-align:center; color: black; background-color:orange; " >6 Bulanan</td>
        </tr>
        <tr style="text-align:center;">
          <td style="text-align:center; color: black; background-color:cyan;" >1 Tahunan</td>
        </tr>
    </table>
    <!-- <table style="float:left;margin-left:30px;font-weight: bold; width:100px; ">
    <tr>
        <td style="color: black;">PIC</td>
        <td style="color: black;">: LUCKY S.K</td>
    </tr>
    <tr>
        <td style="color: black;">SHOP</td>
        <td style="color: black;">: ASSY</td>
    </tr>
    </table> -->
</div>
<br/>
<div class="table-wrap mt-1" style="margin-top:100px;">
	<div class="table-responsive">
	<div class="tableFixHead">
<table class="table table-striped table-bordered mb-0" >
  <thead>
    <tr >
           <th rowspan="2">No</th>
           <th rowspan="2">Line</th>
           <th rowspan="2" style="text-align: center; width:10px;">SPESIFIK MESIN</th>
           <th rowspan="2" style="text-align: center; width:10px;">JML MESIN</th>
           <th rowspan="2" style="text-align: center; width:10px;">JML ITEM </th>
           <th rowspan="2" style="text-align: center; width:10px;">SHOP/LINE</th>
           <th rowspan="1" style="text-align: center; width:10px;">PLAN</th>
           <th colspan="4" style="text-align: center; width:10px;">Jan</th> 
           <th colspan="4" style="text-align: center; width:10px;">Feb</th> 
           <th colspan="4" style="text-align: center; width:10px;">Mar</th>  
           <th colspan="4" style="text-align: center; width:10px;">Apr</th> 
           <th colspan="4" style="text-align: center; width:10px;">Mei</th> 
           <th colspan="4" style="text-align: center; width:10px;">Jun</th> 
           <th colspan="4" style="text-align: center; width:10px;">Jul</th> 
           <th colspan="4" style="text-align: center; width:10px;">Ags</th> 
           <th colspan="4" style="text-align: center; width:10px;">Sep</th> 
           <th colspan="4" style="text-align: center; width:10px;">Okt</th> 
           <th colspan="4" style="text-align: center; width:10px;">Nov</th> 
           <th colspan="4" style="text-align: center; width:10px;">Des</th> 
           <th rowspan="2" style="text-align: center; width:10px;">Total</th>
    </tr>
    <tr>
    <th colspan="1" style="text-align: center;">Aktual</th>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=4;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
        </tr>
    </thead>
  <tbody>
<?php
$z=1;
echo $tahun_cari;
  for ($i=1; $i <= $jml_id ; $i++){
?>

    <tr>
      <td rowspan="2" align="center"><?= $z++ ?></td> 
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $line_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $mesin_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $tot_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $tot_item[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $shop_mesin[$i];?></a> </td> 
      
      <td align="center" style="text-align: left;"><a href="">Plan </a> </td><!------// PLAN  //------->
      
      <?php  
					for($x=1;$x<=48;$x++){
            if($periode_plan[$x][$i] == '1M'){
              $coloring[$x][$i] = 'blue';
              $fontnya[$x][$i] = 'white';
            }elseif($periode_plan[$x][$i] == '3M'){
              $coloring[$x][$i] = 'LawnGreen';
              $fontnya[$x][$i] = 'black';
            }elseif($periode_plan[$x][$i] == '6M'){
              $coloring[$x][$i] = 'orange';
              $fontnya[$x][$i] = 'black';
            }elseif($periode_plan[$x][$i] == '1Y'){
              $coloring[$x][$i] = 'cyan';
              $fontnya[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya[$x][$i]?>; background-color:<?=$coloring[$x][$i]?>;"><?=$line_plan[$x][$i]?></td>
		  <?php
			  }
			?>
      
<!-- <td style="text-align: center;">IP</td> -->
<td rowspan="1" align="center" style="text-align: center;"><?=$tot_plan[$i]?></td>

</tr>

  <tr>
    
    <td  align="center" style="text-align: left;"><a href="">Aktual</a> </td>
    <?php 
					for($x=1;$x<=48;$x++){
					?>
			<td><a href=""><?=$tot_act[$x][$i]?></td>
			<?php
			}
			?>

<td rowspan="1" align="center" style="text-align: center;"><?=$tot_acto[$i]?></td>
  </tr>
  <?php
}
?>
<tr>
			<th colspan="3" rowspan="2" style="font-weight: bold; font-size:50px;">TOTAL</th>
      <th colspan="1" rowspan="2"><?=$tot_mesin_thn?></th>
      <th colspan="1" rowspan="2"><?=$tot_item_thn?></th>
      <th colspan="2" >Plan</th>      
      <?php 
			for ($i=1; $i <= 48 ; $i++) { ?>
				<th style="color: red;font-weight: bolder;font-style: italic;"><?= $tot_plan_week[$i] ?></th>
			<?php }
			 ?>
       <th colspan="1" rowspan="2"><?=$tot_actot?></th> 
</tr>
<tr>
  <th colspan="2" rowspan="1">Aktual</th>
  <?php 
			for ($i=1; $i <= 48 ; $i++) { ?>
				<th style="color: green;font-weight: bolder;font-style: italic;"><?=$tot_act_week[$i]?></th>
			<?php }
			 ?>
</tr>
			
		</tr>
 </tbody>
       </table>
</div>
</div>
</div>
      </div>  
     </div>  
    </div>  
   </div>  
  </div>  
 </div>
 </div>
    <script src="/iotmtc/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="/iotmtc/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.min.js"></script>
  <!-- <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.css"></script> -->
  <script src="/iotmtc/weld/cs_prev/dist/js/init.js"></script>
</body>
</html>