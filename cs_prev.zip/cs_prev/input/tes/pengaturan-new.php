<?php
include '../koneksi.php';

 $waktu_indonesia = time() + (60 * 60 * 7);
 $tanggal = gmdate('Y-m-d', $waktu_indonesia);
 $bulan = gmdate('m', $waktu_indonesia);
 $tahun = gmdate('Y-m', $waktu_indonesia);
 $tahunan = gmdate('Y', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////
$shop_assy1 = $_GET['shop'];

if($shop_assy1 == 'BE'){
  $shop_assy = 'BE';
  $line_assy = 'F';
}elseif($shop_assy1 == 'bdc'){
  $shop_assy = 'Body Assy';
  $line_assy = 'C';
}elseif($shop_assy1 == 'bdd'){
  $shop_assy = 'Body Assy';
  $line_assy = 'D';
}elseif($shop_assy1 == 'bde'){
  $shop_assy = 'Body Assy';
  $line_assy = 'E';
}elseif($shop_assy1 == 'egl'){
  $shop_assy = 'Engine Assy';
  $line_assy = 'L';
}elseif($shop_assy1 == 'egg'){
  $shop_assy = 'Engine Assy';
  $line_assy = 'G';
}elseif($shop_assy1 == 'egc'){
  $shop_assy = 'Engine Assy';
  $line_assy = 'C';
}elseif($shop_assy1 == 'egd'){
  $shop_assy = 'Engine Assy';
  $line_assy = 'D';
}elseif($shop_assy1 == 'ege'){
  $shop_assy = 'Engine Assy';
  $line_assy = 'E';
}elseif($shop_assy1 == 'spok'){
  $shop_assy = 'Body Assy';
  $line_assy = 'Spoke';
}elseif($shop_assy1 == 'ckd'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CKD';
}elseif($shop_assy1 == 'cbu'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CBU';
}elseif($shop_assy1 == 'cbe'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.B/E';
}elseif($shop_assy1 == 'lc'){
  $shop_assy = 'Body Assy';
  $line_assy = 'LC LINE';
}elseif($shop_assy1 == 'gtc'){
  $shop_assy = 'Body Assy';
  $line_assy = 'GTC';
}

 if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
  }
  else{
  $bulancari = $tahun;
  }
    for($t=1; $t<=48; $t++){
      $blnx[$t] = $t;
    }

    $blnz = substr($bulancari,5);
    $thnz = substr($bulancari,0,4);

    // $con_id = pg_query($koneksi, "SELECT COUNT(id) as jumlah_id FROM dbmaintenance_assy.item_prev where bln = '$blnz' and shop = 'engine'  ");
    // while ($row = pg_fetch_array($con_id)) {
    //   $jml_id = $row['jumlah_id'];
    // }

    $con_id = pg_query($koneksi, "SELECT COUNT(id) as jml_id FROM dbmaintenance_assy.mesin_prev where shop = '$shop_assy' AND line = '$line_assy' ");
    while ($row = pg_fetch_array($con_id)) {
      $jml_id = $row['jml_id'];
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////
// $erere=0;
// $panggil_db = pg_query($koneksi,"SELECT * From dbmaintenance_assy.item_prev where bln = '$blnz' and shop = 'engine' ");
// while ($row = pg_fetch_array($panggil_db)) {
// $erere++;
// $line[$erere] = $row['line'];
// $item[$erere] = $row['item'];
// $mesin[$erere] = $row['mesin'];
// $jml_mesin[$erere] = $row['jml_mesin'];
// $jml_item[$erere] = $row['jml_item'];
// $shop[$erere] = $row['shop'];
// $pic[$erere] = $row['pic'];
// }
  ///////////////////////////////////////////////////////////////////////////////////////////////
  $ckck=0;
  $panggil_mesin = pg_query($koneksi,"SELECT shop,line,mesin From dbmaintenance_assy.mesin_prev where shop = '$shop_assy' AND line = '$line_assy' ");
  while ($row_mesin = pg_fetch_array($panggil_mesin)) {
  $ckck++;
  $shop_mesin[$ckck] = $row_mesin['shop'];
  $line_mesin[$ckck] = $row_mesin['line'];
  $mesin_mesin[$ckck] = $row_mesin['mesin'];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT count(id) as tot_plan FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan[$j] = $row['tot_plan'];
  }
}

for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT sum(jml_item) as tot_item FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_item[$j] = $row['tot_item'];
  }
}


for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT sum(jml_mesin) as tot_mesin FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_mesin[$j] = $row['tot_mesin'];
  }
}

for($j=1;$j<=48;$j++){
  $hasil = pg_query($koneksi,"SELECT sum(jml_item) as tot_plan_week FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_week[$j] = $row['tot_plan_week'];
  }
}

for($j=1;$j<=48;$j++){
  $hasil = pg_query($koneksi,"SELECT count(hasil) as tot_act_week FROM dbmaintenance_assy.tb_aktualprev WHERE week_thn = '$j' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_week[$j] = $row['tot_act_week'];
  }
}
  $hasil = pg_query($koneksi,"SELECT sum(jml_mesin) as tot_mesin_thn FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_mesin_thn = $row['tot_mesin_thn'];
  }
  $hasil = pg_query($koneksi,"SELECT sum(jml_item) as tot_item_thn FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_item_thn = $row['tot_item_thn'];
  }

for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT count(id) as tot_act FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_acto[$j] = $row['tot_act'];
  }
}

  $hasil = pg_query($koneksi,"SELECT count(id) as tot_actot FROM dbmaintenance_assy.tb_aktualprev WHERE extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_actot = $row['tot_actot'];
  }



// for ($k=1;$k <= 48; $k++){
//   for($j=1;$j<=$jml_id;$j++){
//   $hasil = pg_query($koneksi,"SELECT count(id) as tot_acti FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]'  ");
//   while ($row = pg_fetch_array($hasil)) {
//     $s[$k][$j] = $row['tot_acti'];
//   }
// }
// }

for ($k=1;$k <= 48; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasili = pg_query($koneksi,"SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasili)) {
    $line_plan[$k][$j] = $row['jml_item'];
    $periode_plan[$k][$j] = $row['periode'];
  }
}
}

for ($k=1;$k <= 48; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasili = pg_query($koneksi,"SELECT periode,hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasili)) {
    $line_act[$k][$j] = $row['hasil'];
    $periode_act[$k][$j] = $row['periode'];
  }
}
}

for ($k=1;$k <= 48; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasili = pg_query($koneksi,"SELECT hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_mesin[$j]' AND shop = '$shop_mesin[$j]' AND week_thn = '$blnx[$k]'  ");
  while ($row = pg_fetch_array($hasili)) {
    $tot_act[$k][$j] = $row['hasil'];
  }
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>
