 <?php
  error_reporting(0);
  $e = 1;

  include '../../koneksi.php';
  $data31 = $_POST['shop'];
  $data5 = $_POST['pic_prev'];
  $datab  = $_POST['bln'];

  $jml = pg_query($koneksi, "SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.item_prev where shop = '$data31' and bln = '$datab' ");
  while ($row = pg_fetch_array($jml)) {
    $jumlah_satu_month = $row['jumlah_satu_month'];
  }

  $itung = 0;
  $panggil_db = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.item_prev where shop = '$data31' and bln = '$datab' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $itung++;
    $line[$itung] = $row['line'];
    $item[$itung] = $row['item'];
    $mesin[$itung] = $row['mesin'];
    $jml_mesin[$itung] = $row['jml_mesin'];
    $jml_item[$itung] = $row['jml_item'];
    $shop[$itung] = $row['shop'];
    $periode[$itung] = $row['periode'];
    $pic[$itung] = $row['pic'];
  }
  for ($x = 1; $x <= $jumlah_satu_month; $x++) {
    $panggil_db = pg_query($koneksi, "SELECT pic1,pic2,tgl_plan FROM dbmaintenance_assy.tb_planprev where shop = '$data31' and bln = '$datab' and item = '$item[$x]' and mesin = '$mesin[$x]' and line = '$line[$x]'  ");
    while ($row = pg_fetch_array($panggil_db)) {
      $pic1_plannya[$x] = $row['pic1'];
      $pic2_plannya[$x] = $row['pic2'];
      $tgl_plannya[$x] = $row['tgl_plan'];
    }
  }


  ?>
 <!DOCTYPE html>

 <html lang="en">

 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>dashboard - maintenance Smart factory</title>
   <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
 </head>

 <body class="hold-transition sidebar-mini">
   <div class="wrapper">

     <div class="row">
       <div class="col-md-12">
         <div class="alert alert-info" role="alert">
           <i class="fas fa-edit"></i> Input Data Preventive
         </div>
         <form method="post" method="get">
           <div class="card">
             <div class="card-body">
               <form class="needs-validation" method="post" enctype="multipart/form-data" novalidate>

                 <label>Shop</label>
                 <td>
                   <select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                     <option value="<?= $data31 ?>"><?= $data31 ?></option>
                     <?php
                      $sql2 = pg_query($koneksi, "SELECT shop FROM dbmaintenance_assy.mesin_prev group by shop");
                      while ($data = pg_fetch_array($sql2)) {
                        $code_shop = $data['shop']; ?>
                       <option value="<?= $code_shop ?>"><?php echo $data['shop'] ?></option>

                     <?php }  ?>
                   </select>
                   <label>Bulan</label>
                   <select name="bln" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                     <option value="<?= $datab ?>"><?= $datab ?></option>
                     <?php
                      $viewwwww = pg_query($koneksi, "SELECT bln FROM dbmaintenance_assy.item_prev where shop = '$data31' group by bln");
                      while ($drowaaa = pg_fetch_array($viewwwww)) {
                        $bln = $drowaaa['bln']; ?>
                       <option value="<?= $bln ?>"><?php echo $drowaaa['bln'] ?></option>
                     <?php }  ?>
                   </select>

                   <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
                   <!-- <label>Tanggal</label>
        <input type="date" class="form-control" name="tgll" required=""> -->
                   <label>Pic</label>
                   <select name="pic_prev" class="form-control">
                     <option value="<?= $data5 ?>"><?= $data5 ?></option>
                     <?php
                      $pic = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' AND jabatan = 'Leader' ");
                      while ($ddd = pg_fetch_array($pic)) {
                        $nama = $ddd['nama']; ?>
                       <option value="<?= $nama ?>"><?php echo $ddd['nama'] ?></option>
                     <?php }  ?>
                   </select>

                   <br />
                   <div class="box-body">
                     <table id="example1" class="table table-bordered table-striped">
                       <thead>
                         <tr>
                           <th class="no" style="text-align: center;">No</th>
                           <th class="item" style="text-align: center;">Line</th>
                           <th class="item" style="text-align: center;">Item</th>
                           <th class="jud" style="text-align: center;">Mesin</th>
                           <th class="jud" style="width: 8%; text-align: center;">Jumlah Mesin</th>
                           <th class="jud" style="width: 8%; text-align: center;">Jumlah Item</th>
                           <th class="jud" style="text-align: center;">Shop</th>
                           <th class="jud" style="text-align: center;">Periode</th>
                           <th class="jud" style="text-align: center;">Tanggal Plan</th>
                           <th class="jud" style="width: 10%; text-align: center;">PIC 1</th>
                           <th class="jud" style="width: 10%; text-align: center;">PIC 2</th>
                         </tr>
                       </thead>
                       <tbody>
                         <?php
                          $z = 1;
                          $ko = $z++;
                          for ($x = 1; $x <= $jumlah_satu_month; $x++) {
                          ?>
                           <tr>
                             <td>
                               <input type="text" class="form-control" name="noi<?= $x ?>" value="<?= $nok[$x] ?>" hidden=""><?= $e++ ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="linein<?= $x ?>" value="<?= $line[$x] ?>" hidden=""><?= $line[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="itemin<?= $x ?>" value="<?= $item[$x] ?>" hidden=""><?= $item[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="mesinin<?= $x ?>" value="<?= $mesin[$x] ?>" hidden=""><?= $mesin[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="jml_mesinin<?= $x ?>" value="<?= $jml_mesin[$x] ?>" hidden=""><?= $jml_mesin[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="jml_itemin<?= $x ?>" value="<?= $jml_item[$x] ?>" hidden=""><?= $jml_item[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="shopin<?= $x ?>" hidden="" value="<?= $shop[$x] ?>"><?= $shop[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="periodein<?= $x ?>" hidden="" value="<?= $periode[$x] ?>"><?= $periode[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="date" class="form-control" name="planin<?= $x ?>" value="<?= $tgl_plannya[$x] ?>">
                             </td>

                             <td align="center" style="text-align: left;">
                               <select name="pic1<?= $x ?>" class="form-control">
                                 <option value="<?= $pic1_plannya[$x] ?>"><?= $pic1_plannya[$x] ?></option>
                                 <?php
                                  $pic12 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY'");
                                  while ($dddd = pg_fetch_array($pic12)) {
                                    $nama1 = $dddd['nama']; ?>
                                   <option value="<?= $nama1 ?>"><?= $nama1 ?></option>
                                 <?php }  ?>
                               </select>
                             </td>
                             <td align="center" style="text-align: left;">
                               <select name="pic2<?= $x ?>" class="form-control">
                                 <option value="<?= $pic2_plannya[$x] ?>"><?= $pic2_plannya[$x] ?></option>
                                 <option value=""></option>
                                 <?php
                                  $pic22 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY'");
                                  while ($ddd = pg_fetch_array($pic22)) {
                                    $nama2 = $ddd['nama']; ?>
                                   <option value="<?= $nama2 ?>"><?= $nama2 ?></option>
                                 <?php }  ?>
                               </select>
                             </td>
                           <?php
                          }
                            ?>
                           </tr>
                       </tbody>
                     </table>
                   </div>
                   <div class="my-md-4 pt-md-1 border-top"> </div>
                   <div class="form-group col-md-5">
                     <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim">
                   </div>
               </form>
               <?php

                if (isset($_POST['kirim'])) {
                  $waktu_indonesia = time() + (60 * 60 * 7);
                  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
                  for ($i = 1; $i <= $jumlah_satu_month; $i++) {
                    $linein[$i]      = $_POST['linein' . $i];
                    $itemin[$i]      = $_POST['itemin' . $i];
                    $mesin[$i]      = $_POST['mesinin' . $i];
                    $jml_mesinin[$i] = $_POST['jml_mesinin' . $i];
                    $jml_item[$i] = $_POST['jml_itemin' . $i];
                    $plan[$i]   = $_POST['planin' . $i];
                    $shop[$i]   = $_POST['shopin' . $i];
                    $periode[$i]  = $_POST['periodein' . $i];
                    $pic1[$i]  = $_POST['pic1' . $i];
                    $pic2[$i]  = $_POST['pic2' . $i];
                    $minggu_ke[$i] = ceil(date("j", strtotime($plan[$i])) / 7); // Menghitung minggu ke berapa dalam bulan
                    $minggu_thn[$i] = date("W", strtotime($plan[$i]));
                    $no_check[$i]    = $tanggal . '-' . $data31 . '-' . $linein[$i] . '-' . $itemin[$i] . '-' . $jml_mesinin[$i] . $datab;
                    ///////////////////////////////////////////////////////////////////////////////
                    if ($plan[$i] !== NULL) {
                      $input_prev = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.tb_planprev (shop,bln,pic_prev,pic1,pic2,line,item,mesin,jml_mesin,jml_item,periode,tgl_plan,tgl_key,no_check,week,week_thn) VALUES ('$data31','$datab','$data5','$pic1[$i]','$pic2[$i]','$linein[$i]','$itemin[$i]','$mesin[$i]','$jml_mesinin[$i]','$jml_item[$i]','$periode[$i]','$plan[$i]',NOW(),'$no_check[$i]','$minggu_ke[$i]','$minggu_thn[$i]')");

                      $cek2  = pg_query($koneksi, $input_prev);
                    } else {
                      pg_close($koneksi);
                    }
                  }
                  exit;
                }

                pg_close($koneksi);

                ?>
             </div>
           </div>
       </div>
     </div>
     <div id="footer"></div>

 </html>