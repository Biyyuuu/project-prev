 <?php
  error_reporting(0);
  $e = 1;

  include '../../koneksi.php';
  $no_check_cari = $_GET['no_check'];

  $jml = pg_query($koneksi, "SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.tb_planing where no_check = '$no_check_cari'");
  while ($row = pg_fetch_array($jml)) {
    $jumlah_satu_month = $row['jumlah_satu_month'];
  }

  $itung = 0;
  $panggil_db = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.tb_planing where no_check = '$no_check_cari' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $shop_cari = $row['shop'];
    $line_cari = $row['line'];
    $bagian = $row['bagian'];
    $mesin = $row['mesin'];
    $pic = $row['pic'];
    $jml_mesin = $row['jml_mesin'];
    $jml_item = $row['jml_item'];
    $periode = $row['periode'];
    $tgl_plan = $row['tgl_plan'];
    $no_check = $row['no_check'];
  }

  if ($shop = 'BE' and $line = 'F') {
    $shop_assy = 'BE';
  } elseif ($shop = 'Body Assy' and $line = 'C') {
    $shop_assy = 'bdc';
  } elseif ($shop = 'Body Assy' and $line = 'D') {
    $shop_assy = 'bdd';
  } elseif ($shop = 'Body Assy' and $line = 'E') {
    $shop_assy = 'bde';
  } elseif ($shop = 'Engine Assy' and $line = 'L') {
    $shop_assy = 'egl';
  } elseif ($shop = 'Engine Assy' and $line = 'G') {
    $shop_assy = 'egg';
  } elseif ($shop = 'Engine Assy' and $line = 'C') {
    $shop_assy = 'egc';
  } elseif ($shop = 'Engine Assy' and $line = 'D') {
    $shop_assy = 'egd';
  } elseif ($shop = 'Engine Assy' and $line = 'E') {
    $shop_assy = 'ege';
  } elseif ($shop = 'Body Assy' and $line = 'Spoke') {
    $shop_assy = 'spoke';
  } elseif ($shop = 'Body Assy' and $line = 'P.CKD') {
    $shop_assy = 'pckd';
  } elseif ($shop = 'Body Assy' and $line = 'P.CBU') {
    $shop_assy = 'pcbu';
  } elseif ($shop = 'Body Assy' and $line = 'P.B/E') {
    $shop_assy = 'pcbe';
  } elseif ($shop = 'Body Assy' and $line = 'LC LINE') {
    $shop_assy = 'lc';
  } elseif ($shop = 'Body Assy' and $line = 'GTC') {
    $shop_assy = 'gtc';
  }


  $blnz = substr($tgl_plan, 6, 1);
  switch ($blnz) {
    case '01':
      $bln_se = 'Januari';
      break;
    case '02':
      $bln_se = 'Februari';
      break;
    case '03':
      $bln_se = 'Maret';
      break;
    case '04':
      $bln_se = 'April';
      break;
    case '05':
      $bln_se = 'Mei';
      break;
    case '06':
      $bln_se = 'Juni';
      break;
    case '07':
      $bln_se = 'Juli';
      break;
    case '08':
      $bln_se = 'Agustus';
      break;
    case '09':
      $bln_se = 'September';
      break;
    case '10':
      $bln_se = 'Oktober';
      break;
    case '11':
      $bln_se = 'November';
      break;
    case '12':
      $bln_se = 'Desember';
      break;
  }
  if ($periode == '1M') {
    $periodeni = 'Bulanan';
  } elseif ($periode == '3M') {
    $periodeni = '3 Bulanan';
  } elseif ($periode == '6M') {
    $periodeni = '6 Bulanan';
  } elseif ($periode == '1Y') {
    $periodeni = '1 Tahunan';
  }

  ?>
 <!DOCTYPE html>

 <html lang="en">

 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>dashboard - maintenance Smart factory</title>
   <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
 </head>

 <body class="hold-transition sidebar-mini">
   <div class="wrapper">

     <div class="row">
       <div class="col-md-12">
         <div class="alert alert-info" role="alert">
           <i class="fas fa-edit"></i> Input Data Preventive
         </div>
         <form method="post" method="get">
           <div class="card">
             <div class="card-body">
               <form class="needs-validation" method="post" enctype="multipart/form-data" novalidate>

                 <label>Shop</label>
                 <td>
                   <input type="text" class="form-control" value="<?= $shop_cari ?>" readonly>

                   <label>Bulan</label>
                   <input type="text" class="form-control" value="<?= $bln_se ?>" readonly>

                   <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
                   <!-- <label>Tanggal</label>
        <input type="date" class="form-control" name="tgll" required=""> -->
                   <label>Pic</label>
                   <input type="text" class="form-control" value="<?= $pic ?>" readonly>

                   <br />
                   <div class="box-body">
                     <table id="example1" class="table table-bordered table-striped">
                       <thead>
                         <tr>
                           <th class="no">No</th>
                           <th class="item">Line</th>
                           <th class="item">Item</th>
                           <th class="jud">Mesin</th>
                           <th class="jud">Jumlah Mesin</th>
                           <th class="jud">Jumlah Item</th>
                           <th class="jud">Shop</th>
                           <th class="jud">Periode</th>
                           <th class="jud">Tanggal Plan</th>
                           <th class="jud">Tanggal Aktual</th>
                           <th class="jud">Hasil</th>
                           <!-- <th class="jud">Tanggal Preventive</th> -->
                           <!-- <th id="text" class="jud">Tanggal Preventive Bulan Ke 2</th>
                  <th id="text2" class="jud">Tanggal Preventive Bulan Ke 3</th>
                  <th id="text3" class="jud">Tanggal Preventive Bulan Ke 4</th> -->
                         </tr>
                       </thead>
                       <tbody>
                         <?php
                          $z = 1;
                          $ko = $z++;
                          ?>
                         <tr>
                           <td>
                             <input type="text" class="form-control" name="noi" value="<?= $nok ?>" hidden=""><?= $e++ ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="linein" value="<?= $line_cari ?>" hidden=""><?= $line_cari ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="itemin" value="<?= $item ?>" hidden="">Preventive <?= $periodeni ?> <?= $mesin; ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="mesinin" value="<?= $mesin ?>" hidden=""><?= $mesin ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="jml_mesinin" value="<?= $jml_mesin ?>" hidden=""><?= $jml_mesin ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="jml_itemin" hidden="" value="<?= $jml_item ?>"><?= $jml_item ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="shopin" hidden="" value="<?= $shop_cari ?>"><?= $shop_cari ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="periodein" hidden="" value="<?= $periode ?>"><?= $periodeni ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="date" class="form-control" name="tgl_planing" value="<?= $tgl_plan ?>">
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="date" class="form-control" name="aktualin">
                           </td>
                           <td>
                             <select style="width: 100px;" class="form-control" name="hasil">
                               <option value=""></option>
                               <option value="O">O</option>
                               <option value="△">△</option>
                               <option value="⇨">⇨</option>
                             </select>
                           </td>
                         </tr>
                       </tbody>
                     </table>
                   </div>
                   <div class="my-md-4 pt-md-1 border-top"> </div>
                   <div class="form-group col-md-5">
                     <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim">
                   </div>
               </form>
               <?php
                if (isset($_POST['kirim'])) {
                  $waktu_indonesia = time() + (60 * 60 * 7);
                  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
                  for ($i = 1; $i <= $jumlah_satu_month; $i++) {
                    $linein      = $_POST['linein'];
                    $mesin      = $_POST['mesinin'];
                    $jml_mesinin = $_POST['jml_mesinin'];
                    $jml_itemin = $_POST['jml_itemin'];
                    $tgl_planing = $_POST['tgl_planing'];
                    $plan   = $_POST['aktualin'];
                    $shopin   = $_POST['shopin'];
                    $hasil   = $_POST['hasil'];
                    $periode  = $_POST['periodein'];
                    $minggu_ke = ceil(date("j", strtotime($plan)) / 7); // Menghitung minggu ke berapa dalam bulan
                    $minggu_thn = date("W", strtotime($plan));
                    $no_check    = $tanggal . '-' . $shop . '-' . $line . '-' . $mesin . '-' . $bagian . '-' . $jml_mesinin;
                    ///////////////////////////////////////////////////////////////////////////////
                    if ($plan !== NULL) {
                      $input_prev = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.tb_aktualprev(shop,bln,pic_prev,line,mesin,jml_mesin,jml_item,periode,tgl_plan,tgl_key,no_check,hasil,week,week_thn,bagian) VALUES ('$shop_cari','$blnz','$pic','$line_cari','$mesin',$jml_mesin,$jml_item,'$periode','$plan','$tanggal','$no_check','$hasil','$minggu_ke','$minggu_thn','$bagian')");

                      $update = pg_query($koneksi, "UPDATE dbmaintenance_assy.tb_planing SET tgl_plan= '$tgl_planing' WHERE no_check = '$no_check_cari' ");
                      $cek2  = pg_query($koneksi, $input_prev, $update);
                      echo '<META HTTP-EQUIV="Refresh" Content="0; URL=';
                      // header("Location:/iotmtc/assy/cs_prev/kontrol-bln-new.php?shop=$shop_assy");
                    }
                    exit;
                  }
                } else {
                  pg_close($koneksi);
                }
                ?>
             </div>
           </div>
       </div>
     </div>
     <div id="footer"></div>

 </html>