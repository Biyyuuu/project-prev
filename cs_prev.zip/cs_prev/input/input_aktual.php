 <?php
  error_reporting(0);
  $e = 1;

  include '../../koneksi.php';
  $no_check_cari = $_GET['no_check'];
  $data31 = $_POST['shop'];
  $data5 = $_POST['pic'];

  $jml = pg_query($koneksi, "SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.tb_planprev where no_check = '$no_check_cari'");
  while ($row = pg_fetch_array($jml)) {
    $jumlah_satu_month = $row['jumlah_satu_month'];
  }

  $itung = 0;
  $panggil_db = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.tb_planprev where no_check = '$no_check_cari' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $itung++;
    $shop = $row['shop'];
    $bln = $row['bln'];
    $pic = $row['pic_prev'];
    $bagian = $row['bagian'];
    $pic2 = $row['pic2'];
    $pic1 = $row['pic1'];
    $line = $row['line'];
    $item = $row['item'];
    $mesin = $row['mesin'];
    $jml_mesin = $row['jml_mesin'];
    $jml_item = $row['jml_item'];
    $periode = $row['periode'];
    $tgl_plan = $row['tgl_plan'];
    $tgl_key = $row['tgl_key'];
    $no_check = $row['no_check'];
  }

  ?>
 <!DOCTYPE html>

 <html lang="en">

 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>dashboard - maintenance Smart factory</title>
   <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
 </head>

 <body class="hold-transition sidebar-mini">
   <div class="wrapper">

     <div class="row">
       <div class="col-md-12">
         <div class="alert alert-info" role="alert">
           <i class="fas fa-edit"></i> Input Data Preventive
         </div>
         <form method="post" method="get">
           <div class="card">
             <div class="card-body">
               <form class="needs-validation" method="post" enctype="multipart/form-data" novalidate>

                 <label>Shop</label>
                 <td>
                   <input type="text" class="form-control" value="<?= $shop ?>">

                   <label>Bulan</label>
                   <input type="text" class="form-control" value="<?= $bln ?>">

                   <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
                   <!-- <label>Tanggal</label>
        <input type="date" class="form-control" name="tgll" required=""> -->
                   <label>Pic</label>
                   <input type="text" class="form-control" value="<?= $pic ?>" dissabled>

                   <br />
                   <div class="box-body">
                     <table id="example1" class="table table-bordered table-striped">
                       <thead>
                         <tr>
                           <th class="no">No</th>
                           <th class="item">Line</th>
                           <th class="item">Item</th>
                           <th class="jud">Mesin</th>
                           <th class="jud">Jumlah Mesin</th>
                           <th class="jud">Jumlah Item</th>
                           <th class="jud">Shop</th>
                           <th class="jud">Periode</th>
                           <th class="jud">Tanggal Plan</th>
                           <th class="jud">Tanggal Aktual</th>
                           <th class="jud">Hasil</th>
                           <!-- <th class="jud">Tanggal Preventive</th> -->
                           <!-- <th id="text" class="jud">Tanggal Preventive Bulan Ke 2</th>
                  <th id="text2" class="jud">Tanggal Preventive Bulan Ke 3</th>
                  <th id="text3" class="jud">Tanggal Preventive Bulan Ke 4</th> -->
                         </tr>
                       </thead>
                       <tbody>
                         <?php
                          $z = 1;
                          $ko = $z++;
                          ?>
                         <tr>
                           <td>
                             <input type="text" class="form-control" name="noi" value="<?= $nok ?>" hidden=""><?= $e++ ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="linein" value="<?= $line ?>" hidden=""><?= $line ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="itemin" value="<?= $item ?>" hidden=""><?= $item ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="mesinin" value="<?= $mesin ?>" hidden=""><?= $mesin ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="jml_mesinin" value="<?= $jml_mesin ?>" hidden=""><?= $jml_mesin ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="jml_itemin" hidden="" value="<?= $jml_item ?>"><?= $jml_item ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="shopin" hidden="" value="<?= $shop ?>"><?= $shop ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="periodein" hidden="" value="<?= $periode ?>"><?= $periode ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="date" class="form-control" name="tgl_planing" value="<?= $tgl_plan ?>">
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="date" class="form-control" name="aktualin">
                           </td>
                           <td>
                             <select style="width: 100px;" class="form-control" name="hasil">
                               <option value=""></option>
                               <option value="O">O</option>
                               <option value="△">△</option>
                               <option value="⇨">⇨</option>
                             </select>
                           </td>
                         </tr>
                       </tbody>
                     </table>
                   </div>
                   <div class="my-md-4 pt-md-1 border-top"> </div>
                   <div class="form-group col-md-5">
                     <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim">
                   </div>
               </form>
               <?php
                if (isset($_POST['kirim'])) {
                  $waktu_indonesia = time() + (60 * 60 * 7);
                  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
                  for ($i = 1; $i <= $jumlah_satu_month; $i++) {
                    $linein      = $_POST['linein'];
                    $itemin      = $_POST['itemin'];
                    $mesin      = $_POST['mesinin'];
                    $jml_mesinin = $_POST['jml_mesinin'];
                    $jml_itemin = $_POST['jml_itemin'];
                    $tgl_planing = $_POST['tgl_planing'];
                    $plan   = $_POST['aktualin'];
                    $shopin   = $_POST['shopin'];
                    $hasil   = $_POST['hasil'];
                    $periode  = $_POST['periodein'];
                    $minggu_ke = ceil(date("j", strtotime($plan)) / 7); // Menghitung minggu ke berapa dalam bulan
                    $minggu_thn = date("W", strtotime($plan));
                    $no_check    = $tanggal . '-' . $data31 . '-' . $linein . '-' . $itemin . '-' . $jml_mesinin;
                    ///////////////////////////////////////////////////////////////////////////////
                    if ($plan !== NULL) {
                      $input_prev = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.tb_aktualprev(shop,bln,pic_prev,pic1,pic2,line,item,mesin,jml_mesin,jml_item,periode,tgl_plan,tgl_key,no_check,hasil,week,week_thn,bagian) VALUES ('$shop','$pic','$pic1','$pic2','$line','$item','$mesin',$jml_mesin,$jml_item,'$periode','$plan','$tanggal','$no_check','$hasil','$minggu_ke','$minggu_thn','$bagian')");

                      $update = pg_query($koneksi, "UPDATE dbmaintenance_assy.tb_planprev SET tgl_plan= '$tgl_planing' WHERE no_check = '$no_check_cari' ");
                      $cek2  = pg_query($koneksi, $input_prev, $update);
                      echo '<META HTTP-EQUIV="Refresh" Content="0; URL=/iotmtc/assy/cs_prev/1m.php">';
                    }
                    exit;
                  }
                } else {
                  pg_close($koneksi);
                }
                pg_close($koneksi);
                ?>
             </div>
           </div>
       </div>
     </div>
     <div id="footer"></div>

 </html>