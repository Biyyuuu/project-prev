 <?php
  error_reporting(0);
  $e = 1;
  $waktu_indonesia = time() + (60 * 60 * 7);
  include '../../koneksi.php';
  $no_check_cari = $_GET['no_check'];


  $data1 = $_POST['no_mesin'];
  $data2 = $_POST['cat'];
  $panggil_db = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.tb_planing where no_check = '$no_check_cari' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $shop_cari = $row['shop'];
    $line_cari = $row['line'];
    $bagian = $row['bagian'];
    $mesin = $row['mesin'];
    $pic = $row['pic'];
    $bln_cari = $row['bln'];
    $jml_mesin = $row['jml_mesin'];
    $jml_item = $row['jml_item'];
    $tgl_plan = $row['tgl_plan'];
    $no_check = $row['no_check'];
    $periodenya = $row['periode'];
    $tgl_plannyani = substr($tgl_plan, 5, 2);
    $blninnya = substr($tgl_plan, 5, 2);
    $thnnya = substr($tgl_plan, 0, 4);
  }
  if ($data1 !== NULL) {
    $jml = pg_query($koneksi, "SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.itemcs_bd where shop = '$shop_cari' AND mesin ='$mesin' AND periode = '$periodenya' ");
    while ($row = pg_fetch_array($jml)) {
      $jumlah_item1 = $row['jumlah_satu_month'];
    }
  }
  if ($data2 !== NULL) {
    $jml = pg_query($koneksi, "SELECT COUNT(id) as jumlah_satu_month FROM dbmaintenance_assy.itemcs_bd where shop = '$shop_cari' AND mesin ='$mesin' AND periode = '$periodenya' and cat = '$data2' ");
    while ($row = pg_fetch_array($jml)) {
      $jumlah_item2 = $row['jumlah_satu_month'];
    }
  }

  $itung = 0;
  if ($mesin == 'OHC') {
    $jumlah_item = $jumlah_item2;

    $panggil_db2 = pg_query($koneksi, "SELECT unit, item_check, standart, metode, periode FROM dbmaintenance_assy.itemcs_bd where mesin = '$mesin' AND periode = '$periodenya' AND shop = '$shop_cari' AND cat = '$data2' ");
    while ($row = pg_fetch_array($panggil_db2)) {

      $itung++;
      $unit[$itung] = $row['unit'];
      $item_check[$itung] = $row['item_check'];
      $standart[$itung] = $row['standart'];
      $periode[$itung] = $row['periode'];
      $metode[$itung] = $row['metode'];
      if ($periode[$itung] == '1M') {
        $periodeni[$itung] = 'Bulanan';
      } elseif ($periode[$itung] == '3M') {
        $periodeni[$itung] = '3 Bulanan';
      } elseif ($periode[$itung] == '6M') {
        $periodeni[$itung] = '6 Bulanan';
      } elseif ($periode[$itung] == '1Y') {
        $periodeni[$itung] = '1 Tahunan';
      }
    }
  } elseif ($mesin == 'ZERO OG BALANCER') {
    $jumlah_item = $jumlah_item2;
    $panggil_db2 = pg_query($koneksi, "SELECT unit, item_check, standart, metode, periode FROM dbmaintenance_assy.itemcs_bd where mesin = '$mesin' AND periode = '$periodenya' AND shop = '$shop_cari' ");
    while ($row = pg_fetch_array($panggil_db2)) {

      $itung++;
      $unit[$itung] = $row['unit'];
      $item_check[$itung] = $row['item_check'];
      $standart[$itung] = $row['standart'];
      $periode[$itung] = $row['periode'];
      $metode[$itung] = $row['metode'];
      if ($periode[$itung] == '1M') {
        $periodeni[$itung] = 'Bulanan';
      } elseif ($periode[$itung] == '3M') {
        $periodeni[$itung] = '3 Bulanan';
      } elseif ($periode[$itung] == '6M') {
        $periodeni[$itung] = '6 Bulanan';
      } elseif ($periode[$itung] == '1Y') {
        $periodeni[$itung] = '1 Tahunan';
      }
    }
  }else{
    $jumlah_item = $jumlah_item1;
    $panggil_db2 = pg_query($koneksi, "SELECT unit, item_check, standart, metode, periode FROM dbmaintenance_assy.itemcs_bd where mesin = '$mesin' AND periode = '$periodenya' AND shop = '$shop_cari' ");
    while ($row = pg_fetch_array($panggil_db2)) {

      $itung++;
      $unit[$itung] = $row['unit'];
      $item_check[$itung] = $row['item_check'];
      $standart[$itung] = $row['standart'];
      $periode[$itung] = $row['periode'];
      $metode[$itung] = $row['metode'];
      if ($periode[$itung] == '1M') {
        $periodeni[$itung] = 'Bulanan';
      } elseif ($periode[$itung] == '3M') {
        $periodeni[$itung] = '3 Bulanan';
      } elseif ($periode[$itung] == '6M') {
        $periodeni[$itung] = '6 Bulanan';
      } elseif ($periode[$itung] == '1Y') {
        $periodeni[$itung] = '1 Tahunan';
      }
    }
  }
  $panggil_db = pg_query($koneksi, "SELECT tanggal FROM dbmaintenance_assy.aktual_cs where shop = '$shop_cari' AND mesin ='$mesin' AND periode = '$periodenya' AND no_mesin = '$data1' AND extract(month from tanggal) = '$blninnya' AND extract(year from tanggal) = '$thnnya' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $tgl_aktualbos = $row['tanggal'];
  }

  for ($zi = 1; $zi <= $jumlah_item; $zi++) {
    $panggil_db1 = pg_query($koneksi, "SELECT hasil,ket_sblm FROM dbmaintenance_assy.aktual_cs where unit = '$unit[$zi]' AND item_check = '$item_check[$zi]' AND standart = '$standart[$zi]' AND metode = '$metode[$zi]' AND periode = '$periodenya' AND shop = '$shop_cari' AND mesin ='$mesin' AND line = '$line_cari' AND no_mesin = '$data1' AND extract(month from tanggal) = '$blninnya' AND extract(year from tanggal) = '$thnnya' ");
    while ($row = pg_fetch_array($panggil_db1)) {
      $hasilin[$zi] = $row['hasil'];
      $ketin[$zi] = $row['ket_sblm'];
    }
  }

  if ($shop = 'BE' and $line = 'F') {
    $shop_assy = 'BE';
  } elseif ($shop = 'Body Assy' and $line = 'C') {
    $shop_assy = 'bdc';
  } elseif ($shop = 'Body Assy' and $line = 'D') {
    $shop_assy = 'bdd';
  } elseif ($shop = 'Body Assy' and $line = 'E') {
    $shop_assy = 'bde';
  } elseif ($shop = 'Engine Assy' and $line = 'L') {
    $shop_assy = 'egl';
  } elseif ($shop = 'Engine Assy' and $line = 'G') {
    $shop_assy = 'egg';
  } elseif ($shop = 'Engine Assy' and $line = 'C') {
    $shop_assy = 'egc';
  } elseif ($shop = 'Engine Assy' and $line = 'D') {
    $shop_assy = 'egd';
  } elseif ($shop = 'Engine Assy' and $line = 'E') {
    $shop_assy = 'ege';
  } elseif ($shop = 'Body Assy' and $line = 'Spoke') {
    $shop_assy = 'spoke';
  } elseif ($shop = 'Body Assy' and $line = 'P.CKD') {
    $shop_assy = 'pckd';
  } elseif ($shop = 'Body Assy' and $line = 'P.CBU') {
    $shop_assy = 'pcbu';
  } elseif ($shop = 'Body Assy' and $line = 'P.B/E') {
    $shop_assy = 'pcbe';
  } elseif ($shop = 'Body Assy' and $line = 'LC LINE') {
    $shop_assy = 'lc';
  } elseif ($shop = 'Body Assy' and $line = 'GTC') {
    $shop_assy = 'gtc';
  }


  $blnz = substr($tgl_plan, 5, 2);
  switch ($blnz) {
    case '01':
      $bln_se = 'Januari';
      break;
    case '02':
      $bln_se = 'Februari';
      break;
    case '03':
      $bln_se = 'Maret';
      break;
    case '04':
      $bln_se = 'April';
      break;
    case '05':
      $bln_se = 'Mei';
      break;
    case '06':
      $bln_se = 'Juni';
      break;
    case '07':
      $bln_se = 'Juli';
      break;
    case '08':
      $bln_se = 'Agustus';
      break;
    case '09':
      $bln_se = 'September';
      break;
    case '10':
      $bln_se = 'Oktober';
      break;
    case '11':
      $bln_se = 'November';
      break;
    case '12':
      $bln_se = 'Desember';
      break;
  }


  ?>
 <!DOCTYPE html>

 <html lang="en">

 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>dashboard - maintenance Smart factory</title>
   <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
 </head>

 <body class="hold-transition sidebar-mini">
   <div class="wrapper">

     <div class="row">
       <div class="col-md-12">
         <div class="alert alert-info" role="alert">
           <i class="fas fa-edit"></i> Input Data Preventive
         </div>
         <form method="post" method="get">
           <div class="card">
             <div class="card-body">
               <form class="needs-validation" method="post" enctype="multipart/form-data" novalidate>
                 <div class="row g-1">
                   <div class="col-md-2">
                     <label>Shop</label>
                     <td>
                       <input type="text" class="form-control" value="<?= $shop_cari ?>" readonly>
                   </div>
                   <div class="col-md-2">
                     <label>Bulan</label>
                     <input type="text" class="form-control" value="<?= $bln_se ?>" readonly>

                     <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
                   </div>
                   <div class="col-md-2">
                     <label>Pic</label>
                     <input type="text" class="form-control" value="<?= $pic ?>" readonly>
                   </div>
                   <div class="col-md-2">
                     <label>Mesin</label>
                     <input type="text" class="form-control" value="<?= $mesin ?>" readonly>
                   </div>
                   <div class="col-md-2">
                     <label>No Mesin</label>
                     <select name="no_mesin" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                       <option value="<?= $data1 ?>"><?= $data1 ?></option>
                       <?php
                        $sql2 = pg_query($koneksi, "SELECT no_mesin FROM dbmaintenance_assy.data_mesin where shop = '$shop_cari' AND line = '$line_cari' AND mesin = '$mesin' group by no_mesin");
                        while ($data = pg_fetch_array($sql2)) {
                          $no_mesinin = $data['no_mesin']; ?>
                         <option value="<?= $no_mesinin ?>"><?= $no_mesinin ?></option>

                       <?php }  ?>
                     </select>
                   </div>
                 </div>
                 <div class="row g-3">
                   <div class="col-md-3">
                     <label>Tanggal Plan</label>
                     <input type="date" class="form-control" name="tgl_planing" value="<?= $tgl_plan ?>">
                   </div>
                   <div class="col-md-3">
                     <label>Tanggal Aktual</label>
                     <input type="date" class="form-control" name="aktualin" value="<?= $tgl_aktualbos ?>">
                   </div>
                   <?php
                    if ($mesin == 'OHC') {
                    ?>
                     <div class="col-md-3">
                       <label>Area</label>
                       <select name="cat" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                         <option value="<?= $data2 ?>"><?= $data2 ?></option>
                         <?php
                          $sql2 = pg_query($koneksi, "SELECT cat FROM dbmaintenance_assy.itemcs_bd where shop = '$shop_cari' AND mesin = 'OHC' group by cat");
                          while ($data = pg_fetch_array($sql2)) {
                            $caty = $data['cat']; ?>
                           <option value="<?= $caty ?>"><?= $caty ?></option>
                         <?php }  ?>
                       </select>
                     </div>
                   <?php
                    } elseif ($mesin == 'ZERO OG BALANCER') {
                    ?>
                     <div class="col-md-3">
                       <label>Area</label>
                       <select name="cat" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                         <option value="<?= $data2 ?>"><?= $data2 ?></option>
                         <?php
                          $sql2 = pg_query($koneksi, "SELECT cat FROM dbmaintenance_assy.itemcs_bd where shop = '$shop_cari' AND mesin = 'ZERO OG BALANCER' AND periode = '$periodenya' group by cat");
                          while ($data = pg_fetch_array($sql2)) {
                            $caty = $data['cat']; ?>
                           <option value="<?= $caty ?>"><?= $caty ?></option>
                         <?php }  ?>
                       </select>
                     </div>
                   <?php
                    }
                    ?>
                 </div>
                 <br />
                 <div class="box-body">
                   <table id="example1" class="table table-bordered table-striped">
                     <thead>
                       <tr>
                         <th class="no">No</th>
                         <th class="item">Unit</th>
                         <th class="item">Item Check</th>
                         <th class="jud">Standart</th>
                         <th class="jud">Metode</th>
                         <th class="jud">Periode</th>
                         <th class="jud">Hasil</th>
                         <th class="jud">Keterangan</th>
                       </tr>
                     </thead>
                     <tbody>
                       <?php
                        for ($z = 1; $z <= $jumlah_item; $z++) {
                          // echo $z;
                        ?>
                         <tr>

                           <td>
                             <input type="text" class="form-control" hidden=""><?= $e++ ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="unitin<?= $z ?>" value="<?= $unit[$z] ?>" hidden=""><?= $unit[$z] ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="item_checkin<?= $z ?>" value="<?= $item_check[$z] ?>" hidden=""><?= $item_check[$z] ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="standartin<?= $z ?>" value="<?= $standart[$z] ?>" hidden=""><?= $standart[$z] ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="metodein<?= $z ?>" hidden="" value="<?= $metode[$z] ?>"><?= $metode[$z] ?>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" name="periodein<?= $z ?>" hidden="" value="<?= $periode[$z] ?>"><?= $periodeni[$z] ?>
                           </td>

                           <td>
                             <select style="width: 100px;" class="form-control" name="hasil<?= $z ?>">
                               <option value=""><?= $hasilin[$z] ?></option>
                               <option value="O">O</option>
                               <option value="X">X</option>
                               <option value="C">C</option>
                               <option value="R">R</option>
                             </select>
                           </td>
                           <td align="center" style="text-align: left;">
                             <input type="text" class="form-control" name="ket<?= $z ?>" value="<?= $ketin[$z] ?>">
                         </tr>
                       <?php
                        }
                        ?>
                     </tbody>
                   </table>
                 </div>
                 <div class="my-md-4 pt-md-1 border-top"> </div>
                 <div class="form-group col-md-5">
                   <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim">
                 </div>
               </form>
               <?php
                if (isset($_POST['kirim'])) {
                  $tgl_aktual   = $_POST['aktualin'];
                  $no_mesin   = $_POST['no_mesin'];
                  $cat   = $_POST['cat'];
                  $minggu_thn = date("W", strtotime($tgl_aktual));
                  $minggu_ke3 = ceil(date("j", strtotime($tgl_aktual)) / 7);
                  if ($minggu_ke3 == '5') {
                    $minggu_ke = '4';
                  } else {
                    $minggu_ke = $minggu_ke3;
                  }
                  $waktu_indonesia = time() + (60 * 60 * 7);
                  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
                  $blnzx = substr($tgl_aktual, 5, 2);
                  for ($i = 1; $i <= $jumlah_item; $i++) {
                    $unitod[$i]   = $_POST['unitin' . $i];
                    $item_checkod[$i]   = $_POST['item_checkin' . $i];
                    $standartod[$i]   = $_POST['standartin' . $i];
                    $metodeod[$i]   = $_POST['metodein' . $i];
                    $hasil[$i]   = $_POST['hasil' . $i];
                    $ket[$i]   = $_POST['ket' . $i];

                    $no_check2[$i] = $tgl_aktual . '-' . $periode[$i] . '-' . $shop_cari . '-' . $mesin . '-' . $no_mesin . '-' . $i;
                    ///////////////////////////////////////////////////////////////////////////////
                    // if($hasil[$i] == 'O'){
                    $input_prev = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.aktual_cs(unit,item_check,standart,metode,periode,shop,mesin,line,hasil,tanggal,no_check,no_check2,week,week_thn,bln,no_mesin,hasil_sdh,ket_sblm,ket_sdh,cat) VALUES ('$unit[$i]','$item_checkod[$i]','$standartod[$i]','$metodeod[$i]','$periode[$i]','$shop_cari','$mesin','$line_cari','$hasil[$i]','$tgl_aktual','$no_check2[$i]','$no_check','$minggu_ke','$minggu_thn',$bln_cari,'$no_mesin','','$ket[$i]','','$cat')");
                    // }
                    // $input_unfinish = pg_query($koneksi,"INSERT INTO dbmaintenance_weld.unfinishprev_assy (tanggal,tgl,code_shop,shop,line,mesin,no_mesin,item_prev,standar,unit,metode,no_check,pk_mesin,periode,ket,hasil,pic,bln,un_key) VALUES ('$jika',NOW(),'$code_shop_cari','$shop_cari','$line_cari','$mesin','$no_mesin_cari', '$item_checkod[$i]','$standartod[$i]','$unit[$i]','$metodeod[$i]', '$no_check_o[$i]','$pk[$i]','$periode','$keterangan[$i]','$hasil[$i]','$data5','$bln_cari','$unkey')");
                    // $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.aktual_cs(unit,item_check,standart,metode,periode,shop,mesin,line,hasil,tanggal,no_check,no_check2,week,week_thn,bln,no_mesin) VALUES ('$unit[$i]','$item_checkod[$i]','$standartod[$i]','$metodeod[$i]','$periode[$i]','$shop_cari','$mesin','$line_cari','$hasil[$i]','$tgl_aktual','$no_check2[$i]','$no_check','$minggu_ke','$minggu_thn',$bln_cari,'$no_mesin')");
                  }
                  $input_tin = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.tb_aktualprev(shop,bln,pic_prev,line,mesin,jml_mesin,jml_item,periode,tgl_plan,tgl_key,no_check,hasil,week,week_thn,bagian,no_mesin) VALUES ('$shop_cari','$blnzx','$pic','$line_cari','$mesin',$jml_mesin,$jml_item,'$periodenya','$tgl_aktual','$tanggal','$no_check','O','$minggu_ke','$minggu_thn','$bagian','$no_mesin')");
                }
                ?>
             </div>
           </div>
       </div>
     </div>
     <div id="footer"></div>

 </html>