 <?php
  error_reporting(0);
  $waktu_default = 21600; //21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
  $tanggal_sekarang = date('Y-m-d', time() + $waktu_default);
  $e = 1;

  include '../../koneksi.php';
  //$data1  = $_POST['line1'];
  //$data2  = $_POST['no_mesin'];
  //$data3  = $_POST['code_shop'];
  $data31 = $_POST['shop'];
  //$data4  = $_POST['mesin'];
  $datap  = $_POST['periode'];

  $jml = pg_query($koneksi, "SELECT COUNT(no) as jumlah_satu_month FROM dbmaintenance_assy.plan_item where shop = '$data31' AND periode = '$datap' ");
  while ($row = pg_fetch_array($jml)) {
    $jumlah_satu_month = $row['jumlah_satu_month'];
  }

  $itung = 0;
  $panggil_db = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.plan_item where shop = '$data31' AND periode = '$datap' ");
  while ($row = pg_fetch_array($panggil_db)) {
    $itung++;
    $nok[$itung] = $row['no'];
    $linein[$itung] = $row['line'];
    $itemin[$itung] = $row['item'];
    $jml_mesinin[$itung] = $row['jml_mesin'];
    $leader[$itung] = $row['leader'];
  }

  ?>
 <!DOCTYPE html>

 <html lang="en">

 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>dashboard - maintenance Smart factory</title>
   <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
 </head>

 <body class="hold-transition sidebar-mini">
   <div class="wrapper">

     <div class="row">
       <div class="col-md-12">
         <div class="alert alert-info" role="alert">
           <i class="fas fa-edit"></i> Input Data Preventive
         </div>
         <form method="post" method="get">
           <div class="card">
             <div class="card-body">
               <form class="needs-validation" method="post" enctype="multipart/form-data" novalidate>

                 <label>Shop</label>
                 <td>
                   <select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                     <option value="<?= $data31 ?>"><?= $data31 ?></option>
                     <?php
                      $sql2 = pg_query($koneksi, "SELECT shop FROM dbmaintenance_assy.plan_item group by shop");
                      while ($data = pg_fetch_array($sql2)) {
                        $code_shop = $data['shop']; ?>
                       <option value="<?= $code_shop ?>"><?php echo $data['shop'] ?></option>

                     <?php }  ?>
                   </select>

                   <div class="invalid-feedback">Shop tidak boleh kosong.</div>
                   <label>Periode</label>
                   <select id="periode" name="periode" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
                     <option value="<?= $datap ?>"><?= $datap ?></option>
                     <?php
                      $viewwww = pg_query($koneksi, "SELECT periode FROM dbmaintenance_assy.plan_item where shop = '$data31' group by periode");
                      while ($drowaa = pg_fetch_array($viewwww)) {
                        $periode = $drowaa['periode']; ?>
                       <option value="<?= $periode ?>"><?php echo $drowaa['periode'] ?></option>
                     <?php }  ?>
                   </select>

                   <div class="invalid-feedback">Mesin tidak boleh kosong.</div>
                   <!-- <label>Tanggal</label>
        <input type="date" class="form-control" name="tgll" required=""> -->
                   <label>Pic</label>
                   <select name="pic" class="form-control">
                     <option value="<?= $data5 ?>"><?= $data5 ?></option>
                     <?php
                      $pic = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' AND jabatan = 'Leader' ");
                      while ($ddd = pg_fetch_array($pic)) {
                        $nama = $ddd['nama']; ?>
                       <option value="<?= $nama ?>"><?php echo $ddd['nama'] ?></option>
                     <?php }  ?>
                   </select>

                   <br />
                   <div class="box-body">
                     <table id="example1" class="table table-bordered table-striped">
                       <thead>
                         <tr>
                           <th class="no">No</th>
                           <th class="item">Line</th>
                           <th class="item">Item</th>
                           <th class="jud">Jumlah Mesin</th>
                           <th class="jud">Tanggal Plan Awal</th>
                           <!-- <th class="jud">Tanggal Plan Akhir</th> -->
                           <!-- <th class="jud">Tanggal Preventive</th> -->
                           <!-- <th id="text" class="jud">Tanggal Preventive Bulan Ke 2</th>
                  <th id="text2" class="jud">Tanggal Preventive Bulan Ke 3</th>
                  <th id="text3" class="jud">Tanggal Preventive Bulan Ke 4</th> -->
                         </tr>
                       </thead>
                       <tbody>
                         <?php
                          $z = 1;
                          $ko = $z++;
                          for ($x = 1; $x <= $jumlah_satu_month; $x++) {
                          ?>
                           <tr>
                             <td>
                               <input type="text" class="form-control" name="noi<?= $x ?>" value="<?= $nok[$x] ?>" hidden=""><?= $e++ ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="linein<?= $x ?>" value="<?= $linein[$x] ?>" hidden=""><?= $linein[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="itemin<?= $x ?>" value="<?= $itemin[$x] ?>" hidden=""><?= $itemin[$x] ?>
                             </td>
                             <td align="center" style="text-align: left;">
                               <input type="text" name="jml_mesinin<?= $x ?>" value="<?= $jml_mesinin[$x] ?>" hidden=""><?= $jml_mesinin[$x] ?>
                             </td>

                             <!-- <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="plan_awal<?= $x ?>">
      </td> -->
                             <td align="center" style="text-align: left;">
                               <input type="date" class="form-control" name="plan_awal<?= $x ?>" value="<?= $plan_awal[$x] ?>">
                             </td>

                             <!-- <td align="center" style="text-align: left;">
        <input type="date" class="form-control" name="plan_akhir<?= $x ?>" value="<?= $plan_akhir[$x] ?>">
      </td> -->
                           <?php
                          }
                            ?>
                           </tr>
                       </tbody>
                     </table>
                   </div>
                   <div class="my-md-4 pt-md-1 border-top"> </div>
                   <div class="form-group col-md-5">
                     <input type="submit" class="btn btn-info btn-submit" name="kirim" value="Kirim">
                   </div>
               </form>
               <?php

                if (isset($_POST['kirim'])) {
                  $waktu_indonesia = time() + (60 * 60 * 7);
                  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
                  for ($i = 1; $i <= $jumlah_satu_month; $i++) {
                    $linein[$i]   = $_POST['linein' . $i];
                    $itemin[$i]         = $_POST['itemin' . $i];
                    $jml_mesinin[$i]   = $_POST['jml_mesinin' . $i];
                    $plan_awal[$i]      = $_POST['plan_awal' . $i];
                    $plan_akhir[$i]      = $_POST['plan_akhir' . $i];
                    $no_check[$i] = $tanggal . '-' . $data31 . '-' . $linein[$i] . '-' . $itemin[$i] . '-' . $jml_mesinin[$i];
                    ///////////////////////////////////////////////////////////////////////////////

                    $input_prev = pg_query($koneksi, "INSERT INTO dbmaintenance_assy.planprev_assy (line,shop,item,jml_mesin,tanggal,plan_awal,plan_akhir,no_check) VALUES ('$linein[$i]','$data31','$itemin[$i]','$jml_mesinin[$i]','$tanggal','$plan_awal[$i]','$plan_akhir[$i]','$no_check[$i]')");

                    $cek2  = pg_query($koneksi, $input_prev);
                  }
                }


                pg_close($koneksi);
                ?>
             </div>
           </div>
       </div>
     </div>
     <div id="footer"></div>

 </html>