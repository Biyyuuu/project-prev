<?php

    if (isset($_POST['kirim'])) {
      $waktu_indonesia = time() + (60 * 60 * 7);
      $tanggal = gmdate('Y-m-d', $waktu_indonesia);
      for ($i=1;$i<=$jumlah_satu_month;$i++) {
       $linein[$i]      = $_POST['linein'.$i];
       $itemin[$i]      = $_POST['itemin'.$i];
       $mesin[$i]      = $_POST['mesinin'.$i];
       $jml_mesinin[$i] = $_POST['jml_mesinin'.$i];
       $jml_item[$i] = $_POST['jml_itemin'.$i];
       $plan[$i]   = $_POST['planin'.$i];
       $shop[$i]   = $_POST['shopin'.$i];
       $periode[$i]  = $_POST['periodein'.$i];
      //  $no_check[$i]    = $tanggal.'-'.$data31.'-'.$linein[$i].'-'.$itemin[$i].'-'.$jml_mesinin[$i];
       ///////////////////////////////////////////////////////////////////////////////
if($plan[$i] !== NULL){
       $input_prev = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.tb_planprev (shop,bln,pic,line,item,mesin,jml_mesin,jml_item,periode,tgl_plan,tgl_key) VALUES ('$data31','$datab','$shop[$i]','$linein[$i]','$itemin[$i]','$mesin[$i]','$jml_mesinin[$i]','$jml_item[$i]','$periode[$i]','$plan[$i]',NOW())");

        $cek2  = pg_query($koneksi, $input_prev);
      }
      else{
        pg_close($koneksi);
      }
        }
        exit;
      }
    
      pg_close($koneksi);
   
?>