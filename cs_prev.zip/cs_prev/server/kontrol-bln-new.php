<?php
include '../koneksi.php';
include 'pengaturan-be.php';
switch ($blnz) {
case '01':
  $bln_se = 'Januari';
  break;
case '02':
  $bln_se = 'Februari';
  break;
case '03':
  $bln_se = 'Maret';
  break;
case '04':
  $bln_se = 'April';
  break;
case '05':
  $bln_se = 'Mei';
  break;
case '06':
  $bln_se = 'Juni';
  break;
case '07':
  $bln_se = 'Juli';
  break;
case '08':
  $bln_se = 'Agustus';
  break;
 case '09':
  $bln_se = 'September';
  break;
  case '10':
  $bln_se = 'Oktober';
  break;
  case '11':
  $bln_se = 'November';
  break;
  case '12':
  $bln_se = 'Desember';
  break;   
} 
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Kontrol Preventive</title>
  <link href="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.css" rel="stylesheet" type="text/css"/>
  <link href="/iotmtc/weld/cs_prev/dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>
<style type="text/css">

	.tableFixHead {
        overflow-y: auto;
        height: 1000px;
      }
      .tableFixHead thead th {
        position: sticky;
        top: 0;
      }
      table {
        border-collapse: separate;
        width: 100%;
      }
      th,
      td {
        padding: 8px 16px;
        border: 1px solid #ccc;
      }
      th {
        background-color: #ffffff;
      }
      img{
      width: 17px;
      height: 17px;
    }
	.footer {position:absolute;
   bottom:0;
   width:100%;
   height:1000px;   /* tinggi dari footer */
   background:#6cf;}
</style>

<body>
      <div class="wrapper theme-1-active pimary-color-blue">
      
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                  <h1 style="text-align:center; font-size: x-large;">RENCANA AKTIVITAS HARIAN SHOP MAINTENANCE ASSY</h1>
                  <h3 style="text-align:center;  font-size: x-large;"><?=$shop_assy?> Line <?=$line_assy?></h3>
                   <br/>
                   <h5 style="text-align:center;  font-size: x-large;">(2023)</h5>
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
   <table style="float:right;margin-right:30px;font-weight: bold; width:100px; border: 1px solid #000;">
          <td style="text-align:center; color: white; background-color:blue;" >1 Bulanan</td>
          <td style="text-align:center; color: black; background-color:LawnGreen;" >3 Bulanan</td>
          <td style="text-align:center; color: black; background-color:orange; " >6 Bulanan</td>
          <td style="text-align:center; color: black; background-color:cyan;" >1 Tahunan</td>
    </table>
</div>
<div class="table-wrap mt-1" style="margin-top:100px;">
	<div class="table-responsive">
	<div class="tableFixHead">
<table class="table table-striped table-bordered mb-0">
  <thead>
    <tr>
           <th rowspan="2">No</th>
           <th rowspan="2">Line</th>
           <th rowspan="2" style="text-align: center; width:10px;">Item Pekerjaan</th>
           <th rowspan="2" style="text-align: center; width:10px;">Jml Mesin</th>
           <th rowspan="2" style="text-align: center; width:10px;">Jml Item</th>
           <th rowspan="1" style="text-align: center; width:10px;">Plan </th>
           <!-- <th colspan="1" style="text-align: center;">Aktual</th> -->
           <th colspan="31" style="text-align: center; width:10px; font-size:20px; font:bold;"> <?=$bln_se?> <?=$thnz?> </th> 
           <!-- <th rowspan="2" style="text-align: center; width:10px;">Jml Item</th>  -->
           <!-- <th rowspan="2" style="text-align: center; width:10px;">%</th>  -->
           <!-- <th rowspan="2" style="text-align: center; width:10px;">PIC</th> -->
           <!-- <th rowspan="2" style="text-align: center; width:10px;">Keterangan</th> -->
    </tr>
    <tr>
    <th colspan="1" style="text-align: center;">Aktual</th>
      <?php
      for($xi=1;$xi<=31;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
        </tr>
    </thead>
  <tbody>
<?php
$z=1;
  for ($i=1; $i <= $jml_id ; $i++){
?>

    <tr>
      <td rowspan="2" align="center"><?= $z++ ?></td> 
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $line_assy;?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href="">Preventive <?=$periodeni[$i]?> <?= $mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $jml_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $jml_item[$i];?></a> </td> 
      
      <td align="center" style="text-align: left;"><a href="">Plan </a> </td><!------// PLAN  //------->
      
      <?php 
            for($x=1;$x<=31;$x++){
              if($periode_plan[$x][$i] == '1M'){
                $coloring[$x][$i] = 'blue';
                $fontnya[$x][$i] = 'white';
              }elseif($periode_plan[$x][$i] == '3M'){
                $coloring[$x][$i] = 'LawnGreen';
                $fontnya[$x][$i] = 'black';
              }elseif($periode_plan[$x][$i] == '6M'){
                $coloring[$x][$i] = 'orange';
                $fontnya[$x][$i] = 'black';
              }elseif($periode_plan[$x][$i] == '1Y'){
                $coloring[$x][$i] = 'cyan';
                $fontnya[$x][$i] = 'black';
              }
					?>

			<td style="background-color:<?=$coloring[$x][$i]?>;"><a href="input/input-aktual.php?no_check=<?= $no_check_plan[$x][$i]?>" style="color:<?=$fontnya[$x][$i]?>; " target="_blank"><?=$line_plan[$x][$i]?></a></td>
			<?php
			}
			?>

<!-- <td rowspan="2" align="center" style="text-align: left;"><a href=""></a></td> -->
</tr>
  <tr>
    <td  align="center" style="text-align: left;"><a href=""> Aktual</a> </td>
    <?php 
					for($x=1;$x<=31;$x++){
		 					  if($tot_act[$x][$i] == "0"){
				    		    $warnaact[$x][$i] = "image/putih.png";
				    		}
				    		elseif ($tot_act[$x][$i] >= "1"){
				    		    $warnaact[$x][$i] = "image/ijo2.png";
				    		}
				    		else{
				    		    $isii[$x][$i]="";
				    		}
			?>
      <td><a href="input/edit_aktual.php?no_check=<?= $no_check_aktual[$x][$i]?>" ><?=$hasil_aktual[$x][$i]?></a></td>
			<?php
			}
			?>
  </tr>
  <?php
}
?>
 </tbody>
       </table>
</div>
</div>
</div>
      </div>  
     </div>  
    </div>  
   </div>  
  </div>  
 </div>
 </div>
    <script src="/iotmtc/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="/iotmtc/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.min.js"></script>
  <!-- <script src="/iotmtc/weld/cs_prev/dist/js/init.js"></script> -->
  
</body>
</html>