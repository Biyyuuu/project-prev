<?php
include '../koneksi.php';
include 'pengaturan-new.php';
switch ($blnz) {
case '01':
  $bln_se = 'Januari';
  break;
case '02':
  $bln_se = 'Februari';
  break;
case '03':
  $bln_se = 'Maret';
  break;
case '04':
  $bln_se = 'April';
  break;
case '05':
  $bln_se = 'Mei';
  break;
case '06':
  $bln_se = 'Juni';
  break;
case '07':
  $bln_se = 'Juli';
  break;
case '08':
  $bln_se = 'Agustus';
  break;
 case '09':
  $bln_se = 'September';
  break;
  case '10':
  $bln_se = 'Oktober';
  break;
  case '11':
  $bln_se = 'November';
  break;
  case '12':
  $bln_se = 'Desember';
  break;   
} 
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Kontrol Preventive</title>
  <link href="/iotmtc/weld/cs_prev/dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>
<style type="text/css">
	.tableFixHead {
        overflow-y: auto;
        height: 1000px;
      }
      .tableFixHead thead th {
        position: sticky;
        top: 0;
      }
      table {
        border-collapse: separate;
        width: 100%;
      }
      
      th {
        background: #ffffff;
      }
      thead {
  position: sticky;
  top: 0;
  background: #eee;
}
      img{
      width: 17px;
      height: 17px;
    }
	.footer {
    position:absolute;
   bottom:0;
   width:100%;
   height:1000px;   /* tinggi dari footer */
   background:#6cf;
   }
</style>

<body>
      <div class="wrapper theme-1-active pimary-color-blue">
      
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                  <h1 style="text-align:center; font-size: x-large;">KALENDER CONTROL KERJA PREVENTIVE MAINTENANCE ASSY YIMM-WJ FACTORY</h1>
                  <h3 style="text-align:center;  font-size: x-large;"><?=$shop_assy?> Line <?=$line_assy?></h3>
                  <h5 style="text-align:center;  font-size: x-large;">(<?=$tahunan?>)</h5>
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
  <table style="float:right;margin-right:30px;font-weight: bold; width:100px; border: 1px solid #000;">
          <td style="text-align:center; color: white; background-color:blue;" >1 Bulanan</td>
          <td style="text-align:center; color: black; background-color:LawnGreen;" >3 Bulanan</td>
          <td style="text-align:center; color: black; background-color:orange; " >6 Bulanan</td>
          <td style="text-align:center; color: black; background-color:cyan;" >1 Tahunan</td>
    </table>
</div>
<div class="table-wrap mt-1" style="margin-top:100px;">
	<div class="table-responsive">
	<div class="tableFixHead">
<table class="table table-striped table-bordered mb-0" >
  <thead>
    <tr >
           <th rowspan="2">No</th>
           <th rowspan="2">Line</th>
           <th rowspan="2" style="text-align: center; width:10px;">SPESIFIK MESIN</th>
           <th rowspan="2" style="text-align: center; width:10px;">JML MESIN</th>
           <th rowspan="2" style="text-align: center; width:10px;">JML ITEM </th>
           <th rowspan="2" style="text-align: center; width:10px;">SHOP/LINE</th>
           <th rowspan="1" style="text-align: center; width:10px;">PLAN</th>
           <th colspan="5" style="text-align: center; width:10px;">Jan</th> 
           <th colspan="5" style="text-align: center; width:10px;">Feb</th> 
           <th colspan="5" style="text-align: center; width:10px;">Mar</th>  
           <th colspan="5" style="text-align: center; width:10px;">Apr</th> 
           <th colspan="5" style="text-align: center; width:10px;">Mei</th> 
           <th colspan="5" style="text-align: center; width:10px;">Jun</th> 
           <th colspan="5" style="text-align: center; width:10px;">Jul</th> 
           <th colspan="5" style="text-align: center; width:10px;">Ags</th> 
           <th colspan="5" style="text-align: center; width:10px;">Sep</th> 
           <th colspan="5" style="text-align: center; width:10px;">Okt</th> 
           <th colspan="5" style="text-align: center; width:10px;">Nov</th> 
           <th colspan="5" style="text-align: center; width:10px;">Des</th> 
           <th rowspan="2" style="text-align: center; width:10px;">Total</th>
    </tr>
    <tr>
    <th colspan="1" style="text-align: center;">Aktual</th>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?></th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
      <?php
      for($xi=1;$xi<=5;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
        </tr>
    </thead>
  <tbody>
<?php
$z=1;
echo $tahun_cari;
  for ($i=1; $i <= $jml_id ; $i++){
?>

    <tr>
      <td rowspan="2" align="center"><?= $z++ ?></td> 
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $line_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $mesin_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $tot_mesin[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $tot_item[$i];?></a></td>
      <td rowspan="2" align="center" style="text-align: left;"><a href=""><?= $shop_mesin[$i];?></a> </td> 
      
      <td align="center" style="text-align: left;"><a href="">Plan </a> </td><!------// PLAN  //------->
      
      <?php  
					for($x=1;$x<=5;$x++){
            if($periode_plan_jan[$x][$i] == '1M'){
              $coloring_jan[$x][$i] = 'blue';
              $fontnya_jan[$x][$i] = 'white';
            }elseif($periode_plan_jan[$x][$i] == '3M'){
              $coloring_jan[$x][$i] = 'LawnGreen';
              $fontnya_jan[$x][$i] = 'black';
            }elseif($periode_plan_jan[$x][$i] == '6M'){
              $coloring_jan[$x][$i] = 'orange';
              $fontnya_jan[$x][$i] = 'black';
            }elseif($periode_plan_jan[$x][$i] == '1Y'){
              $coloring_jan[$x][$i] = 'cyan';
              $fontnya_jan[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya_jan[$x][$i]?>; background-color:<?=$coloring_jan[$x][$i]?>;"><?=$line_plan_jan[$x][$i]?></td>
		  <?php
			  }

					for($x=1;$x<=5;$x++){
            if($periode_plan_feb[$x][$i] == '1M'){
              $coloring_feb[$x][$i] = 'blue';
              $fontnya_feb[$x][$i] = 'white';
            }elseif($periode_plan_feb[$x][$i] == '3M'){
              $coloring_feb[$x][$i] = 'LawnGreen';
              $fontnya_feb[$x][$i] = 'black';
            }elseif($periode_plan_feb[$x][$i] == '6M'){
              $coloring_feb[$x][$i] = 'orange';
              $fontnya_feb[$x][$i] = 'black';
            }elseif($periode_plan_feb[$x][$i] == '1Y'){
              $coloring_feb[$x][$i] = 'cyan';
              $fontnya_feb[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya_feb[$x][$i]?>; background-color:<?=$coloring_feb[$x][$i]?>;"><?=$line_plan_feb[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            if($periode_plan_mar[$x][$i] == '1M'){
              $coloring_mar[$x][$i] = 'blue';
              $fontnya_mar[$x][$i] = 'white';
            }elseif($periode_plan_mar[$x][$i] == '3M'){
              $coloring_mar[$x][$i] = 'LawnGreen';
              $fontnya_mar[$x][$i] = 'black';
            }elseif($periode_plan_mar[$x][$i] == '6M'){
              $coloring_mar[$x][$i] = 'orange';
              $fontnya_mar[$x][$i] = 'black';
            }elseif($periode_plan_mar[$x][$i] == '1Y'){
              $coloring_mar[$x][$i] = 'cyan';
              $fontnya_mar[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya_mar[$x][$i]?>; background-color:<?=$coloring_mar[$x][$i]?>;"><?=$line_plan_mar[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            if($periode_plan_apr[$x][$i] == '1M'){
              $coloring_apr[$x][$i] = 'blue';
              $fontnya_apr[$x][$i] = 'white';
            }elseif($periode_plan_apr[$x][$i] == '3M'){
              $coloring_apr[$x][$i] = 'LawnGreen';
              $fontnya_apr[$x][$i] = 'black';
            }elseif($periode_plan_apr[$x][$i] == '6M'){
              $coloring_apr[$x][$i] = 'orange';
              $fontnya_apr[$x][$i] = 'black';
            }elseif($periode_plan_apr[$x][$i] == '1Y'){
              $coloring_apr[$x][$i] = 'cyan';
              $fontnya_apr[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya_apr[$x][$i]?>; background-color:<?=$coloring_apr[$x][$i]?>;"><?=$line_plan_apr[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            if($periode_plan_mei[$x][$i] == '1M'){
              $coloring_mei[$x][$i] = 'blue';
              $fontnya_mei[$x][$i] = 'white';
            }elseif($periode_plan_mei[$x][$i] == '3M'){
              $coloring_mei[$x][$i] = 'LawnGreen';
              $fontnya_mei[$x][$i] = 'black';
            }elseif($periode_plan_mei[$x][$i] == '6M'){
              $coloring_mei[$x][$i] = 'orange';
              $fontnya_mei[$x][$i] = 'black';
            }elseif($periode_plan_mei[$x][$i] == '1Y'){
              $coloring_mei[$x][$i] = 'cyan';
              $fontnya_mei[$x][$i] = 'black';
            }
			?>
      <td style="color:<?=$fontnya_mei[$x][$i]?>; background-color:<?=$coloring_mei[$x][$i]?>;"><?=$line_plan_mei[$x][$i]?></td>
		  <?php
			  }

        for($x=1;$x<=5;$x++){
          if($periode_plan_jun[$x][$i] == '1M'){
            $coloring_jun[$x][$i] = 'blue';
            $fontnya_jun[$x][$i] = 'white';
          }elseif($periode_plan_jun[$x][$i] == '3M'){
            $coloring_jun[$x][$i] = 'LawnGreen';
            $fontnya_jun[$x][$i] = 'black';
          }elseif($periode_plan_jun[$x][$i] == '6M'){
            $coloring_jun[$x][$i] = 'orange';
            $fontnya_jun[$x][$i] = 'black';
          }elseif($periode_plan_jun[$x][$i] == '1Y'){
            $coloring_jun[$x][$i] = 'cyan';
            $fontnya_jun[$x][$i] = 'black';
          }
    ?>
    <td style="color:<?=$fontnya_jun[$x][$i]?>; background-color:<?=$coloring_jun[$x][$i]?>;"><?=$line_plan_jun[$x][$i]?></td>
    <?php
      }
      for($x=1;$x<=5;$x++){
        if($periode_plan_jul[$x][$i] == '1M'){
          $coloring_jul[$x][$i] = 'blue';
          $fontnya_jul[$x][$i] = 'white';
        }elseif($periode_plan_jul[$x][$i] == '3M'){
          $coloring_jul[$x][$i] = 'LawnGreen';
          $fontnya_jul[$x][$i] = 'black';
        }elseif($periode_plan_jul[$x][$i] == '6M'){
          $coloring_jul[$x][$i] = 'orange';
          $fontnya_jul[$x][$i] = 'black';
        }elseif($periode_plan_jul[$x][$i] == '1Y'){
          $coloring_jul[$x][$i] = 'cyan';
          $fontnya_jul[$x][$i] = 'black';
        }
  ?>
  <td style="color:<?=$fontnya_jul[$x][$i]?>; background-color:<?=$coloring_jul[$x][$i]?>;"><?=$line_plan_jul[$x][$i]?></td>
  <?php
    }
    for($x=1;$x<=5;$x++){
      if($periode_plan_ags[$x][$i] == '1M'){
        $coloring_ags[$x][$i] = 'blue';
        $fontnya_ags[$x][$i] = 'white';
      }elseif($periode_plan_ags[$x][$i] == '3M'){
        $coloring_ags[$x][$i] = 'LawnGreen';
        $fontnya_ags[$x][$i] = 'black';
      }elseif($periode_plan_ags[$x][$i] == '6M'){
        $coloring_ags[$x][$i] = 'orange';
        $fontnya_ags[$x][$i] = 'black';
      }elseif($periode_plan_ags[$x][$i] == '1Y'){
        $coloring_ags[$x][$i] = 'cyan';
        $fontnya_ags[$x][$i] = 'black';
      }
?>
<td style="color:<?=$fontnya_ags[$x][$i]?>; background-color:<?=$coloring_ags[$x][$i]?>;"><?=$line_plan_ags[$x][$i]?></td>
<?php
  }
  for($x=1;$x<=5;$x++){
    if($periode_plan_sep[$x][$i] == '1M'){
      $coloring_sep[$x][$i] = 'blue';
      $fontnya_sep[$x][$i] = 'white';
    }elseif($periode_plan_sep[$x][$i] == '3M'){
      $coloring_sep[$x][$i] = 'LawnGreen';
      $fontnya_sep[$x][$i] = 'black';
    }elseif($periode_plan_sep[$x][$i] == '6M'){
      $coloring_sep[$x][$i] = 'orange';
      $fontnya_sep[$x][$i] = 'black';
    }elseif($periode_plan_sep[$x][$i] == '1Y'){
      $coloring_sep[$x][$i] = 'cyan';
      $fontnya_sep[$x][$i] = 'black';
    }
?>
<td style="color:<?=$fontnya_sep[$x][$i]?>; background-color:<?=$coloring_sep[$x][$i]?>;"><?=$line_plan_sep[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  if($periode_plan_okt[$x][$i] == '1M'){
    $coloring_okt[$x][$i] = 'blue';
    $fontnya_okt[$x][$i] = 'white';
  }elseif($periode_plan_okt[$x][$i] == '3M'){
    $coloring_okt[$x][$i] = 'LawnGreen';
    $fontnya_okt[$x][$i] = 'black';
  }elseif($periode_plan_okt[$x][$i] == '6M'){
    $coloring_okt[$x][$i] = 'orange';
    $fontnya_okt[$x][$i] = 'black';
  }elseif($periode_plan_okt[$x][$i] == '1Y'){
    $coloring_okt[$x][$i] = 'cyan';
    $fontnya_okt[$x][$i] = 'black';
  }
?>
<td style="color:<?=$fontnya_okt[$x][$i]?>; background-color:<?=$coloring_okt[$x][$i]?>;"><?=$line_plan_okt[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  if($periode_plan_nov[$x][$i] == '1M'){
    $coloring_nov[$x][$i] = 'blue';
    $fontnya_nov[$x][$i] = 'white';
  }elseif($periode_plan_nov[$x][$i] == '3M'){
    $coloring_nov[$x][$i] = 'LawnGreen';
    $fontnya_nov[$x][$i] = 'black';
  }elseif($periode_plan_nov[$x][$i] == '6M'){
    $coloring_nov[$x][$i] = 'orange';
    $fontnya_nov[$x][$i] = 'black';
  }elseif($periode_plan_nov[$x][$i] == '1Y'){
    $coloring_nov[$x][$i] = 'cyan';
    $fontnya_nov[$x][$i] = 'black';
  }
?>
<td style="color:<?=$fontnya_nov[$x][$i]?>; background-color:<?=$coloring_nov[$x][$i]?>;"><?=$line_plan_nov[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  if($periode_plan_des[$x][$i] == '1M'){
    $coloring_des[$x][$i] = 'blue';
    $fontnya_des[$x][$i] = 'white';
  }elseif($periode_plan_des[$x][$i] == '3M'){
    $coloring_des[$x][$i] = 'LawnGreen';
    $fontnya_des[$x][$i] = 'black';
  }elseif($periode_plan_des[$x][$i] == '6M'){
    $coloring_des[$x][$i] = 'orange';
    $fontnya_des[$x][$i] = 'black';
  }elseif($periode_plan_des[$x][$i] == '1Y'){
    $coloring_des[$x][$i] = 'cyan';
    $fontnya_des[$x][$i] = 'black';
  }
?>
<td style="color:<?=$fontnya_des[$x][$i]?>; background-color:<?=$coloring_des[$x][$i]?>;"><?=$line_plan_des[$x][$i]?></td>
<?php
}
?>
      
<!-- <td style="text-align: center;">IP</td> -->
<td rowspan="1" align="center" style="text-align: center;"><?=$tot_plan[$i]?></td>

</tr>

  <tr>
    
    <td  align="center" style="text-align: left;"><a href="">Aktual</a> </td>
    <?php  
					for($x=1;$x<=5;$x++){
            // if($periode_act_jan[$x][$i] == '1M'){
            //   $coloring_act_jan[$x][$i] = 'blue';
            //   $fontnya_act_jan[$x][$i] = 'white';
            // }elseif($periode_act_jan[$x][$i] == '3M'){
            //   $coloring_act_jan[$x][$i] = 'LawnGreen';
            //   $fontnya_act_jan[$x][$i] = 'black';
            // }elseif($periode_act_jan[$x][$i] == '6M'){
            //   $coloring_act_jan[$x][$i] = 'orange';
            //   $fontnya_act_jan[$x][$i] = 'black';
            // }elseif($periode_act_jan[$x][$i] == '1Y'){
            //   $coloring_act_jan[$x][$i] = 'cyan';
            //   $fontnya_act_jan[$x][$i] = 'black';
            // }
			?>
      <td style=""><?=$line_act_jan[$x][$i]?></td>
		  <?php
			  }

					for($x=1;$x<=5;$x++){
            // if($periode_act_feb[$x][$i] == '1M'){
            //   $coloring_act_feb[$x][$i] = 'blue';
            //   $fontnya_act_feb[$x][$i] = 'white';
            // }elseif($periode_act_feb[$x][$i] == '3M'){
            //   $coloring_act_feb[$x][$i] = 'LawnGreen';
            //   $fontnya_act_feb[$x][$i] = 'black';
            // }elseif($periode_act_feb[$x][$i] == '6M'){
            //   $coloring_act_feb[$x][$i] = 'orange';
            //   $fontnya_act_feb[$x][$i] = 'black';
            // }elseif($periode_act_feb[$x][$i] == '1Y'){
            //   $coloring_act_feb[$x][$i] = 'cyan';
            //   $fontnya_act_feb[$x][$i] = 'black';
            // }
			?>
      <td style=""><?=$line_act_feb[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            // if($periode_act_mar[$x][$i] == '1M'){
            //   $coloring_act_mar[$x][$i] = 'blue';
            //   $fontnya_act_mar[$x][$i] = 'white';
            // }elseif($periode_act_mar[$x][$i] == '3M'){
            //   $coloring_act_mar[$x][$i] = 'LawnGreen';
            //   $fontnya_act_mar[$x][$i] = 'black';
            // }elseif($periode_act_mar[$x][$i] == '6M'){
            //   $coloring_act_mar[$x][$i] = 'orange';
            //   $fontnya_act_mar[$x][$i] = 'black';
            // }elseif($periode_act_mar[$x][$i] == '1Y'){
            //   $coloring_act_mar[$x][$i] = 'cyan';
            //   $fontnya_act_mar[$x][$i] = 'black';
            // }
			?>
      <td style=""><?=$line_act_mar[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            // if($periode_act_apr[$x][$i] == '1M'){
            //   $coloring_act_apr[$x][$i] = 'blue';
            //   $fontnya_act_apr[$x][$i] = 'white';
            // }elseif($periode_act_apr[$x][$i] == '3M'){
            //   $coloring_act_apr[$x][$i] = 'LawnGreen';
            //   $fontnya_act_apr[$x][$i] = 'black';
            // }elseif($periode_act_apr[$x][$i] == '6M'){
            //   $coloring_act_apr[$x][$i] = 'orange';
            //   $fontnya_act_apr[$x][$i] = 'black';
            // }elseif($periode_act_apr[$x][$i] == '1Y'){
            //   $coloring_act_apr[$x][$i] = 'cyan';
            //   $fontnya_act_apr[$x][$i] = 'black';
            // }
			?>
      <td style=""><?=$line_act_apr[$x][$i]?></td>
		  <?php
			  }
      for($x=1;$x<=5;$x++){
            // if($periode_act_mei[$x][$i] == '1M'){
            //   $coloring_act_mei[$x][$i] = 'blue';
            //   $fontnya_act_mei[$x][$i] = 'white';
            // }elseif($periode_act_mei[$x][$i] == '3M'){
            //   $coloring_act_mei[$x][$i] = 'LawnGreen';
            //   $fontnya_act_mei[$x][$i] = 'black';
            // }elseif($periode_act_mei[$x][$i] == '6M'){
            //   $coloring_act_mei[$x][$i] = 'orange';
            //   $fontnya_act_mei[$x][$i] = 'black';
            // }elseif($periode_act_mei[$x][$i] == '1Y'){
            //   $coloring_act_mei[$x][$i] = 'cyan';
            //   $fontnya_act_mei[$x][$i] = 'black';
            // }
			?>
      <td style=""><?=$line_act_mei[$x][$i]?></td>
		  <?php
			  }

        for($x=1;$x<=5;$x++){
          // if($periode_act_jun[$x][$i] == '1M'){
          //   $coloring_act_jun[$x][$i] = 'blue';
          //   $fontnya_act_jun[$x][$i] = 'white';
          // }elseif($periode_act_jun[$x][$i] == '3M'){
          //   $coloring_act_jun[$x][$i] = 'LawnGreen';
          //   $fontnya_act_jun[$x][$i] = 'black';
          // }elseif($periode_act_jun[$x][$i] == '6M'){
          //   $coloring_act_jun[$x][$i] = 'orange';
          //   $fontnya_act_jun[$x][$i] = 'black';
          // }elseif($periode_act_jun[$x][$i] == '1Y'){
          //   $coloring_act_jun[$x][$i] = 'cyan';
          //   $fontnya_act_jun[$x][$i] = 'black';
          // }
    ?>
    <td style=""><?=$line_act_jun[$x][$i]?></td>
    <?php
      }
      for($x=1;$x<=5;$x++){
        // if($periode_act_jul[$x][$i] == '1M'){
        //   $coloring_act_jul[$x][$i] = 'blue';
        //   $fontnya_act_jul[$x][$i] = 'white';
        // }elseif($periode_act_jul[$x][$i] == '3M'){
        //   $coloring_act_jul[$x][$i] = 'LawnGreen';
        //   $fontnya_act_jul[$x][$i] = 'black';
        // }elseif($periode_act_jul[$x][$i] == '6M'){
        //   $coloring_act_jul[$x][$i] = 'orange';
        //   $fontnya_act_jul[$x][$i] = 'black';
        // }elseif($periode_act_jul[$x][$i] == '1Y'){
        //   $coloring_act_jul[$x][$i] = 'cyan';
        //   $fontnya_act_jul[$x][$i] = 'black';
        // }
  ?>
  <td style=""><?=$line_act_jul[$x][$i]?></td>
  <?php
    }
    for($x=1;$x<=5;$x++){
      // if($periode_act_ags[$x][$i] == '1M'){
      //   $coloring_act_ags[$x][$i] = 'blue';
      //   $fontnya_act_ags[$x][$i] = 'white';
      // }elseif($periode_act_ags[$x][$i] == '3M'){
      //   $coloring_act_ags[$x][$i] = 'LawnGreen';
      //   $fontnya_act_ags[$x][$i] = 'black';
      // }elseif($periode_act_ags[$x][$i] == '6M'){
      //   $coloring_act_ags[$x][$i] = 'orange';
      //   $fontnya_act_ags[$x][$i] = 'black';
      // }elseif($periode_act_ags[$x][$i] == '1Y'){
      //   $coloring_act_ags[$x][$i] = 'cyan';
      //   $fontnya_act_ags[$x][$i] = 'black';
      // }
?>
<td style=""><?=$line_act_ags[$x][$i]?></td>
<?php
  }
  for($x=1;$x<=5;$x++){
    // if($periode_act_sep[$x][$i] == '1M'){
    //   $coloring_act_sep[$x][$i] = 'blue';
    //   $fontnya_act_sep[$x][$i] = 'white';
    // }elseif($periode_act_sep[$x][$i] == '3M'){
    //   $coloring_act_sep[$x][$i] = 'LawnGreen';
    //   $fontnya_act_sep[$x][$i] = 'black';
    // }elseif($periode_act_sep[$x][$i] == '6M'){
    //   $coloring_act_sep[$x][$i] = 'orange';
    //   $fontnya_act_sep[$x][$i] = 'black';
    // }elseif($periode_act_sep[$x][$i] == '1Y'){
    //   $coloring_act_sep[$x][$i] = 'cyan';
    //   $fontnya_act_sep[$x][$i] = 'black';
    // }
?>
<td style=""><?=$line_act_sep[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  // if($periode_act_okt[$x][$i] == '1M'){
  //   $coloring_act_okt[$x][$i] = 'blue';
  //   $fontnya_act_okt[$x][$i] = 'white';
  // }elseif($periode_act_okt[$x][$i] == '3M'){
  //   $coloring_act_okt[$x][$i] = 'LawnGreen';
  //   $fontnya_act_okt[$x][$i] = 'black';
  // }elseif($periode_act_okt[$x][$i] == '6M'){
  //   $coloring_act_okt[$x][$i] = 'orange';
  //   $fontnya_act_okt[$x][$i] = 'black';
  // }elseif($periode_act_okt[$x][$i] == '1Y'){
  //   $coloring_act_okt[$x][$i] = 'cyan';
  //   $fontnya_act_okt[$x][$i] = 'black';
  // }
?>
<td style=""><?=$line_act_okt[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  // if($periode_act_nov[$x][$i] == '1M'){
  //   $coloring_act_nov[$x][$i] = 'blue';
  //   $fontnya_act_nov[$x][$i] = 'white';
  // }elseif($periode_act_nov[$x][$i] == '3M'){
  //   $coloring_act_nov[$x][$i] = 'LawnGreen';
  //   $fontnya_act_nov[$x][$i] = 'black';
  // }elseif($periode_act_nov[$x][$i] == '6M'){
  //   $coloring_act_nov[$x][$i] = 'orange';
  //   $fontnya_act_nov[$x][$i] = 'black';
  // }elseif($periode_act_nov[$x][$i] == '1Y'){
  //   $coloring_act_nov[$x][$i] = 'cyan';
  //   $fontnya_act_nov[$x][$i] = 'black';
  // }
?>
<td><?=$line_act_nov[$x][$i]?></td>
<?php
}
for($x=1;$x<=5;$x++){
  // if($periode_act_des[$x][$i] == '1M'){
  //   $coloring_act_des[$x][$i] = 'blue';
  //   $fontnya_act_des[$x][$i] = 'white';
  // }elseif($periode_act_des[$x][$i] == '3M'){
  //   $coloring_act_des[$x][$i] = 'LawnGreen';
  //   $fontnya_act_des[$x][$i] = 'black';
  // }elseif($periode_act_des[$x][$i] == '6M'){
  //   $coloring_act_des[$x][$i] = 'orange';
  //   $fontnya_act_des[$x][$i] = 'black';
  // }elseif($periode_act_des[$x][$i] == '1Y'){
  //   $coloring_act_des[$x][$i] = 'cyan';
  //   $fontnya_act_des[$x][$i] = 'black';
  // }
?>
<td style=""><?=$line_act_des[$x][$i]?></td>
<?php
}
?>

<td rowspan="1" align="center" style="text-align: center;"><?=$tot_acto[$i]?></td>
  </tr>
  <?php
}
?>
<tr>
			<th colspan="3" rowspan="2" style="font-weight: bold; font-size:50px;">TOTAL</th>
      <th colspan="1" rowspan="2"><?=$tot_mesin_thn?></th>
      <th colspan="1" rowspan="2"><?=$tot_item_thn?></th>
      <th colspan="2" >Plan</th>      
      <?php 
			for ($i=1; $i <= 48 ; $i++) { ?>
				<th style="color: red;font-weight: bolder;font-style: italic;"><?= $tot_plan_week[$i] ?></th>
			<?php }
			 ?>
       <th colspan="1" rowspan="2"><?=$tot_actot?></th> 
</tr>
<tr>
  <th colspan="2" rowspan="1">Aktual</th>
  <?php 
			for ($i=1; $i <= 48 ; $i++) { ?>
				<th style="color: green;font-weight: bolder;font-style: italic;"><?=$tot_act_week[$i]?></th>
			<?php }
			 ?>
</tr>
			
		</tr>
 </tbody>
       </table>
</div>
</div>
</div>
      </div>  
     </div>  
    </div>  
   </div>  
  </div>  
 </div>
 </div>
    <script src="/iotmtc/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="/iotmtc/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <!-- <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.min.js"></script> -->
  <!-- <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.css"></script> -->
  <script src="/iotmtc/weld/cs_prev/dist/js/init.js"></script>
</body>
</html>