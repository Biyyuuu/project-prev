<?php
include '../koneksi.php';
$no_check_ambil = $_GET['no_check'];  

$hasili = pg_query($koneksi,"SELECT periode FROM dbmaintenance_assy.tb_aktualprev WHERE no_check = '$no_check_ambil'");
  while ($row = pg_fetch_array($hasili)) {
    $periode = $row['periode'];
  }

  if($periode == '1M' ){
    include '1m.php';
  }elseif($periode == '3M' ){
    include '3m.php';
  }elseif($periode == '6M' ){
    include '6m.php';
  }elseif($periode == '1Y' ){
    include '1y.php';
  }
?>