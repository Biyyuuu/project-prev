<?php
include '../koneksi.php';
echo '-';

$waktu_indonesia = time() + (60 * 60 * 7);
$tanggal = gmdate('Y-m-d', $waktu_indonesia);
$bulan = gmdate('m', $waktu_indonesia);
$tahun = gmdate('Y-m', $waktu_indonesia);
$tahunan = gmdate('Y', $waktu_indonesia);
$hari = gmdate('D', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////
$shop_assy1 = $_GET['shop'];

if ($shop_assy1 == 'BE') {
  $shop_assy = 'BE';
  $line_assy = 'F';
} elseif ($shop_assy1 == 'bdc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'C';
} elseif ($shop_assy1 == 'bdd') {
  $shop_assy = 'Body Assy';
  $line_assy = 'D';
} elseif ($shop_assy1 == 'bde') {
  $shop_assy = 'Body Assy';
  $line_assy = 'E';
} elseif ($shop_assy1 == 'egl') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'L';
} elseif ($shop_assy1 == 'egg') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'G';
} elseif ($shop_assy1 == 'egc') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'C';
} elseif ($shop_assy1 == 'egd') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'D';
} elseif ($shop_assy1 == 'ege') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'E';
} elseif ($shop_assy1 == 'spoke') {
  $shop_assy = 'Body Assy';
  $line_assy = 'Spoke';
} elseif ($shop_assy1 == 'pckd') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CKD';
} elseif ($shop_assy1 == 'pcbu') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CBU';
} elseif ($shop_assy1 == 'pcbe') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.B/E';
} elseif ($shop_assy1 == 'lc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'LC LINE';
} elseif ($shop_assy1 == 'gtc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'GTC';
}


if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
} else {
  $bulancari = $tahun;
}
$blnx[1] = '01';
$blnx[2] = '02';
$blnx[3] = '03';
$blnx[4] = '04';
$blnx[5] = '05';
$blnx[6] = '06';
$blnx[7] = '07';
$blnx[8] = '08';
$blnx[9] = '09';
$blnx[10] = '10';
$blnx[11] = '11';
$blnx[12] = '12';
for ($t = 13; $t <= 31; $t++) {
  $blnx[$t] = $t;
}
$blnz = substr($bulancari, 5, 7);
$thnz = substr($bulancari, 0, 4);
$con_id = pg_query($koneksi, "SELECT COUNT(id) as jumlah_id FROM dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' AND shop = '$shop_assy' AND line = '$line_assy'  ");
while ($row = pg_fetch_array($con_id)) {
  $jml_id = $row['jumlah_id'];
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere = 0;
$panggil_db = pg_query($koneksi, "SELECT bagian,mesin,jml_mesin,jml_item,periode From dbmaintenance_assy.tb_planing where extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' and shop = '$shop_assy' AND line = '$line_assy' ");
while ($row = pg_fetch_array($panggil_db)) {
  $erere++;
  $bagian[$erere] = $row['bagian'];
  $mesin[$erere] = $row['mesin'];
  $jml_mesin[$erere] = $row['jml_mesin'];
  $jml_item[$erere] = $row['jml_item'];
  $periode[$erere] = $row['periode'];
  if ($periode[$erere] == '1M') {
    $periodeni[$erere] = 'Bulanan';
  } elseif ($periode[$erere] == '3M') {
    $periodeni[$erere] = '3 Bulanan';
  } elseif ($periode[$erere] == '6M') {
    $periodeni[$erere] = '6 Bulanan';
  } elseif ($periode[$erere] == '1Y') {
    $periodeni[$erere] = '1 Tahunan';
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Plan
for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_cek FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND jml_mesin = '$jml_mesin[$j]' AND extract(month from tgl_plan) = '$blnz' AND extract(day from tgl_plan) = '$blnx[$k]'  AND extract(year from tgl_plan) = '$thnz' ");
    while ($row = pg_fetch_array($hasil)) {
      $tot_plan_cek[$k][$j] = $row['tot_plan_cek'];
    }
  }
}


for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_sat FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND extract(month from tgl_plan) = '$blnz' AND mesin = '$mesin[$j]' AND extract(year from tgl_plan) = '$thnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_sat[$j] = $row['tot_plan_sat'];
  }
}

for ($k = 1; $k <= 31; $k++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_aktual_bln FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND extract(month from tgl_plan) = '$blnz' AND extract(day from tgl_plan) = '$blnx[$k]'  AND extract(year from tgl_plan) = '$thnz' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_aktual_bln[$k] = $row['tot_aktual_bln'];
  }
}
for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT line,jml_item,periode,no_check FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND mesin = '$mesin[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND periode = '$periode[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' ");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan[$k][$j] = $row['line'];
      $no_check_plan[$k][$j] = $row['no_check'];
      $periode_plan[$k][$j] = $row['periode'];
      $jml_item_plan[$k][$j] = $row['jml_item'];
    }
  }
}

for ($j = 1; $j <= 31; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND extract(day from tgl_plan) = '$blnx[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan[$j] = $row['tot_plan'];
  }
}
for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_act FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND mesin = '$mesin[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_acto[$j] = $row['tot_act'];
  }
}

$hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_tot FROM dbmaintenance_assy.tb_planing WHERE extract(month from tgl_plan) = '$blnz' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_plan_tot = $row['tot_plan_tot'];
}

$hasil = pg_query($koneksi, "SELECT count(id) as tot_actoti FROM dbmaintenance_assy.tb_aktualprev WHERE extract(month from tgl_plan) = '$blnz' AND  extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_actoti = $row['tot_actoti'];
}
///Aktual

for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT line,periode,no_check,hasil FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND mesin = '$mesin[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND periode = '$periode[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' ");
    while ($row = pg_fetch_array($hasili)) {
      $hasil_aktual[$k][$j] = $row['hasil'];
      $line_aktual[$k][$j] = $row['line'];
      $no_check_aktual[$k][$j] = $row['no_check'];
      $periode_aktual[$k][$j] = $row['periode'];
    }
  }
}

$hasil = pg_query($koneksi, "SELECT count(jml_mesin) as tot_mesin_bln FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_mesin_bln = $row['tot_mesin_bln'];
}

$hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_item_bln FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_item_bln = $row['tot_item_bln'];
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(id) as tot_aktual FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND periode = '$periode[$j]' AND mesin = '$mesin[$j]' AND extract(month from tgl_plan) = '$blnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_aktual[$k][$j] = $row['tot_aktual'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $jml = pg_query($koneksi, "SELECT count(id) as jumlah_itemnya FROM dbmaintenance_assy.itemcs_bd where shop = '$shop_assy' AND mesin ='$mesin[$j]' AND periode = '$periode[$j]' ");
  while ($row = pg_fetch_array($jml)) {
    $jumlah_itemnya[$j] = $row['jumlah_itemnya'];
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
