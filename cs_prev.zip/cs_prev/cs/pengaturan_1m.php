<?php
include 'koneksi.php';

 $waktu_indonesia = time() + (60 * 60 * 7);
 $tanggal = gmdate('Y-m-d', $waktu_indonesia);
 $bulan = gmdate('m', $waktu_indonesia);
 $tahun = gmdate('Y-m', $waktu_indonesia);
 $tahunan = gmdate('Y', $waktu_indonesia);
 $jumlah_kolom = 400;
 $tgl_sekarang = '2021-03-30';
for ($trim = 1; $trim <= $jumlah_kolom; $trim++) { 
 $item_cek[$trim] = "";
}
// if ($cari_idiop != NULL) {
//   $cari_id = $cari_idiop;
// }elseif ($cari_pk != NULL) {
//   $cari_id = $cari_pk;
// }

////////////////////////////////////////////////////////////////////////////////////////////////////////////

 if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
  }
  else{
  $bulancari = $tahun;
  }
    $blnx[1] = '01';
    $blnx[2] = '02';
    $blnx[3] = '03';
    $blnx[4] = '04';
    $blnx[5] = '05';
    $blnx[6] = '06';
    $blnx[7] = '07';
    $blnx[8] = '08';
    $blnx[9] = '09';
    $blnx[10]= '10';
    $blnx[11]= '11';
    $blnx[12]= '12';
    $blnz = substr($bulancari,5);
    $thnz = substr($bulancari,0,4);
    
    switch ($_GET['kirim']){
      case 'id':
          $cari_id = $_GET['id'];  

          $cariin_events  =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.events_weld WHERE id ='$cari_id'");
          $wtfu           =pg_fetch_array($cariin_events);
          $mesinin       = $wtfu['mesin'];
          $no_mesinin  = $wtfu['no_mesin'];
          $shopee      = $wtfu['shop'];
          $linee       = $wtfu['line'];
          $periodee    = $wtfu['periode'];
          $modelin     = $wtfu['model'];
          $code_shopee   = $wtfu['code_shop'];
          $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin3 WHERE code_shop ='$code_shopee'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $shopi      = $wtfk['shop'];

          $con_id = pg_query($koneksi, "SELECT COUNT(DISTINCT CONCAT(metode, unit, item_cek, standart)) as jumlah_id FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' ");
          while ($row = pg_fetch_array($con_id)) {
            $jml_id = $row['jumlah_id'];
          }
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere=0;
  $panggil_db = pg_query($koneksi,"SELECT DISTINCT metode, unit, item_cek, standart From dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
  while ($row = pg_fetch_array($panggil_db)) {
  $erere++;
  $item_cek[$erere] = $row['item_cek'];
  $unit_p[$erere] = $row['unit'];
  $standart[$erere] = $row['standart'];
  $metode[$erere] = $row['metode'];
  }
for ($k=1;$k <= 12; $k++){  
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $pk_mesin[$k][$j] = $row['pk_mesin'];
  }
}
}
for ($k=1;$k <= 12; $k++){
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $aktual_img[$k][$j] = $row['hasil'];
  }
}
}

      break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
      case 'dudu':
          $cari_pki = $_GET['pk_mesin'];
          $cariin_record =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE pk_mesin ='$cari_pki'");
          $wtf    =pg_fetch_array($cariin_record);
          $mesinin = $wtf['nama_mesin'];
          $no_mesinin = $wtf['no_mesin'];
          $linee    = $wtf['line'];
          $periodee = $wtf['periode'];
          $modelin = $wtf['model'];
          $code_shopee   = $wtf['code_shop'];
          $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin3 WHERE code_shop ='$code_shopee'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $shopi      = $wtfk['shop'];

          $con_id = pg_query($koneksi, "SELECT COUNT(DISTINCT CONCAT(metode, unit, item_cek, standart)) as jumlah_id FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' ");
          while ($row = pg_fetch_array($con_id)) {
            $jml_id = $row['jumlah_id'];
          }
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere=0;
$panggil_db = pg_query($koneksi,"SELECT DISTINCT metode, unit, item_cek, standart From dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
while ($row = pg_fetch_array($panggil_db)) {
$erere++;
$item_cek[$erere] = $row['item_cek'];
$unit_p[$erere] = $row['unit'];
$standart[$erere] = $row['standart'];
$metode[$erere] = $row['metode'];
}
  ///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
for ($k=1;$k <= 12; $k++){  
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $pk_mesin[$k][$j] = $row['pk_mesin'];
  }
}
}

for ($k=1;$k <= 12; $k++){
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $aktual_img[$k][$j] = $row['hasil'];
  }
}
}

      break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
      case 'un_key':
        $cari_un_key = $_GET['un_key'];

        $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.unfinishprev_weld WHERE un_key ='$cari_un_key'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $mesinin      = $wtfk['mesin'];
  $no_mesinin = $wtfk['no_mesin'];
  $linee      = $wtfk['line'];
  $periodee   = $wtfk['periode'];
  $code_shopee  = $wtfk['code_shop'];
  $pk_mesin_unkey   = $wtfk['pk_mesin'];
  $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin3 WHERE code_shop ='$code_shopee'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $shopi      = $wtfk['shop'];

  $con_id = pg_query($koneksi, "SELECT COUNT(DISTINCT CONCAT(metode, unit, item_cek, standart)) as jumlah_id FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' ");
          while ($row = pg_fetch_array($con_id)) {
            $jml_id = $row['jumlah_id'];
          }
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere=0;
  $panggil_db = pg_query($koneksi,"SELECT DISTINCT metode, unit, item_cek, standart From dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
  while ($row = pg_fetch_array($panggil_db)) {
  $erere++;
  $item_cek[$erere] = $row['item_cek'];
  $unit_p[$erere] = $row['unit'];
  $standart[$erere] = $row['standart'];
  $metode[$erere] = $row['metode'];
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
for ($k=1;$k <= 12; $k++){  
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $pk_mesin[$k][$j] = $row['pk_mesin'];
  }
}
}
//////////////////////////////////////////////////////////////
for ($k=1;$k <= 12; $k++){
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $aktual_img[$k][$j] = $row['hasil'];
  }
}
}
      break;
      //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
      case 'un_keyi':
        $cari_un_key = $_GET['un_keyi'];
        $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.kontrol WHERE un_key ='$cari_un_key'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $mesinin      = $wtfk['mesin'];
  $no_mesinin = $wtfk['no_mesin'];
  $linee      = $wtfk['line'];
  $periodee   = $wtfk['periode'];
  $code_shopee  = $wtfk['code_shop'];

  $cariin_unfinish =pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin3 WHERE code_shop ='$code_shopee'");
  $wtfk    =pg_fetch_array($cariin_unfinish);
  $shopi      = $wtfk['shop'];

  $cariin_o =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE mesin ='$mesinin' AND no_mesin = '$no_mesinin' AND periode = '$periodee' order by unit asc ");
  $wtfkbtch    =pg_fetch_array($cariin_o);
  $modelin      = $wtfkbtch['model'];

  $con_id = pg_query($koneksi, "SELECT COUNT(DISTINCT CONCAT(metode, unit, item_cek, standart)) as jumlah_id FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' ");
while ($row = pg_fetch_array($con_id)) {
  $jml_id = $row['jumlah_id'];
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere=0;
  $panggil_db = pg_query($koneksi,"SELECT DISTINCT metode, unit, item_cek, standart From dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(year from tgl_key) = '$thnz' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
  while ($row = pg_fetch_array($panggil_db)) {
  $erere++;
  $item_cek[$erere] = $row['item_cek'];
  $unit_p[$erere] = $row['unit'];
  $standart[$erere] = $row['standart'];
  $metode[$erere] = $row['metode'];
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
for ($k=1;$k <= 12; $k++){  
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $pk_mesin[$k][$j] = $row['pk_mesin'];
  }
}
}
for ($k=1;$k <= 12; $k++){
  for($j=1;$j<=$jml_id;$j++){
    $panggil_data = pg_query($koneksi,"SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE periode = '1M' AND extract(month from tgl_key) = '$blnx[$k]' AND extract(year from tgl_key) = '$thnz' AND item_cek = '$item_cek[$j]' AND mesin = '$mesinin' AND no_mesin = '$no_mesinin' order by unit asc ");
    while ($row = pg_fetch_array($panggil_data)) {
    $aktual_img[$k][$j] = $row['hasil'];
  }
}
}
      break;
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>
