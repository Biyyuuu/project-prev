
<?php
include 'koneksi.php';
include 'pengaturan_1y.php';
include 'pengaturan_work_time.php';
  
$tanggal=gmdate('d-m-y', $waktu_indonesia);
error_reporting(0);

echo $thnz;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="../../../../vendors/bower_components/bootstrap-table/dist/bootstrap-table.css" rel="stylesheet" type="text/css"/>
  <link href="../../dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>

<body>
     <div class="wrapper theme-1-active pimary-color-blue">
      <h1 style="text-align:center; font-size: x-large;">PREVENTIVE MAINTENANCE WELDING</h1>
    <h5 style="text-align:center;  font-size: x-large;">(<?=$thnz?>)</h5>
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
   <br/>
<table style="float:right; margin-right:30px; margin-top:-20px;font-weight: bold; padding:10px;">
                <tr>
          <td style="text-align:left; color: black;">O :</td>
          <td style="text-align:left; color: black;">OK</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">X :</td>
          <td style="text-align:left; color: black;">NG</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">B :</td>
          <td style="text-align:left; color: black;">Penggantian</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">C :</td>
          <td style="text-align:left; color: black;">Cleaning</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">R :</td>
          <td style="text-align:left; color: black;">Repair</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">- :</td>
          <td style="text-align:left; color: black;">Tidak Ada Item Preventive </td>
        </tr>
    </table>
    <table>
        <tr>
          <th style="text-align:left; color: black;">Shop</th>
          <th style="text-align:left; color: black;"> : <?=$shopi?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Line </th>
          <th style="text-align:left; color: black;"> : <?=$linee?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Nama Mesin </th>
          <th style="text-align:left; color: black;"> : <?=$mesinin?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Model</th>
          <th style="text-align:left; color: black;">: <?=$modelin?></th>
        </tr>  
          <th style="text-align:left; color: black;">No Mesin</th>
          <th style="text-align:left; color: black;">: <?=$no_mesinin?></th>
        <tr> 
          <th style="text-align:left; color: black;">Periode</th>
          <th style="text-align:left; color: black;">: 1 Years</th>
        </tr>
    </table>
</div>
                    <table data-toggle="table">
                      <thead>
                        <tr>
                          <tr>

           <th rowspan="2">No</th>
           <th rowspan="2">Unit</th>
           <th rowspan="2" style="text-align: center;">Item Check</th>
           <th rowspan="2" style="text-align: center;">Standart</th>
           <th rowspan="2" style="text-align: center;">Metode</th>
           <th colspan="1" style="text-align: center;"> <?= $namabulan ?> <?=$thnz ?> </th>   
    </tr>
    <tr>
          <th rowspan="2" style="text-align: center;">1 </th>
        </tr>
      </tr>
    </thead>
  <tbody>
<?php
$z=1;
echo $tahun_cari;
  for ($i=1; $i <= $jml_id ; $i++){
?>

    <tr class="tr2">
      <td align="center"> <?= $z++ ?> </td> 
      <td align="center" style="text-align: left;"><a href=""> <?= $unit_p[$i] ?></a></td>
      <td align="center" style="text-align: left;"><a href=""><?= $item_cek[$i] ?></a></td>
      <td align="center" style="text-align: left;"><a href=""><?=$standart[$i]?></a> </td> 
      <td align="center" style="text-align: left;"><a href=""> <?=$metode[$i]?> </a> </td>

<td><a href="form_ubah.php?pk_mesin=<?= $pk_mesin[$i]?>"><?= $aktual_img[$i] ?></a></td>

<?php
}
?>
  </tr>
 </tbody>
       </table>
       <?php
       if($cari_pki !== NULL ){?>
        <h1 ><a href="ekspor-1y.php?kirim=dudu&pk_mesin=<?= $cari_pki ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_un_keyi !== NULL){?>
        <h1 ><a href="ekspor-1y.php?kirim=un_keyi&un_keyi=<?= $cari_un_keyi ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_id !== NULL){?>
        <h1 ><a href="ekspor-1y.php?kirim=id&id=<?= $cari_id ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_un_key !== NULL){?>
        <h1 ><a href="ekspor-1y.php?kirim=un_key&un_key=<?= $cari_un_key ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }
       ?>
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>
 </div>
    <script src="../../../../vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="../../../../vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../../../../vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="../../../../vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <script src="../../../../vendors/bower_components/switchery/dist/switchery.min.js"></script>
  <script src="../../dist/js/init.js"></script>
   <script>
    $(document).ready(function(){

     $('#insert_form').on("submit", function(event){  
      event.preventDefault();  
      if($('#nama').val() == "")  
      {  
       alert("Mohon Isi Nama ");  
      }  
      else if($('#alamat').val() == '')  
      {  
       alert("Mohon Isi Alamat");  
      }  
      else
      {  
       $.ajax({  
        url:"insert.php",  
        method:"POST",  
        data:$('#insert_form').serialize(),  
        beforeSend:function(){  
         $('#insert').val("Inserting");  
        },  
        success:function(data){  
         $('#insert_form')[0].reset();  
         $('#add_data_Modal').modal('hide');  
         $('#tabel-pegawai').html(data);  
        }  
       });  
      }  
     });

     $(document).on('click', '.view_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"select.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
        $('#detail_karyawan').html(data);
        $('#dataModal').modal('show');
       }
      });
     });

      $(document).on('click', '.edit_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"edit.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
        $('#form_edit').html(data);
        $('#editModal').modal('show');
       }
      });
     });

     $(document).on('click', '.hapus_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"delete.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
       $('#tabel-pegawai').html(data);  
       }
      });
     });
    }); 

</script>
  
</body>

</html>
