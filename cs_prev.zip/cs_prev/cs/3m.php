
<?php
include 'koneksi.php';
include 'pengaturan_3m.php';
include 'pengaturan_work_time.php';
//error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/bootstrap-table/dist/bootstrap-table.css" rel="stylesheet" type="text/css"/>
  <link href="/iotmtc/weld/cs_prev/dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>


     

<body>
  
    <div class="wrapper theme-1-active pimary-color-blue">
      <h1 style="text-align:center; font-size: x-large;">PREVENTIVE MAINTENANCE WELDING</h1>
    <h5 style="text-align:center;  font-size: x-large;">(<?=$thnz?>)</h5>
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
   <br/>
   
    <table style="float:right; margin-right:30px; margin-top:-20px;font-weight: bold; padding:10px;">
                <tr>
          <td style="text-align:left; color: black;">O :</td>
          <td style="text-align:left; color: black;">OK</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">X :</td>
          <td style="text-align:left; color: black;">NG</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">B :</td>
          <td style="text-align:left; color: black;">Penggantian</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">C :</td>
          <td style="text-align:left; color: black;">Cleaning</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">R :</td>
          <td style="text-align:left; color: black;">Repair</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">- :</td>
          <td style="text-align:left; color: black;">Tidak Ada Item Preventive </td>
        </tr>
    </table>
    <table>
        <tr>
          <th style="text-align:left; color: black;">Shop</th>
          <th style="text-align:left; color: black;"> : <?=$shopi?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Line </th>
          <th style="text-align:left; color: black;"> : <?=$linee?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Nama Mesin </th>
          <th style="text-align:left; color: black;"> : <?=$mesinin?> </th>
        </tr>
        <tr>
          <th style="text-align:left; color: black;">Model</th>
          <th style="text-align:left; color: black;">: <?=$modelin?></th>
        </tr>  
          <th style="text-align:left; color: black;">No Mesin</th>
          <th style="text-align:left; color: black;">: <?=$no_mesinin?></th>
        <tr> 
          <th style="text-align:left; color: black;">Periode</th>
          <th style="text-align:left; color: black;">: 3 Month</th>
        </tr>
    </table>
</div>
                    <table data-toggle="table">
                      <thead>
                        <tr>
                          <tr>

           <th rowspan="2">No</th>
           <th rowspan="2">Unit</th>
           <th rowspan="2" style="text-align: center;">Item Check</th>
           <th rowspan="2" style="text-align: center;">Standart</th>
           <th rowspan="2" style="text-align: center;">Metode</th>
           <th colspan="31" style="text-align: center;"> <?= $namabulan ?> <?=$thnz ?> </th>   
    </tr>
    <tr>
          <th rowspan="2" style="text-align: center;">1 </th>  
          <th rowspan="2" style="text-align: center;">2 </th>
          <th rowspan="2" style="text-align: center;">3 </th>
          <th rowspan="2" style="text-align: center;">4 </th>
        </tr>
      </tr>
    </thead>
  <tbody>
<?php
$z=1;
echo $tahun_cari;
  for ($i=1; $i <= $jml_id ; $i++){
?>

    <tr class="tr2">
      <td align="center"> <?= $z++ ?> </td> 
      <td align="center" style="text-align: left;"><a href=""> <?= $unit_p[$i] ?></a></td>
      <td align="center" style="text-align: left;"><a href=""><?= $item_cek[$i] ?></a></td>
      <td align="center" style="text-align: left;"><a href=""><?=$standart[$i]?></a> </td> 
      <td align="center" style="text-align: left;"><a href=""> <?=$metode[$i]?> </a> </td>
<?php 
for($x=1;$x<=4;$x++){
?>

<td><a href="form_ubah.php?pk_mesin=<?= $pk_mesin[$x][$i]?>"><?= $aktual_img[$x][$i] ?></a></td>

<?php
}}
?>

  </tr>
 </tbody>
       </table>
       <?php
       if($cari_pki !== NULL ){?>
        <h1 ><a href="ekspor-3m.php?kirim=dudu&pk_mesin=<?= $cari_pki ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_un_keyi !== NULL){?>
        <h1 ><a href="ekspor-3m.php?kirim=un_keyi&un_keyi=<?= $cari_un_keyi ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_id !== NULL){?>
        <h1 ><a href="ekspor-3m.php?kirim=id&id=<?= $cari_id ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }elseif($cari_un_key !== NULL){?>
        <h1 ><a href="ekspor-3m.php?kirim=un_key&un_key=<?= $cari_un_key ?>" role="button"><i style="color:green;" class="fa fa-file-excel-o" aria-hidden="true"></i></a></h1>
        <?php
       }
       ?>
       
       <h6>Download To Excel</h6>
      </div>  
     </div>  
    </div>  
   </div>  
  </div>  
 </div>
 </div>
    <script src="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <script src="/iotmtc/weld/cs_prev/kontrol/vendors/bower_components/switchery/dist/switchery.min.js"></script>
  <!-- <script src="/iotmtc/weld/cs_prev/kontrol/dist/js/init.js"></script> -->
  
</body>

</html>
