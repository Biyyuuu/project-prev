<?php
include 'koneksi.php';

 $waktu_indonesia = time() + (60 * 60 * 7);
 $tanggal = gmdate('Y-m-d', $waktu_indonesia);
 $bulan = gmdate('m', $waktu_indonesia);
 $tahun = gmdate('Y-m', $waktu_indonesia);
 $tahunan = gmdate('Y', $waktu_indonesia);
switch ($_GET['kirim']) {
    case 'id':
        $cari_id = $_GET['id'];
        
        $cariin =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.events_weld WHERE id ='$cari_id'");
        $wtf    =pg_fetch_array($cariin);
        $mesinin = $wtf['mesin'];
        $no_mesinin = $wtf['no_mesin'];
        $shopee   = $wtf['shop'];
        $linee    = $wtf['line'];
        $periodee = $wtf['periode'];

  if($periodee == "1M"){
        $cek_periode = include '1m.php';
    }
    elseif ($periodee == "1Y"){
        $cek_periode = include '1y.php';
    }
    elseif($periodee == "3M"){
        $cek_periode = include '3m.php';
    }
    elseif($periodee == "6M"){
        $cek_periode = include '6m.php';
    }
    elseif($periodee == "Daily"){
        $cek_periode = include 'dailyin.php';
    }
    else{
        $cek_periode="";
    }
    break;

    case 'dudu':
       $cari_pki = $_GET['pk_mesin'];
       //echo 'aaa';

        $cariinpk=pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.tbrecprev_weld WHERE pk_mesin ='$cari_pki'");
        $wtfu=pg_fetch_array($cariinpk);
        $mesinin_pk = $wtfu['mesin'];
        $no_mesinin_pk = $wtfu['no_mesin'];
        $shopee_pk   = $wtfu['code_shop'];
        $linee_pk    = $wtfu['line'];
        $periodee_pk = $wtfu['periode'];

  if($periodee_pk == "1M"){
        $cek_periode_pk = include '1m.php';
    }
    elseif ($periodee_pk == "1Y"){
        $cek_periode_pk = include '1y.php';
    }
    elseif($periodee_pk == "3M"){
        $cek_periode_pk = include '3m.php';
    }
    elseif($periodee_pk == "6M"){
        $cek_periode_pk = include '6m.php';
    }
    elseif($periodee_pk == "Daily"){
        $cek_periode_pk = include 'dailyin.php';
    }
    else{
        $cek_periode_pk ="";
    }
    break;

    case 'un_key':
        $panggil_check11 = $_GET['un_key'];
        $cari_ident =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.unfinishprev_weld WHERE un_key ='$panggil_check11'");
  $bawah =pg_fetch_array($cari_ident);
  $pk_mesin_unfinish = $bawah['pk_mesin'];
  $mesinin_pk = $bawah['mesin'];
  $no_mesinin_pk = $bawah['no_mesin'];
  $shopee_pk   = $bawah['code_shop'];
  $linee_pk    = $bawah['line'];
  $periodee_pk = $bawah['periode'];
  if($periodee_pk == "1M"){
    $cek_periode_pk = include '1m.php';
}
elseif ($periodee_pk == "1Y"){
    $cek_periode_pk = include '1y.php';
}
elseif($periodee_pk == "3M"){
    $cek_periode_pk = include '3m.php';
}
elseif($periodee_pk == "6M"){
    $cek_periode_pk = include '6m.php';
}
elseif($periodee_pk == "Daily"){
    $cek_periode_pk = include 'dailyin.php';
}
else{
    $cek_periode_pk ="";
}
    break;

    case 'un_keyi':
        $panggil_check11 = $_GET['un_keyi'];
        $cari_ident =pg_query($koneksi, "SELECT * FROM dbmaintenance_weld.kontrol WHERE un_key ='$panggil_check11'");
  $bawah =pg_fetch_array($cari_ident);
  $periodee_pk = $bawah['periode'];
  if($periodee_pk == "1M"){
    $cek_periode_pk = include '1m.php';
}
elseif ($periodee_pk == "1Y"){
    $cek_periode_pk = include '1y.php';
}
elseif($periodee_pk == "3M"){
    $cek_periode_pk = include '3m.php';
}
elseif($periodee_pk == "6M"){
    $cek_periode_pk = include '6m.php';
}
elseif($periodee_pk == "Daily"){
    $cek_periode_pk = include 'dailyin.php';
}
else{
    $cek_periode_pk ="";
}
    break;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>