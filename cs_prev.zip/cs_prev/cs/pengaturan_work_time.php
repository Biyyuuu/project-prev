<?php 
ini_set("display_errors",0);

  $waktu_indonesia = time() + (60 * 60 * 7);
  $jam_internal = gmdate('H:i:s', $waktu_indonesia);
  $tanggal_key = gmdate('Ymd', $waktu_indonesia);
  $tanggal_absensi=gmdate(', d/m/Y  H:i:s', $waktu_indonesia);
  $tanggal = gmdate('Y-m-d', $waktu_indonesia);
  $tgl = gmdate('d', $waktu_indonesia);
  $hari=gmdate('D', $waktu_indonesia);
  
  switch ($hari) {
    case 'Mon':
      $hari = 'Senin';
      break;
    
    case 'Tue':
      $hari = 'Selasa';
      break;

    case 'Wed':
      $hari = 'Rabu';
      break;

    case 'Thu':
      $hari = 'Kamis';
      break;  

    case 'Fri':
      $hari = 'Jumat';
      break;    

    case 'Sat':
      $hari = 'Sabtu';
      break;  

    case 'Sun':
      $hari = 'Minggu';
      break;  
  }
  $bln = gmdate('M', $waktu_indonesia);
      switch ($bln) {
      case 'Januari':
        $bln = 'Januari';
        break;
      case 'Februari':
        $bln = 'Februari';
        break;
      case 'Mar':
        $bln = 'Maret';
        break;
      case 'Apr':
        $bln = 'April';
        break;
      case 'May':
        $bln = 'Mei';
        break;
      case 'Jun':
        $bln = 'Juni';
        break;
      case 'Jul':
        $bln = 'Juli';
        break;
      case 'Aug':
        $bln = 'Agustus';
        break;
       case 'Sep':
        $bln = 'September';
        break;
        case 'Oct':
        $bln = 'Oktober';
        break;
        case 'Nov':
        $bln = 'November';
        break;
        case 'Dec':
        $bln = 'Desember';
        break;   
     } 
  $thn = gmdate('Y', $waktu_indonesia);
  $tanggal_plus = date('Y-m-d',strtotime($tanggal.'+1 days'));
  $bulan = gmdate('Y-m', $waktu_indonesia);
  $nama_bulan = gmdate('M-Y', $waktu_indonesia);
  $nama_tgl = gmdate('d-m-y', $waktu_indonesia);
  $tahun = gmdate('Y', $waktu_indonesia);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>
       