<?php

include '../../koneksi.php';
if (!empty($_POST)) {
    $output = '';
    $hasil_sdh = $_POST['hasil_sdh'];
    $ket_sdh = $_POST['ket_sdh'];
    $tgl_sdh = $_POST['tgl_sdh'];
    $query = "
        UPDATE dbmaintenance_assy.aktual_cs SET hasil_sdh= '$hasil_sdh',ket_sdh = '$ket_sdh',tgl_sdh = '$tgl_sdh' WHERE id = '$_POST[id]'
        ";
    pg_query($koneksi, $query);
    echo $output;
}
