<script>
  $('#update_form').on("submit", function(event) {
    event.preventDefault();
    if ($('#eitem').val() == "") {
      alert("Mohon Isi Item ");
    } else if ($('#edate').val() == '') {
      alert("Mohon Isi Tanggal");
    } else {
      $.ajax({
        url: "update.php",
        method: "POST",
        data: $('#update_form').serialize(),
        beforeSend: function() {
          $('#update').val("Updating");
        },
        success: function(data) {
          $('#update_form')[0].reset();
          $('#editModal').modal('hide');
          $('#employee_table').html(data);
        }
      });
    }
  });
</script>
<?php
if (isset($_POST["employee_id"])) {
  include '../../koneksi.php';
  $output = '';
  $query = "SELECT * FROM dbmaintenance_assy.aktual_cs WHERE id = '" . $_POST["employee_id"] . "'";
  $result = pg_query($koneksi, $query);
  $row = pg_fetch_array($result);
  $output .= '
     <div class="modal-body">
     <form  method="post" id="update_form">
     <div class="modal-body">
     <div class="row g-3">
        <div class="col-md-6">
         <label class="col-form-label" for="recipient-name" readonly>Tanggal Temuan:</label>
         <input class="form-control" id="edate" type="date" name="tanggal" value="' . $row["tanggal"] . '" readonly>
       </div>
       <div class="col-md-6">
         <label class="col-form-label" for="recipient-name">Tanggal Perbaikan:</label>
         <input class="form-control" type="date" name="tgl_sdh" >
       </div>
      </div>
      <div class="row g-3">
       <div class="col-md-3">
         <label class="col-form-label" for="recipient-name">Shop:</label>
         <input class="form-control" type="text" name="shop" value="' . $row["shop"] . '" readonly>
       </div>
       <div class="col-md-2">
         <label class="col-form-label" for="recipient-name">Line:</label>
         <input class="form-control" type="text" name="line" value="' . $row["line"] . '" readonly>
       </div>
       <div class="col-md-4">
         <label class="col-form-label" for="recipient-name">Mesin:</label>
         <input class="form-control" type="text" name="mesin" value="'.$row["mesin"] . '" readonly>
       </div>
       <div class="col-md-3">
        <label class="col-form-label" for="recipient-name">No Mesin:</label>
        <input class="form-control" type="text" name="no_mesin" value="' . $row["no_mesin"] . '" readonly>
       </div>
       
       </div>
      <div class="row g-3">
      <div class="col-md-6">
       <input type="hidden" name="id" id="id" value="' . $_POST["employee_id"] . '" class="form-control" />
         <label class="col-form-label"  for="recipient-name">Unit:</label>
         <textarea class="form-control" value=' . $row["unit"] . ' name="unit" style="height:50px" readonly>' . $row["unit"] . ' </textarea>
       </div>
       <div class="col-md-6">
         <label class="col-form-label" for="recipient-name">Standart:</label>
         <textarea class="form-control" value=' . $row["standart"] . ' name="standart" style="height:50px" readonly>' . $row["standart"] . ' </textarea>
       </div>
       
       </div>
       <div class="row g-10">
       <div class="col-md-4">
         <label class="col-form-label" for="recipient-name">Metode:</label>
         <textarea class="form-control" value=' . $row["metode"] . ' name="metode" style="height:50px" readonly>' . $row["metode"] . ' </textarea>
       </div>
       <div class="col-md-6">
         <label class="col-form-label" for="recipient-name">Item Check:</label>
         <textarea class="form-control" value=' . $row["item_check"] . ' name="item_check" style="height:50px" readonly>' . $row["item_check"] . ' </textarea>
       </div>
       
       <div class="col-md-2">
       <label class="col-form-label" for="recipient-name">Periode:</label>
       <input class="form-control" type="text" name="periode" style="height:50px" value="' . $row["periode"] . '" readonly>
     </div>
      </div>
      
      <div class="row g-3">
      <div class="col-md-3">
         <label class="col-form-label" for="recipient-name">Hasil Temuan:</label>
       <input class="form-control" type="text" name="hasil" style="height:50px" value="' . $row["hasil"] . '" readonly>
       </div>
       <div class="col-md-9">
         <label class="col-form-label" for="recipient-name">Keterangan Temuan:</label>
         <textarea class="form-control" value=' . $row["ket_sblm"] . ' name="ket_sblm" style="height:50px" readonly>' . $row["ket_sblm"] . ' </textarea>
       </div>
       </div>

       <div class="row g-3">
      <div class="col-md-3">
         <label class="col-form-label" for="recipient-name">Hasil Perbaikan:</label>
         <select class="form-control" style="height:50px" name="hasil_sdh">
					<option value=""></option>
					<option value="O">O</option>
					<option value="X">X</option>
					<option value="R">R</option>
					<option value="B">B</option>
					<option value="C">C</option>
				</select>
       </div>
       <div class="col-md-9">
         <label class="col-form-label" for="recipient-name">Keterangan Perbaikan:</label>
         <textarea class="form-control" name="ket_sdh" style="height:50px"></textarea>
       </div>
       </div>

       </div>
       <div class="modal-footer">
	          <input name="edit" class="btn btn-info btn-submit" type="submit" value="Edit">
            <button type="button" class="btn btn-secondary btn-reset" data-dismiss="modal">Batal</button>
        </div>
     </form>
   </div>
     ';
  echo $output;
}
?>