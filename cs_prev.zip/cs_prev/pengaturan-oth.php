<?php
include '../koneksi.php';

 $waktu_indonesia = time() + (60 * 60 * 7);
 $tanggal = gmdate('Y-m-d', $waktu_indonesia);
 $bulan = gmdate('m', $waktu_indonesia);
 $tahun = gmdate('Y-m', $waktu_indonesia);
 $tahunan = gmdate('Y', $waktu_indonesia);
 $hari = gmdate('D', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////
$shop_assy1 = $_GET['shop'];

if($shop_assy1 == 'spoke'){
  $shop_assy = 'Body Assy';
  $line_assy = 'Spoke';
}elseif($shop_assy1 == 'pckd'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CKD';
}elseif($shop_assy1 == 'pcbu'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CBU';
}elseif($shop_assy1 == 'pcbe'){
  $shop_assy = 'Body Assy';
  $line_assy = 'P.B/E';
}elseif($shop_assy1 == 'lc'){
  $shop_assy = 'Body Assy';
  $line_assy = 'LC LINE';
}elseif($shop_assy1 == 'gtc'){
  $shop_assy = 'Body Assy';
  $line_assy = 'GTC';
}


 if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
  }
  else{
  $bulancari = $tahun;
  }
    $blnx[1] = '01';
    $blnx[2] = '02';
    $blnx[3] = '03';
    $blnx[4] = '04';
    $blnx[5] = '05';
    $blnx[6] = '06';
    $blnx[7] = '07';
    $blnx[8] = '08';
    $blnx[9] = '09';
    $blnx[10]= '10';
    $blnx[11]= '11';
    $blnx[12]= '12';
    for($t=13; $t<=31; $t++){
      $blnx[$t] = $t;
    }
    
    $blnz = substr($bulancari,6,5);
    $thnz = substr($bulancari,0,4);

    $con_id = pg_query($koneksi, "SELECT COUNT(id) as jumlah_id FROM dbmaintenance_assy.tb_planing where extract(month from tgl_plan) = '$blnz' and shop = '$shop_assy' AND line = '$line_assy'  ");
    while ($row = pg_fetch_array($con_id)) {
      $jml_id = $row['jumlah_id'];
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere=0;
$panggil_db = pg_query($koneksi,"SELECT bagian,line,mesin,jml_mesin,jml_item,periode From dbmaintenance_assy.tb_planing where extract(month from tgl_plan) = '$blnz' and shop = '$shop_assy' AND line = '$line_assy' ");
while ($row = pg_fetch_array($panggil_db)) {
$erere++;
$bagian[$erere] = $row['bagian'];
$mesin[$erere] = $row['mesin'];
$jml_mesin[$erere] = $row['jml_mesin'];
$jml_item[$erere] = $row['jml_item'];
$periode[$erere] = $row['periode'];
if($periode[$erere] == '1M'){
  $periodeni[$erere] = 'Bulanan';
}elseif($periode[$erere] == '3M'){
  $periodeni[$erere] = '3 Bulanan';
}elseif($periode[$erere] == '6M'){
  $periodeni[$erere] = '6 Bulanan';
}elseif($periode[$erere] == '1Y'){
  $periodeni[$erere] = '1 Tahunan';
}
}
  ///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//Plan
for ($k=1;$k <= 31; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT count(id) as tot_plan FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND jml_mesin = '$jml_mesin[$j]' AND extract(month from tgl_plan) = '$blnz' AND extract(day from tgl_plan) = '$blnx[$k]'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan[$k][$j] = $row['tot_plan'];
  }
}
}

for ($k=1;$k <= 31; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasili = pg_query($koneksi,"SELECT line,periode,no_check FROM dbmaintenance_assy.tb_planing WHERE shop = '$shop_assy' AND line = '$line_assy' AND mesin = '$mesin[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND periode = '$periode[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' ");
  while ($row = pg_fetch_array($hasili)) {
    $line_plan[$k][$j] = $row['line'];
    $no_check_plan[$k][$j] = $row['no_check'];
    $periode_plan[$k][$j] = $row['periode'];
  }
}
}

///Aktual

for ($k=1;$k <= 31; $k++){
  for($j=1;$j<=$jml_id;$j++){
  $hasili = pg_query($koneksi,"SELECT line,periode,no_check,hasil FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND mesin = '$mesin[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND periode = '$periode[$j]' AND extract(year from tgl_plan) = '$thnz' AND extract(month from tgl_plan) = '$blnz' ");
  while ($row = pg_fetch_array($hasili)) {
    $hasil_aktual[$k][$j] = $row['hasil'];
    $line_aktual[$k][$j] = $row['line'];
    $no_check_aktual[$k][$j] = $row['no_check'];
    $periode_aktual[$k][$j] = $row['periode'];
  }
}
}

  for($j=1;$j<=$jml_id;$j++){
  $hasil = pg_query($koneksi,"SELECT count(id) as tot_aktual FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop_assy' AND line = '$line_assy' AND periode = '$periode[$j]' AND mesin = '$mesin[$j]' AND extract(month from tgl_plan) = '$blnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_aktual[$k][$j] = $row['tot_aktual'];
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>
