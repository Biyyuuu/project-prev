<?php
include '../koneksi.php';
echo '-';
$waktu_indonesia = time() + (60 * 60 * 7);
$tanggal = gmdate('Y-m-d', $waktu_indonesia);
$bulan = gmdate('m', $waktu_indonesia);
$tgl_geter = gmdate('d', $waktu_indonesia);
$tahun = gmdate('Y-m', $waktu_indonesia);
$tahunan = gmdate('Y');
$tahun1 = $tahunan - 1;
$tahun2 = $tahunan - 2;
$tahun3 = $tahunan - 3;
$tahun11 = $tahunan + 1;
$tahun12 = $tahunan + 2;
////////////////////////////////////////////////////////////////////////////////////////////////////////////
$shop_assy1 = $_GET['shop'];

if ($shop_assy1 == 'BE') {
  $shop_assy = 'BE';
  $line_assy = 'F';
} elseif ($shop_assy1 == 'bdc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'C';
} elseif ($shop_assy1 == 'bdd') {
  $shop_assy = 'Body Assy';
  $line_assy = 'D';
} elseif ($shop_assy1 == 'bde') {
  $shop_assy = 'Body Assy';
  $line_assy = 'E';
} elseif ($shop_assy1 == 'egl') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'L';
} elseif ($shop_assy1 == 'egg') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'G';
} elseif ($shop_assy1 == 'egc') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'C';
} elseif ($shop_assy1 == 'egd') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'D';
} elseif ($shop_assy1 == 'ege') {
  $shop_assy = 'Engine Assy';
  $line_assy = 'E';
} elseif ($shop_assy1 == 'spok') {
  $shop_assy = 'Body Assy';
  $line_assy = 'Spoke';
} elseif ($shop_assy1 == 'ckd') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CKD';
} elseif ($shop_assy1 == 'cbu') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.CBU';
} elseif ($shop_assy1 == 'cbe') {
  $shop_assy = 'Body Assy';
  $line_assy = 'P.B/E';
} elseif ($shop_assy1 == 'lc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'LC LINE';
} elseif ($shop_assy1 == 'gtc') {
  $shop_assy = 'Body Assy';
  $line_assy = 'GTC';
}

if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
} else {
  $bulancari = $tahun;
}
for ($t = 1; $t <= 5; $t++) {
  $blnx[$t] = $t;
}

$blnz = substr($bulancari, 5);
$thnz = substr($bulancari, 0, 4);
$buatget = $thnz . '-' . '01';
$con_id = pg_query($koneksi, "SELECT COUNT(id) as jml_id FROM dbmaintenance_assy.mesin_prev where shop = '$shop_assy' AND line = '$line_assy' ");
while ($row = pg_fetch_array($con_id)) {
  $jml_id = $row['jml_id'];
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
$ckck = 0;
$panggil_mesin = pg_query($koneksi, "SELECT shop,line,mesin From dbmaintenance_assy.mesin_prev where shop = '$shop_assy' AND line = '$line_assy' ");
while ($row_mesin = pg_fetch_array($panggil_mesin)) {
  $ckck++;
  $shop_mesin[$ckck] = $row_mesin['shop'];
  $line_mesin[$ckck] = $row_mesin['line'];
  $mesin_mesin[$ckck] = $row_mesin['mesin'];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(id) as tot_plan FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan[$j] = $row['tot_plan'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_item FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $totin_item[$j] = $row['tot_item'];
    if ($totin_item[$j] == NULL) {
      $tot_item[$j] = '0';
    } elseif ($totin_item[$j] !== NULL) {
      $tot_item[$j] = $totin_item[$j];
    }
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(no) as tot_mesin FROM dbmaintenance_assy.data_mesin WHERE mesin = '$mesin_mesin[$j]' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_mesin[$j] = $row['tot_mesin'];
  }
}

for ($j = 1; $j <= 48; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_week FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_week[$j] = $row['tot_plan_week'];
  }
}

for ($j = 1; $j <= 48; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_week FROM dbmaintenance_assy.tb_aktualprev WHERE week_thn = '$j' AND extract(year from tgl_plan) = '$thnz'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_week[$j] = $row['tot_act_week'];
  }
}
$hasil = pg_query($koneksi, "SELECT sum(jml_mesin) as tot_mesin_thn FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_mesin_thn = $row['tot_mesin_thn'];
}
$hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_item_thn FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_item_thn = $row['tot_item_thn'];
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(id) as tot_act FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_acto[$j] = $row['tot_act'];
  }
}

$hasil = pg_query($koneksi, "SELECT count(id) as tot_actot FROM dbmaintenance_assy.tb_aktualprev WHERE extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_actot = $row['tot_actot'];
}

$hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_tot FROM dbmaintenance_assy.tb_planing WHERE extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
while ($row = pg_fetch_array($hasil)) {
  $tot_plan_tot = $row['tot_plan_tot'];
}

//jan
$line_plan_jan = array();
$periode_plan_jan = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_jan[$k][$j] = 0;
    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '01' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_jan[$k][$j] += $row['jml_item'];
      $periode_plan_jan[$k][$j] = $row['periode'];
    }
  }
}
//feb
$line_plan_feb = array();
$periode_plan_feb = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_feb[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '02' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_feb[$k][$j] += $row['jml_item'];
      $periode_plan_feb[$k][$j] = $row['periode'];
    }
  }
}

//mar
$line_plan_mar = array();
$periode_plan_mar = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_mar[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '03' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_mar[$k][$j] += $row['jml_item'];
      $periode_plan_mar[$k][$j] = $row['periode'];
    }
  }
}

// //apr
$line_plan_apr = array();
$periode_plan_apr = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_apr[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '04' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_apr[$k][$j] += $row['jml_item'];
      $periode_plan_apr[$k][$j] = $row['periode'];
    }
  }
}

//mei
$line_plan_mei = array();
$periode_plan_mei = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_mei[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '05' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_mei[$k][$j] += $row['jml_item'];
      $periode_plan_mei[$k][$j] = $row['periode'];
    }
  }
}

//jun
$line_plan_jun = array();
$periode_plan_jun = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_jun[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '06' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_jun[$k][$j] += $row['jml_item'];
      $periode_plan_jun[$k][$j] = $row['periode'];
    }
  }
}

//jul
$line_plan_jul = array();
$periode_plan_jul = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_jul[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '07' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_jul[$k][$j] += $row['jml_item'];
      $periode_plan_jul[$k][$j] = $row['periode'];
    }
  }
}

//ags
$line_plan_ags = array();
$periode_plan_ags = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_ags[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '08' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_ags[$k][$j] += $row['jml_item'];
      $periode_plan_ags[$k][$j] = $row['periode'];
    }
  }
}

//sep
$line_plan_sep = array();
$periode_plan_sep = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_sep[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '09' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_sep[$k][$j] += $row['jml_item'];
      $periode_plan_sep[$k][$j] = $row['periode'];
    }
  }
}

//okt
$line_plan_okt = array();
$periode_plan_okt = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_okt[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '10' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_okt[$k][$j] += $row['jml_item'];
      $periode_plan_okt[$k][$j] = $row['periode'];
    }
  }
}

//nov
$line_plan_nov = array();
$periode_plan_nov = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_nov[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '11' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_nov[$k][$j] += $row['jml_item'];
      $periode_plan_nov[$k][$j] = $row['periode'];
    }
  }
}

//des
$line_plan_des = array();
$periode_plan_des = array();
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $line_plan_des[$k][$j] = 0;

    $hasili = pg_query($koneksi, "SELECT jml_item,periode FROM dbmaintenance_assy.tb_planing WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$k' AND extract(month from tgl_plan) = '12' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan_des[$k][$j] += $row['jml_item'];
      $periode_plan_des[$k][$j] = $row['periode'];
    }
  }
}

//act
//jan
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '01' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_jan[$k][$j] = $row['hasil'];
      $periode_act_jan[$k][$j] = $row['periode'];
    }
  }
}


//feb
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '02' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_feb[$k][$j] = $row['hasil'];
      $periode_act_feb[$k][$j] = $row['periode'];
    }
  }
}

//mar
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '03' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_mar[$k][$j] = $row['hasil'];
      $periode_act_mar[$k][$j] = $row['periode'];
    }
  }
}

//apr
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '04' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_apr[$k][$j] = $row['hasil'];
      $periode_act_apr[$k][$j] = $row['periode'];
    }
  }
}

//mei
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '05' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_mei[$k][$j] = $row['hasil'];
      $periode_act_mei[$k][$j] = $row['periode'];
    }
  }
}

//jun
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '06' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_jun[$k][$j] = $row['hasil'];
      $periode_act_jun[$k][$j] = $row['periode'];
    }
  }
}

//jul
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '07' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_jul[$k][$j] = $row['hasil'];
      $periode_act_jul[$k][$j] = $row['periode'];
    }
  }
}

//ags
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '08' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_ags[$k][$j] = $row['hasil'];
      $periode_act_ags[$k][$j] = $row['periode'];
    }
  }
}

//sep
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '09' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_sep[$k][$j] = $row['hasil'];
      $periode_act_sep[$k][$j] = $row['periode'];
    }
  }
}

//okt
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '10' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_okt[$k][$j] = $row['hasil'];
      $periode_act_okt[$k][$j] = $row['periode'];
    }
  }
}

//nov
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '11' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_nov[$k][$j] = $row['hasil'];
      $periode_act_nov[$k][$j] = $row['periode'];
    }
  }
}

//des
for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week = '$k' AND extract(month from tgl_plan) = '12' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act_des[$k][$j] = $row['hasil'];
      $periode_act_des[$k][$j] = $row['periode'];
    }
  }
}

//tot plan
for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_jan FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '01' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_jan[$j] = $row['tot_plan_jan'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_feb FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '02' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_feb[$j] = $row['tot_plan_feb'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_mar FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '03' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_mar[$j] = $row['tot_plan_mar'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_apr FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '04' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_apr[$j] = $row['tot_plan_apr'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_mei FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '05' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_mei[$j] = $row['tot_plan_mei'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_jun FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '06' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_jun[$j] = $row['tot_plan_jun'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_jul FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '07' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_jul[$j] = $row['tot_plan_jul'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_ags FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '08' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_ags[$j] = $row['tot_plan_ags'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_sep FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '09' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_sep[$j] = $row['tot_plan_sep'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_okt FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '10' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_okt[$j] = $row['tot_plan_okt'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_nov FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '11' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_nov[$j] = $row['tot_plan_nov'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_plan_des FROM dbmaintenance_assy.tb_planing WHERE week_thn = '$j' AND extract(month from tgl_plan) = '12' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy'");
  while ($row = pg_fetch_array($hasil)) {
    $tot_plan_des[$j] = $row['tot_plan_des'];
  }
}

//tot act
for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_jan FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '01' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_jan[$j] = $row['tot_act_jan'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_feb FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '02' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_feb[$j] = $row['tot_act_feb'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_mar FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '03' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_mar[$j] = $row['tot_act_mar'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_apr FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '04' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_apr[$j] = $row['tot_act_apr'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_mei FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '05' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_mei[$j] = $row['tot_act_mei'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_jun FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '06' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_jun[$j] = $row['tot_act_jun'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_jul FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '07' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_jul[$j] = $row['tot_act_jul'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_ags FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '08' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_ags[$j] = $row['tot_act_ags'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_sep FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '09' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_sep[$j] = $row['tot_act_sep'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_okt FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '10' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_okt[$j] = $row['tot_act_okt'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_nov FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '11' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_nov[$j] = $row['tot_act_nov'];
  }
}

for ($j = 1; $j <= 5; $j++) {
  $hasil = pg_query($koneksi, "SELECT count(hasil) as tot_act_des FROM dbmaintenance_assy.tb_aktualprev WHERE week = '$j' AND extract(month from tgl_plan) = '12' AND extract(year from tgl_plan) = '$thnz' AND line = '$line_assy' AND shop = '$shop_assy' ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_act_des[$j] = $row['tot_act_des'];
  }
}

//

for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT periode,hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$blnx[$k]' AND extract(year from tgl_plan) = '$thnz'");
    while ($row = pg_fetch_array($hasili)) {
      $line_act[$k][$j] = $row['hasil'];
      $periode_act[$k][$j] = $row['periode'];
    }
  }
}


for ($k = 1; $k <= 5; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil FROM dbmaintenance_assy.tb_aktualprev WHERE mesin = '$mesin_mesin[$j]' AND line = '$line_assy' AND shop = '$shop_assy' AND week_thn = '$blnx[$k]'  ");
    while ($row = pg_fetch_array($hasili)) {
      $tot_act[$k][$j] = $row['hasil'];
    }
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
