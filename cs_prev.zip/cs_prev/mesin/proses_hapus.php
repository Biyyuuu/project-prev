<?php
require_once "config/config.php";
if (isset($_GET['no'])) {
    $no = $_GET['no'];
        $delete = $mysqli->query("DELETE FROM dbmaintenance.no_mesin2 WHERE no='$no'")
                                  or die('Ada kesalahan pada query delete : '.$mysqli->error);
        if ($delete) {
            header("location: index.php?alert=3");
        }
}
$mysqli->close();   
?>