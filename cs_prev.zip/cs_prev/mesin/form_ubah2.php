<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>dashboard - maintenance Smart factory</title>

  <!-- Google Font: Source Sans Pro -->
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../../dist/css/adminlte.min.css">
   <script type="text/javascript" src="../../../plugins/assets/js/fungsi_validasi_karakter.js"></script>
        <!-- jQuery -->
        <script type="text/javascript" src="../../../plugins/assets/js/jquery-3.3.1.js"></script>
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
 <?php include "../../../navbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar  sidebar-light-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php?page=home" class="brand-link">
      <img src="/iotmtc/dist/img/icon.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-DARK">MAINTENANCE</span>
    </a>
    <!-- Sidebar -->
    <?php
    include "../../sidebar.php";
    ?>
        <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid"> 
<?php 

include '../../../koneksi.php';

?>

<!DOCTYPE html>
<html>
<head>
  <title>Form Edit</title>
	
</head>
<body>
	
  <?php

$no = $_GET['no'];

  $sql = pg_query($koneksi,"SELECT * FROM dbmaintenance.no_mesin2 WHERE no = '$no' ");
  while ($data=pg_fetch_array($sql)) {
$no = $data['no'];
$code_shop = $data['code_shop'];
$shop = $data['shop'];
$line = $data['line'];
$mesin = $data['mesin'];
$op = $data['op'];
$no_mesin = $data['no_mesin'];
$maker = $data['maker'];
$sn = $data['sn'];
$fa = $data['fa'];
  }
   ?>

<div class="row" style="margin-right: -10px;">
        <div class="col-md-12">
			<div class="alert alert-info" role="alert">
  				<i class="fas fa-edit"></i> Detail Mesin
			</div>
			<div class="card">
			  	<div class="card-body">
			  		<div id="wrapper">
 <form class="needs-validation" action="" method="post" enctype="multipart/form-data" novalidate>
	<div class="row">
	<div class="col-md-3">
		<div class="form-group col-md-10">
		    <input type="number" name="no" value="<?= $no ?>" hidden="">
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-10">
									<label>Code Shop</label>
			<input  class="form-control" name="code_shop" value="<?= $code_shop ?>" >
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-10">
									<label>Shop</label>
			<input  class="form-control" name="shop" value="<?= $shop ?>" >
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		 <div class="form-group col-md-10">
									<label>Line</label>
			<input  class="form-control" name="line" value="<?= $line ?>" >
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-10">
				<label>Mesin</label>
				<input  class="form-control" name="mesin" value="<?= $mesin ?>" >
				<div class="invalid-feedback">Shift tidak boleh kosong.</div>
			</div>
	</div>
		<div class="col-md-3">
     <div class="form-group col-md-10">
									<label>No Mesin</label>
			<input  class="form-control" name="no_mesin" value="<?= $no_mesin ?>" >
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
	</div>

			</div>
			  <input type="submit" class="btn btn-primary btn-submit" name="kirim" value="Kirim">

					  	</div>
					  	<div class="form-group col-md-5" >
				  		</div>		
	</table>
</form>

<?php

$waktu_default = 21600;//21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
$tanggal_sekarang = date('H-i-s' ,time() + $waktu_default);
$tgl = date('d' ,time() + $waktu_default);


if (isset($_POST['kirim'])) {
$no = $_POST['no'];
$code_shop = $_POST['code_shop'];
$shop = $_POST['shop'];
$line = $_POST['line'];
$mesin = $_POST['mesin'];
$op = $_POST['op'];
$no_mesin = $_POST['no_mesin'];
$maker = $_POST['maker'];
$sn = $_POST['sn'];
$fa = $_POST['fa'];
	
	$update = pg_query($koneksi,"UPDATE no_mesin2 SET code_shop = '$code_shop', shop = '$shop', line = '$line', mesin = '$mesin' , no_mesin = '$no_mesin'  WHERE no = '$no' ");
  
	if ($update) {
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=./">';
	}
	else{
		echo "Gagal mengirim...!";
	}
}
if (isset($_POST['batal'])) {
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=">';
}		

?>

</div>
</body>
</html>
 <script src="../../../plugins/jquery/jquery.min.js"></script>
<!-- <script src="../plugins/jquery/jquery.min.js"></script> -->
<!-- Bootstrap 4 -->
<script src="../../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../../dist/js/adminlte.min.js"></script>
<!-- ChartJS -->
<script src="../../../plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../../dist/js/demo.js"></script>