            <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist" >
              <li class="nav-item">
                <a class="nav-link active" id="custom-content-below-home-tab" data-toggle="pill" href="#custom-content-below-home" role="tab" aria-controls="custom-content-below-home" aria-selected="true">Data Mesin</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="custom-content-below-profile-tab" data-toggle="pill" href="#custom-content-below-profile" role="tab" aria-controls="custom-content-below-profile" onclick="myFunction() " aria-selected="false">Tambah</a>
              </li>
            </ul>
            
            <div class="tab-content" id="custom-content-below-tabContent">
              <div class="tab-pane fade show active" id="custom-content-below-home" role="tabpanel" aria-labelledby="custom-content-below-home-tab" style="overflow: scroll;">
                  <?php include 'data.php'; ?>
              </div>
            </div>
            <script>
function myFunction() {
  var myWindow = window.open("form_tambah.php", "", "width=500,height=500");
}
</script>