<!DOCTYPE html>
<html>
<head>
	<title>oke</title>
    <link rel="stylesheet" type="text/css" href="../css/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
</head>
<body>
	  <a class="navbar-brand text-white" href="index.php">
	   
	  </a>
	

<div id="dataModal" class="modal fade">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detail Data Stop Line</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
            <div class="modal-body" id="detail_karyawan">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div> 

		<div class="table-responsive">
			<table id="data" class="table table-striped table-bordered" style="width:100%">
			    <thead>
			        <tr>
			            <td>No</td>
			            <td>Shop</td>
			            <td>Line</td>
			            <td>Machine</td>
			            <td>No Mesin</td>
			            <!-- <td>Opsi</td> -->
			        </tr>
			    </thead>
			    <tbody>
			        <?php
			            include '../../../koneksi.php';
			            $i = 1;
                        $query = "SELECT * FROM dbmaintenance_assy.data_mesin";
                        $dewan1 = $db1->prepare($query);
                        $dewan1->execute();
                        $res1 = $dewan1->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($res1 as $row) {
                            $no = $row['no'];
                            $code_shop = $row['code_shop'];
                            $shop = $row['shop'];
                            $line1 = $row['line'];
                            $mesin = $row['mesin'];
                            $no_mesin = $row['no_mesin'];
			        ?>
			            <tr>
			                <td><?= $i++; ?></td>
			                <td><?= $shop; ?></td>
			                <td><?= $line1; ?></td>
			                <td><?= $mesin; ?></td>
			                <td><?= $no_mesin; ?></td>
			            </tr>
			        <?php } ?>
			    </tbody>
			</table>
		</div>
	
    <script src="../js/datatables.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        let table = $('#data').DataTable();

        $('#data tbody').on( 'click', '#detail', function () {
            var current_row = $(this).parents('tr');
            if (current_row.hasClass('child')) {
                current_row = current_row.prev();
            }
            var data = table.row( current_row ).data();
            console.log(data)

            document.getElementById("id").value = data[0];
            document.getElementById("part_name").value = data[1];
            document.getElementById("stock").value = data[2];
            document.getElementById("loc2").value = data[3];
            document.getElementById("harga").value = data[4];
            document.getElementById("status").value = data[5];

            $("#viewModal").modal("show");
        });

    });
</script>
 <script>  
$(document).ready(function(){
// Begin Aksi Insert
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#nama').val() == "")  
  {  
   alert("Mohon Isi Nama ");  
  }  
  else if($('#alamat').val() == '')  
  {  
   alert("Mohon Isi Alamat");  
  }  
 
  else  
  {  
   $.ajax({  
    url:"insert.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#tabel-pegawai').html(data);  
    }  
   });  
  }  
 });
//END Aksi Insert

//Begin Tampil Detail Karyawan
 $(document).on('click', '.view_data', function(){
  var employee_id = $(this).attr("no");
  $.ajax({
   url:"select.php",
   method:"POST",
   data:{employee_id:employee_id},
   success:function(data){
    $('#detail_karyawan').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
//End Tampil Detail Karyawan
 
//Begin Tampil Form Edit
  $(document).on('click', '.edit_data', function(){
  var employee_id = $(this).attr("id");
  $.ajax({
   url:"edit.php",
   method:"POST",
   data:{employee_id:employee_id},
   success:function(data){
    $('#form_edit').html(data);
    $('#editModal').modal('show');
   }
  });
 });
//End Tampil Form Edit

//Begin Aksi Delete Data
 $(document).on('click', '.hapus_data', function(){
  var employee_id = $(this).attr("id");
  $.ajax({
   url:"delete.php",
   method:"POST",
   data:{employee_id:employee_id},
   success:function(data){
   $('#tabel-pegawai').html(data);  
   }
  });
 });
}); 
//End Aksi Delete Data
</script>
</body>
</html>