<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>dashboard - maintenance Smart factory</title>
  <link rel="stylesheet" href="../../../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../../../dist/css/adminlte.min.css">
   <script type="text/javascript" src="../../../plugins/assets/js/fungsi_validasi_karakter.js"></script>
        <script type="text/javascript" src="../../../plugins/assets/js/jquery-3.3.1.js"></script>
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
 <?php 
 include "../../../navbar.php";
  ?>
  <aside class="main-sidebar  sidebar-light-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php?page=home" class="brand-link">
      <img src="/iotmtc/dist/img/icon.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-DARK">MAINTENANCE</span>
    </a>
    <?php
    include "../../sidebar.php";
    ?>
  </aside>
<div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid"> 
<!doctype html>
<html lang="en">
  	<head>
	    <!-- Required meta tags -->
	    <meta charset="utf-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Aplikasi CRUD dengan PHP, MySQLi, Ajax, DataTables ServerSide, dan Bootstrap 4">
	    <meta name="keywords" content="Aplikasi CRUD dengan PHP, MySQLi, Ajax, DataTables ServerSide, dan Bootstrap 4">
    	<link rel="shortcut icon" href="../../../assets/img/icon.png">
	    <link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.min.css">
	    <link rel="stylesheet" type="text/css" href="../../../assets/plugins/DataTables/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" type="text/css" href="../../../assets/plugins/datepicker/css/datepicker.min.css">
	    <link rel="stylesheet" type="text/css" href="../../../assets/plugins/fontawesome-free-5.4.1-web/css/all.min.css">
	    <link rel="stylesheet" type="text/css" href="../../../assets/css/style.css">
        <script type="text/javascript" src="../../../assets/js/fungsi_validasi_karakter.js"></script>
        <script type="text/javascript" src="../../../assets/js/jquery-3.3.1.js"></script>
	    <title>Perbaikan MTC</title>
  	</head>
  	<body>
		</div>

		<div class="container-fluid">
		<?php
        if (empty($_GET["page"])) {
            include "tampil_data.php";
        } 
        // jika halaman = tambah, maka tampilkan halaman form tambah data
        elseif ($_GET['page']=='tambah') {
            include "form_tambah.php";
        } 
        // jika halaman = ubah, maka tampilkan halaman form ubah data
        elseif ($_GET['page']=='ubah') {
            include "form_ubah2.php";
        } 
        ?>
		</div>
        <div class="container-fluid">
            <footer class="pt-4 my-md-4 pt-md-3 border-top">
                <div class="row">
                    <div class="col-12 col-md center">
                        &copy; <a class="text-info" href="">Maintenance</a>
                    </div>
                </div>
            </footer>
        </div>
	    <script type="text/javascript" src="../../../assets/js/bootstrap.min.js"></script>
	    <script type="text/javascript" src="../../../assets/plugins/fontawesome-free-5.4.1-web/js/all.min.js"></script>
	    <script type="text/javascript" src="../../../assets/plugins/DataTables/js/jquery.dataTables.min.js"></script>
	    <script type="text/javascript" src="../../../assets/plugins/DataTables/js/dataTables.bootstrap4.min.js"></script>
        <script type="text/javascript" src="../../../assets/plugins/datepicker/js/bootstrap-datepicker.min.js"></script>
  	</body>
</html>
 </div>
    </div>  
</div>
</div>
<script src="../../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../../dist/js/adminlte.min.js"></script>
<script src="../../../plugins/chart.js/Chart.min.js"></script>
<script src="../../../dist/js/demo.js"></script>




</html>