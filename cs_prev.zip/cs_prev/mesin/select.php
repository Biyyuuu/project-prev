<?php
include '../koneksi.php';
if(isset($_POST["employee_id"]))

  $sql = pg_query($koneksi,"SELECT * FROM dbmaintenance.tbdaily_stop WHERE id = '".$_POST["employee_id"]."'");
  while ($data=pg_fetch_array($sql)) {
$getime1 = $data['time_1'];
$getime2 = $data['time_2'];
$getime3 = $data['time_3'];
$mttr_persiapan = $data['mttr_persiapan'];
$mttr_check = $data['mttr_check'];
$mttr_tunggu_part = $data['mttr_tunggu_part'];
$mttr_repair = $data['mttr_repair'];
$mttr_setting = $data['mttr_setting'];
$mttr_perapihan = $data['mttr_perapihan'];
$mttr_total = $mttr_persiapan + $mttr_check + $mttr_tunggu_part + $mttr_repair + $mttr_setting + $mttr_perapihan;

  }

  if ($getime1 > 0) {
    $waktu_stop = $getime1;
  }elseif ($getime2 > 0) {
    $waktu_stop = $getime2;
  }elseif ($getime3 > 0) {
    $waktu_stop = $getime3;
  }
   ?>
<?php
//select.php 
if(isset($_POST["employee_id"]))
{
// $foto = $row["foto"];
 $output = '';
 $connect = pg_connect("localhost", "root", "", "dbmaintenance");
 $query = "SELECT * FROM dbmaintenance.tbdaily_stop WHERE id = '".$_POST["employee_id"]."'";
 $result = pg_query($connect, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = pg_fetch_array($result))
    {
     $output .= '
    <tr>  
            <td width="30%"><label>Shop</label></td>  
            <td width="70%">'.$row["shop"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Line</label></td>  
            <td width="70%">'.$row["line1"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Mesin</label></td>  
            <td width="70%">'.$row["machine"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>No Mesin</label></td>  
            <td width="70%">'.$row["no_machine"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Tanggal Stop Line</label></td>  
            <td width="70%">'.$row["tgl_key"].'</td>  
    </tr>

    <tr>  
            <td width="30%"><label>Shift</label></td>  
            <td width="70%">'.$row["shift"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Categori 1</label></td>  
            <td width="70%">'.$row["cat_1"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Categori 2</label></td>  
            <td width="70%">'.$row["cat_2"].'</td>  
    </tr>

     <tr>  
            <td width="30%"><label>Item Trouble / Problem Masalah</label></td>  
            <td width="70%">'.$row["bagian_machine"].'</td>  
    </tr>
     <tr>  
            <td width="30%"><label>Analisa</label></td>  
            <td width="70%">'.$row["analisa"].'</td>  
    </tr>
     <tr>  
            <td width="30%"><label>Tindakan Perbaikan</label></td>  
            <td width="70%">'.$row["kerusakan"].'</td>  
    </tr>
     <tr>  
            <td width="30%"><label>Next Action</label></td>  
            <td width="70%">'.$row["action"].'</td>  
    </tr>
     <tr>  
            <td width="30%"><label>Stop Line</label></td>  
            <td width="70%">'.$waktu_stop.'<label>Menit</label></td>  
    </tr>
    <tr>  
            <td width="30%"><label>MTTR Persiapan</label></td>  
            <td width="70%">'.$row["mttr_persiapan"].'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>MTTR Check</label></td>  
            <td width="70%">'.$row["mttr_check"].'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>MTTR Tunggu Part</label></td>  
            <td width="70%">'.$row["mttr_tunggu_part"].'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>MTTR Repair</label></td>  
            <td width="70%">'.$row["mttr_repair"].'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>MTTR Setting</label></td>  
            <td width="70%">'.$row["mttr_setting"].'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>MTTR Perapihan</label></td>  
            <td width="70%">'.$row["mttr_perapihan"].'<label>Menit</label></td>  
    </tr>
    <tr>  
            <td width="30%"><label>MTTR Total</label></td>  
            <td width="70%">'.$mttr_total.'<label>Menit</label></td>  
    </tr>
     <tr>  
            <td width="30%"><label>PIC 1</label></td>  
            <td width="70%">'.$row["pic_1"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>PIC 2</label></td>  
            <td width="70%">'.$row["pic_2"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>PIC 3</label></td>
            <td width="70%">'.$row["pic_3"].'</td>
    </tr>
    <tr>
            <td width="30%"><label>Foto Perbaikan</label></td>
             <td width="70%"><img class="foto-preview" src="foto/'.$row["foto"].'"/></td> 
    </tr>
     <tr>
            <td width="30%"><label>Foto Setelah Perbaikan</label></td>
             <td width="70%"><img class="foto-preview" src="foto/'.$row["foto1"].'"/></td> 
    </tr>
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>