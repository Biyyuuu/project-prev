<?php
error_reporting(0);
include '../../koneksi.php';

$data2 = $_POST['shop'];
$data3 = $_POST['line'];
$data4 = $_POST['mesin'];
$data6 = $_POST['no_mesin'];
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../../plugins/bs-stepper/css/bs-stepper.min.css">
  <link rel="stylesheet" href="../../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- /.card -->
        <!-- /.row -->

        <div class="row" style="align-middle">
          <div class="col-md-12" style="align-self: center;">
            <div class="card card-default" >
              
                <div class="bs-stepper" class="col-md-8" >
                    <!-- your steps content here -->
                    <!-- <div id="logins-part" class="content" role="tabpanel" aria-labelledby="logins-part-trigger" > -->
			    	<form  method="post"  enctype="multipart/form-data" >
	<div class="col">
		<div class="form-group col-md-8">
			<label>Nama Shop</label>
			<td>
				<select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off">
					<option value="<?=  $data2 ?>"><?=  $data2 ?></option>
					<?php 
					$sql2 = pg_query($koneksi, "SELECT shop FROM dbmaintenance_assy.data_mesin  group by shop");
            			while ($data = pg_fetch_array($sql2)) {
            			$shop = $data['shop']; ?>
            			<option value="<?=  $shop ?>"><?php echo $data['shop'] ?></option>

        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-8" style="align-middle">
			<label>Line</label>
				<select name="line" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data3 ?>"><?=  $data3 ?></option>
					<?php 
					$sql1 = pg_query($koneksi, "SELECT line FROM dbmaintenance_assy.data_mesin where shop = '$data2' group by line");
            			while ($data = pg_fetch_array($sql1)) {
            			$line = $data['line']; ?>
            			<option value="<?=  $line ?>"><?php echo $data['line'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Line tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-8">
			<label>Mesin</label>
			<td><input type="text" class="form-control" name="mesin" required=""></td>
		</div>
		<div class="form-group col-md-8">
			<label>No Mesin</label>
	       <input type="text" name="no_mesin" class="form-control"  autocomplete="off"  required>
	       <div class="invalid-feedback">Item Trouble / Problem Masalah tidak boleh kosong.</div>
		</div>
	</div> 
  <input type="submit" class="btn btn-primary btn-submit" name="kirim" value="Kirim"> 
         <input type="reset" class="btn btn-warning btn-submit" value="Reset"/> 
         <button type="button"  class="btn btn-danger" onclick="javascript:window.close()">Close</button>

	</div>
  </div>
  </div>
  </div>
  </div>
  </div>
  <!-- </div> -->
  </div>
  </section>
  </div>
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<?php
if (isset($_POST['kirim'])) {
$shop 		= $_POST['shop'];
$line 		= $_POST['line'];
$mesin 		= $_POST['mesin'];
$no_mesin 	= $_POST['no_mesin'];
///////////////////////////////////////////////////////////////////////////////////////////////////
  $selSto =pg_query($koneksi, "SELECT code_shop FROM dbmaintenance_assy.data_mesin WHERE shop ='$shop'");
  $sto    =pg_fetch_array($selSto);
  $code_shop =$sto['code_shop'];
///////////////////////////////////////////////////////////////////////////////////////////////////
$insert = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.data_mesin(no,code_shop,shop,line,mesin,no_mesin) VALUES (576,'$code_shop','$shop','$line','$mesin','$no_mesin')"); 

    }
?>
<script src="../../../plugins/bs-stepper/js/bs-stepper.min.js"></script>
</body>
</html>
