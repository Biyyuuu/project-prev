<?php
include '../koneksi.php';

$waktu_indonesia = time() + (60 * 60 * 7);
$tanggal = gmdate('Y-m-d', $waktu_indonesia);
$bulan = gmdate('m', $waktu_indonesia);
$tahun = gmdate('Y-m', $waktu_indonesia);
$tahunan = gmdate('Y', $waktu_indonesia);
$hari = gmdate('D', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////

if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
} else {
  $bulancari = $tahun;
}
$blnx[1] = '01';
$blnx[2] = '02';
$blnx[3] = '03';
$blnx[4] = '04';
$blnx[5] = '05';
$blnx[6] = '06';
$blnx[7] = '07';
$blnx[8] = '08';
$blnx[9] = '09';
$blnx[10] = '10';
$blnx[11] = '11';
$blnx[12] = '12';
for ($t = 13; $t <= 31; $t++) {
  $blnx[$t] = $t;
}

$blnz = substr($bulancari, 6, 5);
$thnz = substr($bulancari, 0, 4);

$con_id = pg_query($koneksi, "SELECT COUNT(id) as jumlah_id FROM dbmaintenance_assy.item_prev where bln = '$blnz' and shop = 'Engine Assy'  ");
while ($row = pg_fetch_array($con_id)) {
  $jml_id = $row['jumlah_id'];
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
$erere = 0;
$panggil_db = pg_query($koneksi, "SELECT * From dbmaintenance_assy.item_prev where bln = '$blnz' and shop = 'Engine Assy' ");
while ($row = pg_fetch_array($panggil_db)) {
  $erere++;
  $line[$erere] = $row['line'];
  $item[$erere] = $row['item'];
  $mesin[$erere] = $row['mesin'];
  $jml_mesin[$erere] = $row['jml_mesin'];
  $jml_item[$erere] = $row['jml_item'];
  $shop[$erere] = $row['shop'];
  $pic[$erere] = $row['pic'];
}
///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasil = pg_query($koneksi, "SELECT count(id) as tot_plan FROM dbmaintenance_assy.tb_planprev WHERE shop = 'Engine Assy' AND line = '$line[$j]' AND item = '$item[$j]' AND bln = '$blnz' AND extract(day from tgl_plan) = '$blnx[$k]'  ");
    while ($row = pg_fetch_array($hasil)) {
      $tot_plan[$k][$j] = $row['tot_plan'];
    }
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_item) as tot_item FROM dbmaintenance_assy.tb_planprev WHERE shop = 'Engine Assy' AND line = '$line[$j]' AND item = '$item[$j]' AND bln = '$blnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_item[$j] = $row['tot_item'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT pic1, pic2 FROM dbmaintenance_assy.tb_planprev WHERE shop = 'Engine Assy' AND line = '$line[$j]' AND item = '$item[$j]' AND bln = '$blnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $pic1[$j] = $row['pic1'];
    $pic2[$j] = $row['pic2'];
  }
}

for ($j = 1; $j <= $jml_id; $j++) {
  $hasil = pg_query($koneksi, "SELECT sum(jml_mesin) as tot_mesin FROM dbmaintenance_assy.tb_planprev WHERE shop = 'Engine Assy' AND line = '$line[$j]' AND item = '$item[$j]' AND bln = '$blnz'  ");
  while ($row = pg_fetch_array($hasil)) {
    $tot_mesin[$j] = $row['tot_mesin'];
  }
}


for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT line,periode,no_check FROM dbmaintenance_assy.tb_planprev WHERE shop = '$shop[$j]' AND  mesin = '$mesin[$j]' AND line = '$line[$j]' AND shop = '$shop[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND extract(year from tgl_plan) = '$thnz' AND bln = '$blnz' ");
    while ($row = pg_fetch_array($hasili)) {
      $line_plan[$k][$j] = $row['line'];
      $no_check_plan[$k][$j] = $row['no_check'];
      $periode_plan[$k][$j] = $row['periode'];
    }
  }
}

for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasili = pg_query($koneksi, "SELECT hasil,periode,no_check FROM dbmaintenance_assy.tb_aktualprev WHERE shop = '$shop[$j]' AND  mesin = '$mesin[$j]' AND line = '$line[$j]' AND shop = '$shop[$j]' AND extract(day from tgl_plan) = '$blnx[$k]' AND extract(year from tgl_plan) = '$thnz' AND bln = '$blnz' ");
    while ($row = pg_fetch_array($hasili)) {
      $line_act[$k][$j] = $row['hasil'];
      $periode_act[$k][$j] = $row['periode'];
      $no_check_act[$k][$j] = $row['no_check'];
    }
  }
}

for ($k = 1; $k <= 31; $k++) {
  for ($j = 1; $j <= $jml_id; $j++) {
    $hasil = pg_query($koneksi, "SELECT count(id) as tot_act FROM dbmaintenance_assy.tb_aktualprev WHERE shop = 'Engine Assy' AND line = '$line[$j]' AND item = '$item[$j]' AND bln = '$blnz' AND extract(day from tgl_plan) = '$blnx[$k]'  ");
    while ($row = pg_fetch_array($hasil)) {
      $tot_act[$k][$j] = $row['tot_act'];
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
