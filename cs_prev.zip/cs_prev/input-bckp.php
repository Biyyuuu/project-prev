<?php
include '../koneksi.php';
include 'pengaturan_1m.php';
//include 'pengaturan_work_time.php';
  
//$tanggal=gmdate('d-m-y', $waktu_indonesia);
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.css" rel="stylesheet" type="text/css"/>
  <link href="/iotmtc/weld/cs_prev/dist/css/style.css" rel="stylesheet" type="text/css">
  
</head>

<body>
      <div class="wrapper theme-1-active pimary-color-blue">
      <h1 style="text-align:center; font-size: x-large;">RENCANA AKTIVITAS BULANAN SHOP MAINTENANCE ASSY</h1>
    <h5 style="text-align:center;  font-size: x-large;">(2023)</h5>
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default card-view">
              <div class="panel-heading">
              <div class="panel-wrapper collapse in">
                <div class="panel-body">
                  <div class="table-wrap">
                     <div id="cari">
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Cari">
   </form>
   <br/>
  <table style="float:right; margin-right:30px; margin-top:-20px;font-weight: bold; padding:10px;">
        
        <tr>
          <td style="text-align:left; color: black;">→</td>
          <td style="text-align:left; color: black;">: PLAN</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">O</td>
          <td style="text-align:left; color: black;">: FINISH 100%</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">△</td>
          <td style="text-align:left; color: black;">: TIDAK SELESAI / NG</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">⇨</td>
          <td style="text-align:left; color: black;">: RE-SCHEDULE </td>
        </tr>
    </table>
    <table>
    <tr>
          <td style="text-align:left; color: black;">PIC </td>
          <td style="text-align:left; color: black;">: LUCKY S.K</td>
        </tr>
        <tr>
          <td style="text-align:left; color: black;">SHOP </td>
          <td style="text-align:left; color: black;">: MAINTENANCE BODY ASSY</td>
        </tr>
    </table>
</div>
<form class="needs-validation"  method="post" enctype="multipart/form-data" novalidate>
<table data-toggle="table" style= "text-align: left; position: relative; border-collapse: collapse; ">
  <thead>
    <tr>
           <th rowspan="2">No</th>
           <th rowspan="2">Line</th>
           <th rowspan="2" style="text-align: center;">Item Pekerjaan</th>
           <th rowspan="2" style="text-align: center;">Jml Mesin</th>
           <th rowspan="1" style="text-align: center;">Plan </th>
           <!-- <th colspan="1" style="text-align: center;">Aktual</th> -->
           <th colspan="31" style="text-align: center;"> Juli 2023 </th>   
           <th rowspan="2" style="text-align: center;">PIC</th>
           <th rowspan="2" style="text-align: center;">keterangan</th>
    </tr>
    <tr>
    <th colspan="1" style="text-align: center;">Aktual</th>
      <?php
      for($xi=1;$xi<=31;$xi++){
      ?>
          <th rowspan="2" style="text-align: center;"><?=$xi?> </th>
      <?php
      }
      ?>
     
        </tr>
    </thead>
  <tbody>
<?php
$z=1;
// echo $tahun_cari;
  for ($i=1; $i <= $jml_id ; $i++){

			$tampil = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.aktualprev_assy WHERE bln = '$blnz' AND thn = '$thnz' and urut = '$i' ");
			while ($row = pg_fetch_array($tampil)) {
        $bln_1[$i] = $row['bln_1']; 
        $bln_2[$i] = $row['bln_2']; 
        $bln_3[$i] = $row['bln_3']; 
        $bln_4[$i] = $row['bln_4']; 
        $bln_5[$i] = $row['bln_5']; 
        $bln_6[$i] = $row['bln_6']; 
        $bln_7[$i] = $row['bln_7']; 
        $bln_8[$i] = $row['bln_8']; 
        $bln_9[$i] = $row['bln_9']; 
        $bln_10[$i] = $row['bln_10'];
        $bln_11[$i] = $row['bln_11'];
        $bln_12[$i] = $row['bln_12'];
        $bln_13[$i] = $row['bln_13'];
        $bln_14[$i] = $row['bln_14'];
        $bln_15[$i] = $row['bln_15'];
        $bln_16[$i] = $row['bln_16'];
        $bln_17[$i] = $row['bln_17'];
        $bln_18[$i] = $row['bln_18'];
        $bln_19[$i] = $row['bln_19'];
        $bln_20[$i] = $row['bln_20'];
        $bln_21[$i] = $row['bln_21'];
        $bln_22[$i] = $row['bln_22'];
        $bln_23[$i] = $row['bln_23'];
        $bln_24[$i] = $row['bln_24'];
        $bln_25[$i] = $row['bln_25'];
        $bln_26[$i] = $row['bln_26'];
        $bln_27[$i] = $row['bln_27'];
        $bln_28[$i] = $row['bln_28'];
        $bln_29[$i] = $row['bln_29'];
        $bln_30[$i] = $row['bln_30'];
        $bln_31[$i] = $row['bln_31'];
        $pic1[$i] = $row['pic1'];
        $pic2[$i] = $row['pic2'];
        $ket[$i] = $row['ket'];
				}
        $tampil = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.planprev_assy WHERE bln = '$blnz' AND thn = '$thnz' and urut = '$i' ");
        while ($row = pg_fetch_array($tampil)) {
          $bln_plan_1[$i] = $row['bln_1']; 
          $bln_plan_2[$i] = $row['bln_2']; 
          $bln_plan_3[$i] = $row['bln_3']; 
          $bln_plan_4[$i] = $row['bln_4']; 
          $bln_plan_5[$i] = $row['bln_5']; 
          $bln_plan_6[$i] = $row['bln_6']; 
          $bln_plan_7[$i] = $row['bln_7']; 
          $bln_plan_8[$i] = $row['bln_8']; 
          $bln_plan_9[$i] = $row['bln_9']; 
          $bln_plan_10[$i] = $row['bln_10'];
          $bln_plan_11[$i] = $row['bln_11'];
          $bln_plan_12[$i] = $row['bln_12'];
          $bln_plan_13[$i] = $row['bln_13'];
          $bln_plan_14[$i] = $row['bln_14'];
          $bln_plan_15[$i] = $row['bln_15'];
          $bln_plan_16[$i] = $row['bln_16'];
          $bln_plan_17[$i] = $row['bln_17'];
          $bln_plan_18[$i] = $row['bln_18'];
          $bln_plan_19[$i] = $row['bln_19'];
          $bln_plan_20[$i] = $row['bln_20'];
          $bln_plan_21[$i] = $row['bln_21'];
          $bln_plan_22[$i] = $row['bln_22'];
          $bln_plan_23[$i] = $row['bln_23'];
          $bln_plan_24[$i] = $row['bln_24'];
          $bln_plan_25[$i] = $row['bln_25'];
          $bln_plan_26[$i] = $row['bln_26'];
          $bln_plan_27[$i] = $row['bln_27'];
          $bln_plan_28[$i] = $row['bln_28'];
          $bln_plan_29[$i] = $row['bln_29'];
          $bln_plan_30[$i] = $row['bln_30'];
          $bln_plan_31[$i] = $row['bln_31'];
        }    


       
?>

    <tr>
      <td rowspan="2" align="center"> <?= $z++ ?> </td> 
      <td rowspan="2" align="center" name="line<?=$i?>" style="text-align: left;"><a href=""><?= $line[$i];?></a></td>
      <td rowspan="2" align="center" name="item<?=$i?>" style="text-align: left;"><a href=""><?= $item[$i];?></a></td>
      <td rowspan="2" align="center" name="jml_mesin<?=$i?>" style="text-align: left;"><a href=""><?= $jml_mesin[$i];?></a> </td>
      <td align="center"style="text-align: left;"><a href="">Plan </a> </td><!------// PLAN  //------->


<td >
<select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_1<?= $i ?>" >
      <?php if($bln_plan_1[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_1[$i]?>"><?=$bln_plan_1[$i]?></option>
			<?php}elseif($bln_plan_1[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
        <option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
  
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_2<?= $i ?>" >
      <?php if($bln_plan_2[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_2[$i]?>"><?=$bln_plan_2[$i]?></option>
			<?php}elseif($bln_plan_2[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
      
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_3<?= $i ?>">
      <?php if($bln_plan_3[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_3[$i]?>"><?=$bln_plan_3[$i]?></option>
			<?php}elseif($bln_plan_3[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_4<?= $i ?>">
      <?php if($bln_plan_4[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_4[$i]?>"><?=$bln_plan_4[$i]?></option>
			<?php}elseif($bln_plan_4[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_5<?= $i ?>">
      <?php if($bln_plan_5[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_5[$i]?>"><?=$bln_plan_5[$i]?></option>
			<?php}elseif($bln_plan_5[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_6<?= $i ?>">
      <?php if($bln_plan_6[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_6[$i]?>"><?=$bln_plan_6[$i]?></option>
			<?php}elseif($bln_plan_6[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_7<?= $i ?>">
      <?php if($bln_plan_7[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_7[$i]?>"><?=$bln_plan_7[$i]?></option>
			<?php}elseif($bln_plan_7[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_8<?= $i ?>">
      <?php if($bln_plan_8[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_8[$i]?>"><?=$bln_plan_8[$i]?></option>
			<?php}elseif($bln_plan_8[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_9<?= $i ?>">
      <?php if($bln_plan_9[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_9[$i]?>"><?=$bln_plan_9[$i]?></option>
			<?php}elseif($bln_plan_9[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_10<?= $i ?>">
      <?php if($bln_plan_10[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_10[$i]?>"><?=$bln_plan_10[$i]?></option>
			<?php}elseif($bln_plan_10[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_11<?= $i ?>">
      <?php if($bln_plan_11[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_11[$i]?>"><?=$bln_plan_11[$i]?></option>
			<?php}elseif($bln_plan_11[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_12<?= $i ?>">
      <?php if($bln_plan_12[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_12[$i]?>"><?=$bln_plan_12[$i]?></option>
			<?php}elseif($bln_plan_12[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_13<?= $i ?>">
      <?php if($bln_plan_13[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_13[$i]?>"><?=$bln_plan_13[$i]?></option>
			<?php}elseif($bln_plan_13[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_14<?= $i ?>">
      <?php if($bln_plan_14[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_14[$i]?>"><?=$bln_plan_14[$i]?></option>
			<?php}elseif($bln_plan_14[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_15<?= $i ?>">
      <?php if($bln_plan_15[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_15[$i]?>"><?=$bln_plan_15[$i]?></option>
			<?php}elseif($bln_plan_15[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_16<?= $i ?>">
      <?php if($bln_plan_16[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_16[$i]?>"><?=$bln_plan_16[$i]?></option>
			<?php}elseif($bln_plan_16[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_17<?= $i ?>">
      <?php if($bln_plan_17[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_17[$i]?>"><?=$bln_plan_17[$i]?></option>
			<?php}elseif($bln_plan_17[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_18<?= $i ?>">
      <?php if($bln_plan_18[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_18[$i]?>"><?=$bln_plan_18[$i]?></option>
			<?php}elseif($bln_plan_18[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_19<?= $i ?>">
      <?php if($bln_plan_19[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_19[$i]?>"><?=$bln_plan_19[$i]?></option>
			<?php}elseif($bln_plan_19[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_20<?= $i ?>">
      <?php if($bln_plan_20[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_20[$i]?>"><?=$bln_plan_20[$i]?></option>
			<?php}elseif($bln_plan_20[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_21<?= $i ?>">
      <?php if($bln_plan_21[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_21[$i]?>"><?=$bln_plan_21[$i]?></option>
			<?php}elseif($bln_plan_21[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_22<?= $i ?>">
      <?php if($bln_plan_22[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_22[$i]?>"><?=$bln_plan_22[$i]?></option>
			<?php}elseif($bln_plan_22[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_23<?= $i ?>">
      <?php if($bln_plan_23[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_23[$i]?>"><?=$bln_plan_23[$i]?></option>
			<?php}elseif($bln_plan_23[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_24<?= $i ?>">
      <?php if($bln_plan_24[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_24[$i]?>"><?=$bln_plan_24[$i]?></option>
			<?php}elseif($bln_plan_24[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_25<?= $i ?>">
      <?php if($bln_plan_25[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_25[$i]?>"><?=$bln_plan_25[$i]?></option>
			<?php}elseif($bln_plan_25[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_26<?= $i ?>">
      <?php if($bln_plan_26[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_26[$i]?>"><?=$bln_plan_26[$i]?></option>
			<?php}elseif($bln_plan_26[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_27<?= $i ?>">
      <?php if($bln_plan_27[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_27[$i]?>"><?=$bln_plan_27[$i]?></option>
			<?php}elseif($bln_plan_27[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_28<?= $i ?>">
      <?php if($bln_plan_28[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_28[$i]?>"><?=$bln_plan_28[$i]?></option>
			<?php}elseif($bln_plan_28[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_29<?= $i ?>">
      <?php if($bln_plan_29[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_29[$i]?>"><?=$bln_plan_29[$i]?></option>
			<?php}elseif($bln_plan_29[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_30<?= $i ?>">
      <?php if($bln_plan_30[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_30[$i]?>"><?=$bln_plan_30[$i]?></option>
			<?php}elseif($bln_plan_30[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_plan_31<?= $i ?>">
      <?php if($bln_plan_31[$i] !== NULL){ ?>
        <option value="<?=$bln_plan_31[$i]?>"><?=$bln_plan_31[$i]?></option>
			<?php}elseif($bln_plan_31[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>

</td>

<td rowspan="2" >
          <select name="pic1<?= $i ?>" value="<?= $pic1[$i] ?>" class="form-control" style="padding: -0.625rem 20.75rem;"  >
          <option value=""></option>
          <?php 
          $sql1 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY'");
                  while ($data = pg_fetch_array($sql1)) {?>
                  
                  <option><?php echo $data['nama'] ?></option>
              <?php }  ?>
        </select>

        <br/> <p style="text-align:center;">&</p>

        <select name="pic2<?= $i ?>" value="<?= $pic2[$i] ?>" class="form-control" style="padding: -0.625rem 20.75rem;"  >
          <option value=""></option>
          <?php 
          $sql1 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY'");
                  while ($data = pg_fetch_array($sql1)) {?>
                  
                  <option><?php echo $data['nama'] ?></option>
              <?php }  ?>
        </select>
        </td>
    <td rowspan="2">
          <input type="text" class="form-control" name="ket<?= $i ?>">
        </td>
</tr>
  <tr>
      <td  align="center" style="text-align: left;"><a href=""> Aktual</a> </td>

    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_1<?= $i ?>" >
      <?php if($bln_1[$i] !== NULL){ ?>
        <option value="<?=$bln_1[$i]?>"><?=$bln_1[$i]?></option>
			<?php}elseif($bln_1[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
        <option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
  
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_2<?= $i ?>" >
      <?php if($bln_2[$i] !== NULL){ ?>
        <option value="<?=$bln_2[$i]?>"><?=$bln_2[$i]?></option>
			<?php}elseif($bln_2[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
      
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_3<?= $i ?>">
      <?php if($bln_3[$i] !== NULL){ ?>
        <option value="<?=$bln_3[$i]?>"><?=$bln_3[$i]?></option>
			<?php}elseif($bln_3[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_4<?= $i ?>">
      <?php if($bln_4[$i] !== NULL){ ?>
        <option value="<?=$bln_4[$i]?>"><?=$bln_4[$i]?></option>
			<?php}elseif($bln_4[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_5<?= $i ?>">
      <?php if($bln_5[$i] !== NULL){ ?>
        <option value="<?=$bln_5[$i]?>"><?=$bln_5[$i]?></option>
			<?php}elseif($bln_5[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_6<?= $i ?>">
      <?php if($bln_6[$i] !== NULL){ ?>
        <option value="<?=$bln_6[$i]?>"><?=$bln_6[$i]?></option>
			<?php}elseif($bln_6[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_7<?= $i ?>">
      <?php if($bln_7[$i] !== NULL){ ?>
        <option value="<?=$bln_7[$i]?>"><?=$bln_7[$i]?></option>
			<?php}elseif($bln_7[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_8<?= $i ?>">
      <?php if($bln_8[$i] !== NULL){ ?>
        <option value="<?=$bln_8[$i]?>"><?=$bln_8[$i]?></option>
			<?php}elseif($bln_8[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_9<?= $i ?>">
      <?php if($bln_9[$i] !== NULL){ ?>
        <option value="<?=$bln_9[$i]?>"><?=$bln_9[$i]?></option>
			<?php}elseif($bln_9[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_10<?= $i ?>">
      <?php if($bln_10[$i] !== NULL){ ?>
        <option value="<?=$bln_10[$i]?>"><?=$bln_10[$i]?></option>
			<?php}elseif($bln_10[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_11<?= $i ?>">
      <?php if($bln_11[$i] !== NULL){ ?>
        <option value="<?=$bln_11[$i]?>"><?=$bln_11[$i]?></option>
			<?php}elseif($bln_11[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_12<?= $i ?>">
      <?php if($bln_12[$i] !== NULL){ ?>
        <option value="<?=$bln_12[$i]?>"><?=$bln_12[$i]?></option>
			<?php}elseif($bln_12[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_13<?= $i ?>">
      <?php if($bln_13[$i] !== NULL){ ?>
        <option value="<?=$bln_13[$i]?>"><?=$bln_13[$i]?></option>
			<?php}elseif($bln_13[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_14<?= $i ?>">
      <?php if($bln_14[$i] !== NULL){ ?>
        <option value="<?=$bln_14[$i]?>"><?=$bln_14[$i]?></option>
			<?php}elseif($bln_14[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_15<?= $i ?>">
      <?php if($bln_15[$i] !== NULL){ ?>
        <option value="<?=$bln_15[$i]?>"><?=$bln_15[$i]?></option>
			<?php}elseif($bln_15[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_16<?= $i ?>">
      <?php if($bln_16[$i] !== NULL){ ?>
        <option value="<?=$bln_16[$i]?>"><?=$bln_16[$i]?></option>
			<?php}elseif($bln_16[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_17<?= $i ?>">
      <?php if($bln_17[$i] !== NULL){ ?>
        <option value="<?=$bln_17[$i]?>"><?=$bln_17[$i]?></option>
			<?php}elseif($bln_17[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_18<?= $i ?>">
      <?php if($bln_18[$i] !== NULL){ ?>
        <option value="<?=$bln_18[$i]?>"><?=$bln_18[$i]?></option>
			<?php}elseif($bln_18[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_19<?= $i ?>">
      <?php if($bln_19[$i] !== NULL){ ?>
        <option value="<?=$bln_19[$i]?>"><?=$bln_19[$i]?></option>
			<?php}elseif($bln_19[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_20<?= $i ?>">
      <?php if($bln_20[$i] !== NULL){ ?>
        <option value="<?=$bln_20[$i]?>"><?=$bln_20[$i]?></option>
			<?php}elseif($bln_20[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_21<?= $i ?>">
      <?php if($bln_21[$i] !== NULL){ ?>
        <option value="<?=$bln_21[$i]?>"><?=$bln_21[$i]?></option>
			<?php}elseif($bln_21[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
        ?>
        <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_22<?= $i ?>">
      <?php if($bln_22[$i] !== NULL){ ?>
        <option value="<?=$bln_22[$i]?>"><?=$bln_22[$i]?></option>
			<?php}elseif($bln_22[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_23<?= $i ?>">
      <?php if($bln_23[$i] !== NULL){ ?>
        <option value="<?=$bln_23[$i]?>"><?=$bln_23[$i]?></option>
			<?php}elseif($bln_23[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_24<?= $i ?>">
      <?php if($bln_24[$i] !== NULL){ ?>
        <option value="<?=$bln_24[$i]?>"><?=$bln_24[$i]?></option>
			<?php}elseif($bln_24[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_25<?= $i ?>">
      <?php if($bln_25[$i] !== NULL){ ?>
        <option value="<?=$bln_25[$i]?>"><?=$bln_25[$i]?></option>
			<?php}elseif($bln_25[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_26<?= $i ?>">
      <?php if($bln_26[$i] !== NULL){ ?>
        <option value="<?=$bln_26[$i]?>"><?=$bln_26[$i]?></option>
			<?php}elseif($bln_26[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_27<?= $i ?>">
      <?php if($bln_27[$i] !== NULL){ ?>
        <option value="<?=$bln_27[$i]?>"><?=$bln_27[$i]?></option>
			<?php}elseif($bln_27[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_28<?= $i ?>">
      <?php if($bln_28[$i] !== NULL){ ?>
        <option value="<?=$bln_28[$i]?>"><?=$bln_28[$i]?></option>
			<?php}elseif($bln_28[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_29<?= $i ?>">
      <?php if($bln_29[$i] !== NULL){ ?>
        <option value="<?=$bln_29[$i]?>"><?=$bln_29[$i]?></option>
			<?php}elseif($bln_29[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_30<?= $i ?>">
      <?php if($bln_30[$i] !== NULL){ ?>
        <option value="<?=$bln_30[$i]?>"><?=$bln_30[$i]?></option>
			<?php}elseif($bln_30[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>
    <td>
      <select style= "height: 40px; width: 40px;" class="form-control"  name="bln_31<?= $i ?>">
      <?php if($bln_31[$i] !== NULL){ ?>
        <option value="<?=$bln_31[$i]?>"><?=$bln_31[$i]?></option>
			<?php}elseif($bln_31[$i] == NULL){?>
        <option value=""></option>
			<?php
        }
      ?>
      <option value=""></option>
				<option value="O">O</option>
        <option value="△">△</option>
        <option value="⇨">⇨</option>
			</select>
    </td>


  </tr>
  <!-- <tr>
    
  </tr> -->
  <?php
}
?>
 </tbody>

       </table>
       <td align="right"><input type="submit"  class="btn btn-info btn-submit"  name="kirim" value="kirim"></td>
      </div>  
     </div>  
    </div>  
   </div>  
  </div>  
 </div>
 </div>
  <script src="/iotmtc/vendors/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/bootstrap-table/dist/bootstrap-table.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
  <script src="/iotmtc/vendors/bower_components/switchery/dist/switchery.min.js"></script>
  <script src="/iotmtc/weld/cs_prev/dist/js/init.js"></script>
</form>
</body>

</html>

<?php
if (isset($_POST['kirim'])) {
  for($i=1;$i<=$jml_id;$i++){

$bln_1[$i] = $_POST['bln_1'.$i]; 
$bln_2[$i] = $_POST['bln_2'.$i]; 
$bln_3[$i] = $_POST['bln_3'.$i]; 
$bln_4[$i] = $_POST['bln_4'.$i]; 
$bln_5[$i] = $_POST['bln_5'.$i]; 
$bln_6[$i] = $_POST['bln_6'.$i]; 
$bln_7[$i] = $_POST['bln_7'.$i]; 
$bln_8[$i] = $_POST['bln_8'.$i]; 
$bln_9[$i] = $_POST['bln_9'.$i]; 
$bln_10[$i] = $_POST['bln_10'.$i];
$bln_11[$i] = $_POST['bln_11'.$i];
$bln_12[$i] = $_POST['bln_12'.$i];
$bln_13[$i] = $_POST['bln_13'.$i];
$bln_14[$i] = $_POST['bln_14'.$i];
$bln_15[$i] = $_POST['bln_15'.$i];
$bln_16[$i] = $_POST['bln_16'.$i];
$bln_17[$i] = $_POST['bln_17'.$i];
$bln_18[$i] = $_POST['bln_18'.$i];
$bln_19[$i] = $_POST['bln_19'.$i];
$bln_20[$i] = $_POST['bln_20'.$i];
$bln_21[$i] = $_POST['bln_21'.$i];
$bln_22[$i] = $_POST['bln_22'.$i];
$bln_23[$i] = $_POST['bln_23'.$i];
$bln_24[$i] = $_POST['bln_24'.$i];
$bln_25[$i] = $_POST['bln_25'.$i];
$bln_26[$i] = $_POST['bln_26'.$i];
$bln_27[$i] = $_POST['bln_27'.$i];
$bln_28[$i] = $_POST['bln_28'.$i];
$bln_29[$i] = $_POST['bln_29'.$i];
$bln_30[$i] = $_POST['bln_30'.$i];
$bln_31[$i] = $_POST['bln_31'.$i];
$pic1[$i] = $_POST['pic1'.$i];
$pic2[$i] = $_POST['pic2'.$i];
$ket[$i] = $_POST['ket'.$i];

$bln_plan_1[$i] = $_POST['bln_plan_1'.$i]; 
$bln_plan_2[$i] = $_POST['bln_plan_2'.$i]; 
$bln_plan_3[$i] = $_POST['bln_plan_3'.$i]; 
$bln_plan_4[$i] = $_POST['bln_plan_4'.$i]; 
$bln_plan_5[$i] = $_POST['bln_plan_5'.$i]; 
$bln_plan_6[$i] = $_POST['bln_plan_6'.$i]; 
$bln_plan_7[$i] = $_POST['bln_plan_7'.$i]; 
$bln_plan_8[$i] = $_POST['bln_plan_8'.$i]; 
$bln_plan_9[$i] = $_POST['bln_plan_9'.$i]; 
$bln_plan_10[$i] = $_POST['bln_plan_10'.$i];
$bln_plan_11[$i] = $_POST['bln_plan_11'.$i];
$bln_plan_12[$i] = $_POST['bln_plan_12'.$i];
$bln_plan_13[$i] = $_POST['bln_plan_13'.$i];
$bln_plan_14[$i] = $_POST['bln_plan_14'.$i];
$bln_plan_15[$i] = $_POST['bln_plan_15'.$i];
$bln_plan_16[$i] = $_POST['bln_plan_16'.$i];
$bln_plan_17[$i] = $_POST['bln_plan_17'.$i];
$bln_plan_18[$i] = $_POST['bln_plan_18'.$i];
$bln_plan_19[$i] = $_POST['bln_plan_19'.$i];
$bln_plan_20[$i] = $_POST['bln_plan_20'.$i];
$bln_plan_21[$i] = $_POST['bln_plan_21'.$i];
$bln_plan_22[$i] = $_POST['bln_plan_22'.$i];
$bln_plan_23[$i] = $_POST['bln_plan_23'.$i];
$bln_plan_24[$i] = $_POST['bln_plan_24'.$i];
$bln_plan_25[$i] = $_POST['bln_plan_25'.$i];
$bln_plan_26[$i] = $_POST['bln_plan_26'.$i];
$bln_plan_27[$i] = $_POST['bln_plan_27'.$i];
$bln_plan_28[$i] = $_POST['bln_plan_28'.$i];
$bln_plan_29[$i] = $_POST['bln_plan_29'.$i];
$bln_plan_30[$i] = $_POST['bln_plan_30'.$i];
$bln_plan_31[$i] = $_POST['bln_plan_31'.$i];

	$checking = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.aktualprev_assy WHERE bln = '$blnz' AND thn = '$thnz' AND item = '$item[$i]' ");
	$check = pg_num_rows($checking);
	if ($check == 1) {
		while ($row = pg_fetch_array($checking)) {
			$aidi = $row['no'];
		}
		$update = pg_query($koneksi, "UPDATE dbmaintenance_assy.aktualprev_assy SET bln_1 = '$bln_1[$i]', bln_2 = '$bln_2[$i]', bln_3 = '$bln_3[$i]', bln_4 = '$bln_4[$i]', bln_5 = '$bln_5[$i]', bln_6 = '$bln_6[$i]', bln_7 = '$bln_7[$i]', bln_8 = '$bln_8[$i]', bln_9 = '$bln_9[$i]', bln_10 = '$bln_10[$i]', bln_11 = '$bln_11[$i]', bln_12 = '$bln_12[$i]', bln_13 = '$bln_13[$i]', bln_14 = '$bln_14[$i]', bln_15 = '$bln_15[$i]', bln_16 = '$bln_16[$i]', bln_17 = '$bln_17[$i]', bln_18 = '$bln_18[$i]', bln_19 = '$bln_19[$i]', bln_20 = '$bln_20[$i]', bln_21 = '$bln_21[$i]', bln_22 = '$bln_22[$i]', bln_23 = '$bln_23[$i]', bln_24 = '$bln_24[$i]', bln_25 = '$bln_25[$i]', bln_26 = '$bln_26[$i]', bln_27 = '$bln_27[$i]', bln_28 = '$bln_28[$i]', bln_29 = '$bln_29[$i]', bln_30 = '$bln_30[$i]', bln_31 = '$bln_31[$i]',pic1 = '$pic1[$i]',pic2 = '$pic2[$i]',ket = '$ket[$i]' WHERE no = '$aidi' ");
		if ($update) {
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=/iotmtc/assy/cs_prev/1m.php">';
	}
	else{
		echo "Gagal mengirim...!";
	}
	} else {

    $insert = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.aktualprev_assy (urut,shop,line,item,jml_mesin,tanggal,bln,thn,bln_1,bln_2,bln_3,bln_4,bln_5,bln_6,bln_7,bln_8,bln_9,bln_10,bln_11,bln_12,bln_13,bln_14,bln_15,bln_16,bln_17,bln_18,bln_19,bln_20,bln_21,bln_22,bln_23,bln_24,bln_25,bln_26,bln_27,bln_28,bln_29,bln_30,bln_31,pic1,pic2,ket) VALUES ('$i','$shop[$i]','$line[$i]','$item[$i]','$jml_mesin[$i]','$tanggal','$blnz','$thnz','$bln_1[$i]','$bln_2[$i]','$bln_3[$i]','$bln_4[$i]','$bln_5[$i]','$bln_6[$i]','$bln_7[$i]','$bln_8[$i]','$bln_9[$i]','$bln_10[$i]','$bln_11[$i]','$bln_12[$i]','$bln_13[$i]','$bln_14[$i]','$bln_15[$i]','$bln_16[$i]','$bln_17[$i]','$bln_18[$i]','$bln_19[$i]','$bln_20[$i]','$bln_21[$i]','$bln_22[$i]','$bln_23[$i]','$bln_24[$i]','$bln_25[$i]','$bln_26[$i]','$bln_27[$i]','$bln_28[$i]','$bln_29[$i]','$bln_30[$i]','$bln_31[$i]','$pic1[$i]','$pic2[$i]','$ket[$i]')");
    
		if ($insert) {
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL= /iotmtc/assy/cs_prev/1m.php">';
    }else{
      echo "Gagal mengirim...!";
	
}
	
	}
  $checkingg = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.planprev_assy WHERE bln = '$blnz' AND thn = '$thnz' AND item = '$item[$i]' ");
	$checki = pg_num_rows($checkingg);
	if ($checki == 1) {
		while ($row = pg_fetch_array($checkingg)) {
			$aidi = $row['no'];
		}
		$update = pg_query($koneksi, "UPDATE dbmaintenance_assy.planprev_assy SET bln_1 = '$bln_plan_1[$i]', bln_2 = '$bln_plan_2[$i]', bln_3 = '$bln_plan_3[$i]', bln_4 = '$bln_plan_4[$i]', bln_5 = '$bln_plan_5[$i]', bln_6 = '$bln_plan_6[$i]', bln_7 = '$bln_plan_7[$i]', bln_8 = '$bln_plan_8[$i]', bln_9 = '$bln_plan_9[$i]', bln_10 = '$bln_plan_10[$i]', bln_11 = '$bln_plan_11[$i]', bln_12 = '$bln_plan_12[$i]', bln_13 = '$bln_plan_13[$i]', bln_14 = '$bln_plan_14[$i]', bln_15 = '$bln_plan_15[$i]', bln_16 = '$bln_plan_16[$i]', bln_17 = '$bln_plan_17[$i]', bln_18 = '$bln_plan_18[$i]', bln_19 = '$bln_plan_19[$i]', bln_20 = '$bln_plan_20[$i]', bln_21 = '$bln_plan_21[$i]', bln_22 = '$bln_plan_22[$i]', bln_23 = '$bln_plan_23[$i]', bln_24 = '$bln_plan_24[$i]', bln_25 = '$bln_plan_25[$i]', bln_26 = '$bln_plan_26[$i]', bln_27 = '$bln_plan_27[$i]', bln_28 = '$bln_plan_28[$i]', bln_29 = '$bln_plan_29[$i]', bln_30 = '$bln_plan_30[$i]', bln_31 = '$bln_plan_31[$i]',pic1 = '$pic1[$i]',pic2 = '$pic2[$i]',ket = '$ket[$i]' WHERE no = '$aidi' ");
		if ($update) {
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL=/iotmtc/assy/cs_prev/1m.php">';
	}
	else{
		echo "Gagal mengirim...!";
	}
	} else {

    $insert = pg_query($koneksi,"INSERT INTO dbmaintenance_assy.planprev_assy (urut,shop,line,item,jml_mesin,tanggal,bln,thn,bln_1,bln_2,bln_3,bln_4,bln_5,bln_6,bln_7,bln_8,bln_9,bln_10,bln_11,bln_12,bln_13,bln_14,bln_15,bln_16,bln_17,bln_18,bln_19,bln_20,bln_21,bln_22,bln_23,bln_24,bln_25,bln_26,bln_27,bln_28,bln_29,bln_30,bln_31,pic1,pic2,ket) VALUES ('$i','$shop[$i]','$line[$i]','$item[$i]','$jml_mesin[$i]','$tanggal','$blnz','$thnz','$bln_plan_1[$i]','$bln_plan_2[$i]','$bln_plan_3[$i]','$bln_plan_4[$i]','$bln_plan_5[$i]','$bln_plan_6[$i]','$bln_plan_7[$i]','$bln_plan_8[$i]','$bln_plan_9[$i]','$bln_plan_10[$i]','$bln_plan_11[$i]','$bln_plan_12[$i]','$bln_plan_13[$i]','$bln_plan_14[$i]','$bln_plan_15[$i]','$bln_plan_16[$i]','$bln_plan_17[$i]','$bln_plan_18[$i]','$bln_plan_19[$i]','$bln_plan_20[$i]','$bln_plan_21[$i]','$bln_plan_22[$i]','$bln_plan_23[$i]','$bln_plan_24[$i]','$bln_plan_25[$i]','$bln_plan_26[$i]','$bln_plan_27[$i]','$bln_plan_28[$i]','$bln_plan_29[$i]','$bln_plan_30[$i]','$bln_plan_31[$i]','$pic1[$i]','$pic2[$i]','$ket[$i]')");
    
		if ($insert) {
		echo '<META HTTP-EQUIV="Refresh" Content="0; URL= /iotmtc/assy/cs_prev/1m.php">';
    }else{
      echo "Gagal mengirim...!";
	
}
	
	}
  
	}
	
	
   }
	
// }
 ?>
