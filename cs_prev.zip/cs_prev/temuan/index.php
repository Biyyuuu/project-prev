<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>dashboard - maintenance Smart factory</title>

  <!-- Google Font: Source Sans Pro -->
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../../dist/css/adminlte.min.css">
        <!-- jQuery -->
        <script type="text/javascript" src="../../../plugins/assets/js/jquery-3.3.1.js"></script>
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
 <?php include "../../../navbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar  sidebar-light-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../index.php" class="brand-link">
      <img src="/iotmtc/dist/img/icon.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-DARK">MAINTENANCE</span>
    </a>
    <!-- Sidebar -->
    <?php
    include "../../sidebar.php";
    ?>
        <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid"> 
        
      
 


<!doctype html>
<html lang="en">
  	<head>
	    <!-- Required meta tags -->
	    <meta charset="utf-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Aplikasi CRUD dengan PHP, MySQLi, Ajax, DataTables ServerSide, dan Bootstrap 4">
	    <meta name="keywords" content="Aplikasi CRUD dengan PHP, MySQLi, Ajax, DataTables ServerSide, dan Bootstrap 4">
		<!-- favicon -->
    	<link rel="shortcut icon" href="../../../assets/img/icon.png">
	    <!-- Bootstrap CSS -->
	    <!-- DataTables CSS -->
        <!-- datepicker CSS -->
	    <!-- Font Awesome CSS -->
	    <!-- Custom CSS -->
        <!-- Fungsi untuk membatasi karakter yang diinputkan -->
        <script type="text/javascript" src="../../../assets/js/fungsi_validasi_karakter.js"></script>
        <!-- jQuery -->
        <script type="text/javascript" src="../../../assets/js/jquery-3.3.1.js"></script>

	    <title>Perbaikan MTC</title>
  	</head>
  	<body>
  		

		<div class="container-fluid">
		<?php
        // fungsi untuk menampilkan halaman
        // tampilkan halaman tampil data pada saat aplikasi pertama dijalankan
        if (empty($_GET["page"])) {
            include "data.php";
        } 
        // jika halaman = tambah, maka tampilkan halaman form tambah data
        elseif ($_GET['page']=='tambah') {
            include "form_tambah.php";
        } 
        // jika halaman = ubah, maka tampilkan halaman form ubah data
        elseif ($_GET['page']=='ubah') {
            include "form_ubah2.php";
        } 
        ?>
		</div>
        <div class="container-fluid">
            <footer class="pt-4 my-md-4 pt-md-3 border-top">
                <div class="row">
                    <div class="col-12 col-md center">
                        &copy; <a class="text-info" href="">Maintenance</a>
                    </div>
                </div>
            </footer>
        </div>
	    <!-- Optional JavaScript -->
	    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <!-- fontawesome js -->
        <!-- DataTables js -->
	    <!-- <script type="text/javascript" src="../../../assets/plugins/DataTables/js/jquery.dataTables.min.js"></script> -->
        <!-- datepicker js -->

       
  	</body>
</html>
 </div>
    </div>  
  <!-- /.content-wrapper -->
</div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<!-- <script src="../plugins/jquery/jquery.min.js"></script> -->
<!-- Bootstrap 4 -->
<script src="../../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../../dist/js/adminlte.min.js"></script>
<!-- ChartJS -->
<!-- AdminLTE for demo purposes -->
<script src="../../../dist/js/demo.js"></script>




</html>