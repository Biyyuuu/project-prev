<?php
include '../../koneksi.php';
//select.php 
if(isset($_POST["employee_id"]))
{
// $foto = $row["foto"];
 $output = '';
 
 $query = "SELECT * FROM dbmaintenance_assy.aktual_cs WHERE id = '".$_POST["employee_id"]."'";
 $result = pg_query($koneksi, $query);
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = pg_fetch_array($result))
    {
     $output .= '
    <tr>  
            <td width="30%"><label>Unit</label></td>  
            <td width="70%">'.$row["unit"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Item Check</label></td>  
            <td width="70%">'.$row["item_check"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Standart</label></td>  
            <td width="70%">'.$row["standart"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Metode</label></td>  
            <td width="70%">'.$row["metode"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Periode</label></td>  
            <td width="70%">'.$row["periode"].'</td>  
    </tr>

    <tr>  
            <td width="30%"><label>Shop</label></td>  
            <td width="70%">'.$row["shop"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Line</label></td>  
            <td width="70%">'.$row["line"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>Mesin</label></td>  
            <td width="70%">'.$row["mesin"].'</td>  
    </tr>
    <tr>  
            <td width="30%"><label>No Mesin</label></td>  
            <td width="70%">'.$row["no_mesin"].'</td>  
    </tr>
     ';
    }
    $output .= '</table></div>';
    echo $output;
}
?>