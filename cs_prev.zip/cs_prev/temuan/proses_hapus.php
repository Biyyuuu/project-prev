<?php
// panggil file config.php untuk koneksi ke database
include '../koneksi.php';
// jika tombol simpan diklik
if (isset($_GET['id'])) {
    // ambil data get dari form 
    $id = $_GET['id'];

    // perintah query untuk menampilkan data foto pegawai berdasarkan nip
    // $result = pg_query("SELECT foto FROM dbmaintenance.tbdaily_stopassy WHERE id='$id'")
    //                           or die('Ada kesalahan pada query tampil data nik: '.$mysqli->error);
    // $data = $result->fetch_assoc();
    // $foto = $data['foto'];

    // hapus file foto dari folder foto
//$hapus_file = unlink("foto/$foto");
    // cek hapus file
//if ($hapus_file) {
        // jika file berhasil dihapus jalankan perintah query untuk menghapus data pada tabel pegawai
        $delete = pg_query($koneksi,"DELETE FROM dbmaintenance.tbdaily_stopassy WHERE id='$id'");
        // cek hasil query
        if ($delete) {
            // jika berhasil tampilkan pesan berhasil delete data
            header("location: index.php?alert=3");
        }
//}
}
// tutup koneksi
$mysqli->close();   
?>