<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="dk.png">
	<title>oke</title>
    <link rel="stylesheet" type="text/css" href="../../tambah_mesin/css/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="../../tambah_mesin/css/font-awesome.min.css">
</head>
<body>
	  <a class="navbar-brand text-white" href="index.php">
	   
	  </a>
      <!-- <a class="btn btn-outline-success" href="export.php" role="button"><i class="fas fa-file-excel"></i></a> -->

<div id="dataModal" class="modal fade">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detail Data Temuan</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
            <div class="modal-body" id="detail_karyawan">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div> 
     <!----------------------------------------------------------------------------------->
        <!-----------------------------------Modal-Edit------------------------------------>
        <!----------------------------------------------------------------------------------->

        <div class="modal fade bd-example-modal-lg" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModal" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Data Temuan</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <!-- <form method="post" enctype="multipart/form-data"> -->
                        <div class="modal-body" id="form_edit"></div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    <form method="post" >
      <input type="month" name="cari" >
      <input type="submit" name="" value="Search">
   </form>
   <?php
   	if (isset($_POST['cari'])) {
   		$tanggal_leader = $_POST['cari'];
   	}
   ?>

<form method="post" action="export.php" >
   	<input type="month" name="cari" value="<?=$tanggal_leader?>" hidden >
   	<button type="submit" > <i style="color:green"; class="fas fa-file-excel"></i></button>
   </form>
		<div class="table-responsive">
			<table id="data" class="table table-striped table-bordered" style="width:100%">
			    <thead>
			        <tr>
			            <td style="text-align:center">No</td>
			            <td style="text-align:center">Tanggal Temuan</td>
                        <td style="text-align:center">Shop</td>
                        <td style="text-align:center">Line</td>
                        <td style="text-align:center">Mesin</td>
                        <td style="text-align:center">No Mesin</td>
			            <td style="text-align:center">Periode</td>
			            <td style="text-align:center">Unit</td>
			            <td style="text-align:center">Hasil</td>
			            <td style="text-align:center">Keterangan Temuan</td>
			            <td style="width: 10%; text-align:center">Opsi</td>
			        </tr>
			    </thead>
			    <tbody>
			        <?php
                    include '../../koneksi.php';
			            $no = 1;
			            if (isset($_POST['cari'])){
                            $cari = $_POST['cari'];
                            $query = "SELECT * FROM dbmaintenance_assy.aktual_cs where hasil = 'X' AND hasil_sdh = ''  AND tanggal like '%$cari%'  ";
                        }else{
                            $query = "SELECT * FROM dbmaintenance_assy.aktual_cs where hasil = 'X'  AND hasil_sdh = '' order by tanggal desc";}
                            $dewan1 = $db1->prepare($query);
                            $dewan1->execute();
                            $res1 = $dewan1->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($res1 as $row) {
		                	$id = $row['id'];
		                    $unit = $row['unit'];
		                    $item_check = $row['item_check'];
		                    $standart = $row['standart'];
		                    $metode = $row['metode'];
		                    $periode = $row['periode'];
                            $shop = $row['shop'];
                            $mesin = $row['mesin'];
							$line = $row['line'];
							$ket_sblm = $row['ket_sblm'];
							$hasil = $row['hasil'];
							$tanggal = $row['tanggal'];
							$no_check = $row['no_check'];
							$no_mesin = $row['no_mesin'];

			        ?>
			            <tr>
			                <td style="text-align:center"><?= $no++ ?></td>
			                <td style="text-align:center"><?= $tanggal ?></td>
                            <td style="text-align:center"><?= $shop?></td>
			                <td style="text-align:center"><?= $line?></td>
			                <td style="text-align:center"><?= $mesin?></td>
			                <td style="text-align:center"><?= $no_mesin?></td>
			                <td style="text-align:center"><?= $periode?></td>
                            <td style="text-align:center"><?= $unit?></td>
			                <td style="text-align:center"><?=$hasil?></td>
			                <td style="text-align:center"><?= $ket_sblm?></td>
			                <td>
			               		<!-- <input type="button" name="view" id="<?php echo $row["id"]; ?>" value='Detail'  class='btn btn-primary  view_data'   />
			               		<a href="form_ubah2.php?id=<?= $id ?>" style='font-size: 11px;' class='btn btn-primary'><p title="edit" class="fas fa-check-square"></p></a>
			                	<a href="proses_hapus.php?id=<?= $id ?>" style='font-size: 11px;' class='btn btn-primary' onclick = "return confirm('Yakin di hapus....?')"><p title="Hapus" class="fas fa-trash"></p></a> -->
                                <input type="button" name="edit" value="Action" Style="font-size:20px;height:50px;width:90px" id="<?php echo $row["id"]; ?>" class="btn btn-primary btn-xs edit_data" /> 

			               	</td>
			            </tr>
			        <?php } ?>
			    </tbody>
			</table>
		</div>
	
    <!-- Untuk Keperluan Demo Saya Menggunakan JQuery Online, Jika sobat menggunakan untuk keperluan developmen/production maka download JQuery pada situs resminya -->
    <!-- JQuery -->
    <script src="js/jquery.min.js"></script>
	<!-- Bootstrap -->
    <!-- DataTable -->
  	<script src="../../tambah_mesin/js/datatables.min.js"></script>

	<script type="text/javascript">
	    $(document).ready(function() {
	        let table = $('#data').DataTable();

	        $('#data tbody').on( 'click', '#detail', function () {
		        var current_row = $(this).parents('tr');
		        if (current_row.hasClass('child')) {
		            current_row = current_row.prev();
		        }
		        var data = table.row( current_row ).data();
		        console.log(data)

		        document.getElementById("id").value = data[0];
		        document.getElementById("part_name").value = data[1];
		        document.getElementById("stock").value = data[2];
		        document.getElementById("loc2").value = data[3];
		        document.getElementById("harga").value = data[4];
		        document.getElementById("status").value = data[5];

		        $("#viewModal").modal("show");
		    });

	    });
	</script>
	 <script>  
    $(document).ready(function(){
    // Begin Aksi Insert
     $('#insert_form').on("submit", function(event){  
      event.preventDefault();  
      if($('#nama').val() == "")  
      {  
       alert("Mohon Isi Nama ");  
      }  
      else if($('#alamat').val() == '')  
      {  
       alert("Mohon Isi Alamat");  
      }  
     
      else  
      {  
       $.ajax({  
        url:"insert.php",  
        method:"POST",  
        data:$('#insert_form').serialize(),  
        beforeSend:function(){  
         $('#insert').val("Inserting");  
        },  
        success:function(data){  
         $('#insert_form')[0].reset();  
         $('#add_data_Modal').modal('hide');  
         $('#tabel-pegawai').html(data);  
        }  
       });  
      }  
     });
    //END Aksi Insert
    
    //Begin Tampil Detail Karyawan
     $(document).on('click', '.view_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"select.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
        $('#detail_karyawan').html(data);
        $('#dataModal').modal('show');
       }
      });
     });
    //End Tampil Detail Karyawan
     
    //Begin Tampil Form Edit
    $(document).on('click', '.edit_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"edit.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
        $('#form_edit').html(data);
        $('#editModal').modal('show');
       }
      });
     });
    //End Tampil Form Edit
    
    //Begin Aksi Delete Data
     $(document).on('click', '.hapus_data', function(){
      var employee_id = $(this).attr("id");
      $.ajax({
       url:"delete.php",
       method:"POST",
       data:{employee_id:employee_id},
       success:function(data){
       $('#tabel-pegawai').html(data);  
       }
      });
     });
    }); 
    //End Aksi Delete Data
</script>
</body>
</html>