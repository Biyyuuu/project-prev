<?php
error_reporting(0);
$waktu_default = 21600;//21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
$tanggal_sekarang = date('Y-m-d' ,time() + $waktu_default);
$bulan_sekarang = gmdate('m', $waktu_indonesia);
include '../koneksi.php';
$data1 = $_POST['line'];
$data2 = $_POST['no_mesin'];
$data3 = $_POST['shop'];
$data31 = $_POST['code_shop'];
$data4 = $_POST['mesin'];
$data41 = $_POST['op'];
$no = pg_query($koneksi, "SELECT * FROM dbmaintenance.tbdaily_stopassy");
while ($d = pg_fetch_array($no)) {
	$no1 = $d['id'];
}


$ambil = substr($contoh, 8,2);
echo $ambil;

$number = $no1 + 1;
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/iotmtc/plugins/bs-stepper/css/bs-stepper.min.css">
  <link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- /.card -->
        <!-- /.row -->

        <div class="row" style="align-middle">
          <div class="col-md-12" style="align-self: center;">
            <div class="card card-default">
              
                <div class="bs-stepper" >
                  <div class="bs-stepper-header" role="tablist">
                    <!-- your steps here -->
                    <div class="step" data-target="#logins-part">
                      <!-- <button type="button" class="step-trigger" role="tab" aria-controls="logins-part">
                        <span class="bs-stepper-circle">1</span>
                        <span class="bs-stepper-label">Step 1</span>
                      </button> -->
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <!-- <button type="button" class="step-trigger" role="tab" aria-controls="information-part">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">Step 2</span>
                      </button> -->
                    </div>
                  </div>
                    <!-- your steps content here -->
                    <!-- <div id="logins-part" class="content" role="tabpanel" aria-labelledby="logins-part-trigger"> -->
			    	<form  method="post"  enctype="multipart/form-data" >
					  		<div class="col">
			<div class="form-group col-md-12" hidden="">
			<label>No</label>
			<input type="number" name="no" class="form-control" value="<?= $number ?>" readonly="readonly">
		</div>
			<div class="form-group col-md-12">
			<label>Shop</label>
			<td>
				<select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data3 ?>"><?=  $data3 ?></option>
					<?php 
					$sql2 = pg_query($koneksi, "SELECT shop FROM dbmaintenance.no_mesin2 group by shop");
            			while ($data = pg_fetch_array($sql2)) {
            			$shop = $data['shop']; ?>
            			<option value="<?=  $shop ?>"><?php echo $data['shop'] ?></option>

        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Line</label>
				<select name="line" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data1 ?>"><?=  $data1 ?></option>
					<?php 
					$sql1 = pg_query($koneksi, "SELECT line FROM dbmaintenance.no_mesin2 where shop = '$data3' group by line");
            			while ($data = pg_fetch_array($sql1)) {
            			$line = $data['line']; ?>
            			<option value="<?=  $line ?>"><?php echo $data['line'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Line tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Mesin</label>
				<select name="mesin" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data4 ?>"><?=  $data4 ?></option>
					<?php 
					$viewww = pg_query($koneksi, "SELECT mesin FROM dbmaintenance.no_mesin2 where line = '$data1' AND shop = '$data3' group by mesin");
            			while ($drowa = pg_fetch_array($viewww)) {
            			$mesin = $drowa['mesin']; ?>
            			<option value="<?=  $mesin ?>"><?php echo $drowa['mesin'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Mesin tidak boleh kosong.</div>
		</div>
		<!----------------------------------------------------------------------------------------->
		<div class="form-group col-md-12">
			<label>No Mesin</label>
				<select name="no_mesin" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data2 ?>"><?=  $data2 ?></option>
					<?php 
					$viewww = pg_query($koneksi, "SELECT no_mesin FROM dbmaintenance.no_mesin2 where mesin = '$data4' AND line = '$data1' AND shop = '$data3' group by no_mesin");
            			while ($drowa = pg_fetch_array($viewww)) {
            			$no_mesin = $drowa['no_mesin']; ?>
            			<option value="<?=  $no_mesin ?>"><?php echo $drowa['no_mesin'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Mesin tidak boleh kosong.</div>
		</div>
		<!----------------------------------------------------------------------------------------->
		<div class="form-group col-md-12">
			<label>Tanggal</label>
			<td><input type="date" class="form-control" name="tanggal" value="" required=""></td>
		</div>
		<div class="form-group col-md-12">
			<label>Shift</label>
				<select class="form-control" name="shift">
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
			<div class="invalid-feedback">Shift tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 1</label>
			<select class="form-control" name="cat_1" autocomplete="off" >
				<option value=""></option>
				<option value="Suddenly Trouble">1. Suddenly Trouble</option>
				<option value="Postpone Repair">2. Postpone Repair</option>
				<option value="Preventive MTC">3. Preventive MTC</option>
				<option value="MTC Prediction">4. MTC Prediction</option>
				<option value="Corective MTC">5. Corective MTC</option>
				<option value="Inspection MTC">6. Inspection MTC</option>
				<option value="Improvement">7. Improvement</option>
				<option value="Lay Out">8. Lay Out</option>
				<option value="Other">Other</option>
			</select>
		       <div class="invalid-feedback">Categori 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 2</label>
			<select class="form-control" name="cat_2" autocomplete="off" >
				<option value=""></option>
				<option value="(E) Electric">(E) Electric</option>
				<option value="(M) Mechanic">(M) Mechanic</option>
				<option value="(H) Hydroulic">(H) Hydroulic</option>
				<option value="(P) Pneumatic">(P) Pneumatic</option>
				<option value="Other">Other</option>
			</select>
	    <div class="invalid-feedback">Categori 2 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Item Trouble / Problem Masalah</label>
	       <input type="text" name="bagian_machine" class="form-control"  autocomplete="off"  required>
	       <div class="invalid-feedback">Item  Trouble / Problem Masalah tidak boleh kosong.</div>
		</div>
	</div>
  <!-- <button class="btn btn-info" onclick="stepper.next()">Next</button>
  <button type="button"  class="btn btn-danger" onclick="javascript:window.close()">Close</button> -->
	</div>
	<div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
	 <div class="form-group">
    <div class="col">
				<div class="form-group col-md-12">
					<label>Analisa Penyebab</label>
					<textarea class="form-control" rows="2" name="analisa" autocomplete="off" required></textarea>
					<div class="invalid-feedback">Analisa Penyebab tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Tindakan Perbaikan</label>
					<textarea class="form-control" rows="2" name="kerusakan" autocomplete="off" ></textarea>
					<div class="invalid-feedback">Tindakan Perbaikan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Tindakan Pencegahan</label>
					<textarea class="form-control" rows="2" name="pencegahan" autocomplete="off" ></textarea>
					<div class="invalid-feedback">Tindakan Perbaikan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Next Action</label>
					<textarea class="form-control" rows="2" name="action" autocomplete="on" required></textarea>
					<div class="invalid-feedback">Next Action tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Stop Line</label>
					<input type="number" class="form-control" name="waktu_stop"  autocomplete="off"  required>
				<div class="invalid-feedback">Stop Line tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Persiapan</label>
						<td><input type="number" id="txt1" onkeyup="sum();" class="form-control" name="mttr_persiapan" value="<?= $mttr_persiapan ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Persiapan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
				<label>MTTR Check</label>
			    <td><input type="number" id="txt2" onkeyup="sum();" class="form-control" name="mttr_check" value="<?= $mttr_check ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Check tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Tunggu Part</label>
		        <td><input type="number" id="txt3" onkeyup="sum();" class="form-control" name="mttr_tunggu_part" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Repair</label>
		        <td><input type="number" id="txt4" onkeyup="sum();" class="form-control" name="mttr_repair" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Repair tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
		     		<label>MTTR Setting</label>
		        <td><input type="number" id="txt5" onkeyup="sum();" class="form-control" name="mttr_setting" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Setting tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Perapihan</label>
		        <td><input type="number" id="txt6" onkeyup="sum();" class="form-control" name="mttr_perapihan" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Perapihan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
	     			<label>MTTR Total</label>
	           <td><input type="text" id="txt7" class="form-control" readonly>&nbspMenit</td>
	      <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
		</div>
		<!----------------------------------------------------------------------------------------->
		<div class="form-group col-md-12">
			<label>Pic 1</label>
			<select name="pic_1" class="form-control" autocomplete="off" required="">
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic1 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($d = pg_fetch_array($pic1)) {
           	$nama = $d['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $d['nama'] ?></option>
        	<?php }  ?>
			</select>
			<div class="invalid-feedback">Pic 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 2</label>
			<select name="pic_2" class="form-control" >
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic2 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($dd = pg_fetch_array($pic2)) {
           	$nama = $dd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $dd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 3</label>
			<select name="pic_3" class="form-control">
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic3 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($ddd = pg_fetch_array($pic3)) {
           	$nama = $ddd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $ddd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
	</div>
	<div class="form-group col-md-3">
				<label>Foto Sebelum</label>
    			<input type="file" class="form-control-file mb-3" id="foto" name="foto" onchange="return validasiFile()" autocomplete="off" >
				<div id="imagePreview"><img class="foto-preview" src="foto/default_user.png"/></div>
				<div class="invalid-feedback">Foto Perbaikan tidak boleh kosong.</div>
			</div> 
			<div class="form-group col-md-3">
				<label>Foto Sesudah</label>
    			<input type="file" class="form-control-file mb-3" id="foto1" name="foto1" onchange="return validasiFile()" autocomplete="off" >
				<div id="imagePreview"><img class="foto-preview" src="foto/default_user.png"/></div>
				<div class="invalid-feedback">Foto Sesudah tidak boleh kosong.</div>
			</div>
  </div>
  <button class="btn btn-primary" onclick="stepper.previous()">Previous</button>
  <input type="submit" class="btn btn-success btn-submit" name="kirim" value="Kirim">
  <input type="reset" class="btn btn-warning btn-submit" value="Reset"/> 
  <button type="button"  class="btn btn-danger" onclick="javascript:window.close()">Close</button>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </section>
  </div>
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<?php
$waktu_default = 21600;//21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
$tanggal_sekarang = date('H-i-s' ,time() + $waktu_default);
$tgl = date('d' ,time() + $waktu_default);

$index_list1 = [
	'no','tanggal','shop','line','machine','no_machine','shift',
	'waktu_stop','bagian_machine','kerusakan','analisa','action',
	'pic_1','pic_2','pic_3','cat_1','cat_2','wkt_kerja','foto',
	'tgl_temu','shift_temu','foto1','mttr_persiapan','mttr_check',
	'mttr_tunggu_part','mttr_repair','mttr_setting','mttr_perapihan'
];

if (isset($_POST['kirim'])) {
$tanggal_isi 	  = $_POST['tanggal'];
$isi 			  = substr($tanggal_isi, 8,2);
$shop 			  = $_POST['shop'];
$line 			  = $_POST['line'];
$no_mesin 		  = $_POST['no_mesin'];
$machine 		  = $_POST['mesin'];
$shift 			  = $_POST['shift'];
$bagian_machine   = $_POST['bagian_machine'];
$kerusakan 		  = $_POST['kerusakan'];
$analisa 		  = $_POST['analisa'];
$action 		  = $_POST['action'];
$pic_1 			  = $_POST['pic_1'];
$pic_2 			  = $_POST['pic_2'];
$pic_3 			  = $_POST['pic_3'];
$number1 		  = $_POST['no'];
$waktu_stop       = $_POST['waktu_stop'];
$id 			  = $_POST['id'];
$cat_1 			  = $_POST['cat_1'];
$cat_2 			  = $_POST['cat_2'];
$wkt_kerja 		  = $_POST['wkt_kerja'];
$mttr_persiapan   = $_POST['mttr_persiapan'];
$mttr_check 	  = $_POST['mttr_check'];
$mttr_tunggu_part = $_POST['mttr_tunggu_part'];
$mttr_repair 	  = $_POST['mttr_repair'];
$mttr_setting 	  = $_POST['mttr_setting'];
$mttr_perapihan   = $_POST['mttr_perapihan'];
$pencegahan   	  = $_POST['pencegahan'];
$nama_file        = $_FILES['foto']['name'];    
$tmp_file      	  = $_FILES['foto']['tmp_name']; 
$nama_file1       = $_FILES['foto1']['name'];    
$tmp_file1     	  = $_FILES['foto1']['tmp_name']; 
///////////////////////////////////////////////////////////////////////////////////////////////////
include '../koneksi.php';
  $selSto =pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 WHERE shop ='$data3'");
  $sto    =pg_fetch_array($selSto);
  $code_shop =$sto['code_shop'];
///////////////////////////////////////////////////////////////////////////////////////////////////
// Set path folder tempat menyimpan filenya   
  $path             = "foto/";
  move_uploaded_file($tmp_file, $path.$nama_file);
  move_uploaded_file($tmp_file1, $path.$nama_file1);

  for ($i=0; $i < count($index_list1); $i++) { 
	$index_form[$i] = $_POST[$index_list1[$i]];
	//echo $i.'='. $index_form[$i].'<br>';
}
echo $index_form[6].'--';

$waktu_1 = 0;
$waktu_2 = 0;
$waktu_3 = 0;

	if ($index_form[6] == '1') {
		$waktu_1 = $index_form[7];
	}
	elseif ($index_form[6] == '2') {
		$waktu_2 = $index_form[7];
	}
	elseif ($index_form[6] == '3') { 
		$waktu_3 = $index_form[7];
	}


    // jika nik belum ada
      
        // upload file
            $insert = pg_query($koneksi,"INSERT INTO dbmaintenance.tbdaily_stopassy(tanggal, time_1, time_2, time_3, no_id,code_shop, shop, line1, machine, no_machine, shift, bagian_machine, kerusakan, analisa, action, pic_1, pic_2, pic_3, no, tgl_key, cat_1, cat_2, foto,foto1,mttr_persiapan,mttr_check,mttr_tunggu_part,mttr_repair,mttr_setting,mttr_perapihan,pencegahan) VALUES (NOW(),'$waktu_1','$waktu_2','$waktu_3','$isi','$code_shop' ,'$shop','$line','$machine' ,'$no_mesin','$shift','$bagian_machine','$kerusakan','$analisa','$action','$pic_1','$pic_2','$pic_3','$number1','$tanggal_isi','$cat_1','$cat_2','$nama_file','$nama_file1','$mttr_persiapan','$mttr_check','$mttr_tunggu_part','$mttr_repair','$mttr_setting','$mttr_perapihan','$pencegahan')"); 

			// $insert = pg_query($koneksi_pg,"INSERT INTO dbmaintenance.tbdaily_stopassy(tanggal, time_1, time_2, time_3, no_id,code_shop, shop, line1, machine, no_machine, shift, bagian_machine, kerusakan, analisa, action, pic_1, pic_2, pic_3, no, tgl_key, cat_1, cat_2, foto,foto1,mttr_persiapan,mttr_check,mttr_tunggu_part,mttr_repair,mttr_setting,mttr_perapihan,pencegahan) VALUES (NOW(),2,0,0,2,2 ,'2','2','2' ,'2','2','2','2','2','2','2','2','2','2','2202-02-02','2','2','2','2','2','2','2','2','2','2','2')");
            // cek query
            if ($insert) {
            	$deletin = pg_query($koneksi,"DELETE FROM dbmaintenance.tbdaily_stopassy where shop = '' ");
                // jika berhasil tampilkan pesan berhasil simpan data
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=">';
        }   
      
    }
?>
<!-- Tempusdominus Bootstrap 4 -->
<!-- Bootstrap Switch -->
<script src="/iotmtc/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<!-- Page specific script -->
<script>
  // BS-Stepper Init
  document.addEventListener('DOMContentLoaded', function () {
    window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  })
  // DropzoneJS Demo Code End
  function sum(){
	var txtFirstNumberValue = document.getElementById('txt1').value;
	var txtSecondNumberValue = document.getElementById('txt2').value;
	var txtThirdNumberValue = document.getElementById('txt3').value;
	var txtFourthNumberValue = document.getElementById('txt4').value;
	var txtFifthNumberValue = document.getElementById('txt5').value;
	var txtSixthNumberValue = document.getElementById('txt6').value;
	var result = parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue) + parseInt(txtThirdNumberValue) + parseInt(txtFourthNumberValue) + parseInt(txtFifthNumberValue) + parseInt(txtSixthNumberValue);
	if (!isNaN(result)){
		document.getElementById('txt7').value = result;
	}
}
</script>
</body>
</html>
