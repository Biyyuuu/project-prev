<?php 
// panggil file config.php untuk koneksi ke database
require_once "config/config.php";
// panggil fungsi untuk format tanggal

$waktu_indonesia = time() + (60 * 60 * 7);
  $tanggal = gmdate('Y-m', $waktu_indonesia);

header("Content-Type: application/force-download");
header("Cache-Control: no-cache, must-revalidate");
header("content-disposition: attachment;filename=DATA-PDLP-Assy.xls");
if(isset($_POST['cari'])){
    $tanggal_cari = $_POST['cari'];
}else{
    $tanggal_cari = $tanggal;
}

$blnzi = substr($tanggal_cari,5);
$thnz = substr($tanggal_cari,0,4);



echo $blnzi;
echo $thnz;
?>

<!-- Buat Table saat di Export Ke Excel -->
<center>
	<h3>DATA PDLP Assy</h3>
</center>

<table border='1'>
	<h3>
		<thead>
			<tr>
                <th align="center" valign="middle">No</th>
				<th align="center" valign="middle">Tanggal Isi</th>
                <th align="center" valign="middle">Tanggal Kejadian</th>
                <th align="center" valign="middle">Shop</th>
                <th align="center" valign="middle">Line</th>
                <th align="center" valign="middle">Machine</th>
                <th align="center" valign="middle">No Machine</th>
                <th align="center" valign="middle">Categori 1</th>
                <th align="center" valign="middle">Categori 2</th>
                <th align="center" valign="middle">Shift</th>
                <th align="center" valign="middle">Stop Line Shift 1</th>
                <th align="center" valign="middle">Stop Line Shift 2</th>
                <th align="center" valign="middle">Stop Line Shift 3</th>
                <th align="center" valign="middle">Waktu Pengerjaan</th>
                <th align="center" valign="middle">Item Trouble / Problem Masalah</th>
                <th align="center" valign="middle">Analisa Penyebab</th>
                <th align="center" valign="middle">Tindakan Perbaikan</th>
                <th align="center" valign="middle">Next Action</th>
                <th align="center" valign="middle">Pic 1</th>
                <th align="center" valign="middle">Pic 2</th>
                <th align="center" valign="middle">Pic 3</th>
                <th align="center" valign="middle">MTTR Persiapan</th>
                <th align="center" valign="middle">MTTR Check</th>
                <th align="center" valign="middle">MTTR Tunggu Part</th>
                <th align="center" valign="middle">MTTR Repair</th>
                <th align="center" valign="middle">MTTR Setting</th>
                <th align="center" valign="middle">MTTR Perapihan</th>
			</tr>
		</thead>
	</h3>

	<tbody>
	<?php  
    $no = 1;
    // fungsi query untuk menampilkan data dari tabel pegawai
    $result = $mysqli->query("SELECT * FROM dbmaintenance.tbdaily_stopassy order by tgl_key desc ")
                              or die('Ada kesalahan pada query tampil data member: '.$mysqli->error);
    $rows = $result->num_rows;
    // jika data ada, tampilkan data
    if ($rows > 0) {
        while ($data = $result->fetch_assoc()) { ?>
			<tr>
			    <td align="center" valign="top"><?php echo $no; ?></td>
                <td align="center" valign="top"><?php echo $data['tanggal']; ?></td>
                <td align="center" valign="top"><?php echo $data['tgl_key']; ?></td>
                <td align="center" valign="top"><?php echo $data["shop"]; ?></td>
                <td align="center" valign="top"><?php echo $data["line1"]; ?></td>
                <td align="center" valign="top"><?php echo $data["machine"]; ?></td>
                <td align="center" valign="top"><?php echo $data["no_machine"]; ?></td>
                <td align="center" valign="top"><?php echo $data["cat_1"]; ?></td>
                <td align="center" valign="top"><?php echo $data["cat_2"]; ?></td>
                <td align="center" valign="top"><?php echo $data["shift"]; ?></td>
                <td align="center" valign="top"><?php echo $data["time_1"]; ?></td>
                <td align="center" valign="top"><?php echo $data["time_2"]; ?></td>
                <td align="center" valign="top"><?php echo $data["time_3"]; ?></td> 
                <td align="center" valign="top"><?php echo $data["wkt_kerja"]; ?></td>
                <td align="center" valign="top"><?php echo $data["bagian_machine"]; ?></td>
                <td align="center" valign="top"><?php echo $data["kerusakan"]; ?></td>
                <td align="center" valign="top"><?php echo $data["analisa"]; ?></td>
                <td align="center" valign="top"><?php echo $data["action"]; ?></td>
                <td align="center" valign="top"><?php echo $data["pic_1"]; ?></td>
                <td align="center" valign="top"><?php echo $data["pic_2"]; ?></td>
                <td align="center" valign="top"><?php echo $data["pic_3"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_persiapan"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_check"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_tunggu_part"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_repair"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_setting"]; ?></td>
                <td align="center" valign="top"><?php echo $data["mttr_perapihan"]; ?></td>
			</tr>
		<?php
			$no++;
		}
	// jika data tidak ada, tampilkan tabel kosong
	} else { ?>
		<tr>
		    <td align="center" valign="top"></td>
            <td align="center" valign="top"></td>
            <td valign="top"></td>
            <td valign="top"></td>
            <td align="center" valign="top"></td>
            <td align="center" valign="top"></td>
            <td valign="top"></td>
            <td align="center" valign="top"></td>
		</tr>
	<?php
	}
	?>
	</tbody>
</table>

<div style="text-align: right">
    <h4>Maintenance</h4>
</div>