
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="dk.png">
	<title>oke</title>
	<!-- Bootstrap -->
    <!-- Datatable -->
    <link rel="stylesheet" type="text/css" href="css/datatables.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
   <script type="text/javascript" src="../../plugins/assets/js/fungsi_validasi_karakter.js"></script>
        <!-- jQuery -->
        <script type="text/javascript" src="../../plugins/assets/js/jquery-3.3.1.js"></script>
</head>
<body>
	 <!--  <a class="navbar-brand text-white" href="index.php">
	   
	  </a>
	 -->
	<!-- <div class="container mb-5"> -->
		<h2 align="center" style="margin: 30px;"></h2>
				<!-- favicon -->
    	<link rel="shortcut icon" href="../assets/img/icon.png">
	    <!-- Bootstrap CSS -->
	    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
	    <!-- DataTables CSS -->
	    <link rel="stylesheet" type="text/css" href="../assets/plugins/DataTables/css/dataTables.bootstrap4.min.css">
        <!-- datepicker CSS -->
        <link rel="stylesheet" type="text/css" href="../assets/plugins/datepicker/css/datepicker.min.css">
	    <!-- Font Awesome CSS -->
	    <link rel="stylesheet" type="text/css" href="../assets/plugins/fontawesome-free-5.4.1-web/css/all.min.css">
	    <!-- Custom CSS -->
	    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
        <!-- Fungsi untuk membatasi karakter yang diinputkan -->
        <script type="text/javascript" src="../assets/js/fungsi_validasi_karakter.js"></script>
        <!-- jQuery -->
        <script type="text/javascript" src="../assets/js/jquery-3.3.1.js"></script>

		<div class="table-responsive">
			<table id="data" class="table table-striped table-bordered" style="width:100%">
			    <thead>
			        <tr>
			            <td>No</td>
			            <td>Tanggal </td>
			            <td>No Part</td>
			            <td>Nama Part</td>
			            <td>Speck</td>
			            <td>Stock Sparepart</td>
			            <td>Stock Request</td>
			             <td style="width: 15%;">Opsi</td>
			        </tr>
			    </thead>
			    <tbody>
			        <?php
			            $query = "SELECT * FROM tb_cekout WHERE status = 'Request' AND shope = 'Machining'";
			            $biu = $db1->prepare($query);
			            $biu->execute();
			            $res1 = $biu->get_result();
		                while ($row = $res1->fetch_assoc()) {
		                	$id = $row['id'];
		                    $tgl = $row['tgl'];
		                    $id_brg = $row['id_brg'];
		                    $nama_part = $row['nama_part'];
		                    $speck = $row['speck'];
		                    $jumlah = $row['jumlah'];
		                    $query2 = "SELECT * FROM tb_whs WHERE no_part = '$id_brg'";
			            $biu2 = $db1->prepare($query2);
			            $biu2->execute();
			            $res12 = $biu2->get_result();
		                while ($row2 = $res12->fetch_assoc()) {
		                    $stock = $row2['stock'];
		                }
			        ?>
			            <tr>
			                <td><?php echo $no++; ?></td>
			                <td><?php echo $tgl; ?></td>
			                <td><?php echo $id_brg; ?></td>
			                <td><?php echo $nama_part; ?></td>
			                <td><?php echo $speck; ?></td>
			                <td><?php echo $stock; ?></td>
			                <td><?php echo $jumlah; ?></td>
			                <td><!-- 
			                	<button style='font-size: 11px;' class='btn btn-primary' id='detail' name='detail' title='Lihat Detail'><i class='fa fa-search'></i></button> -->
			                	<button style='font-size: 11px;' class='btn btn-primary'><a href="form_ubah.php?id=<?= $id ?>"><i title="Ubah" class="fas fa-search"></i></a></button>
			            	</td>
			            </tr>
			        <?php } ?>
			    </tbody>
			</table>
		</div>

		<div id="viewModal" class="modal fade mr-tp-100" role="dialog">
		    <div class="modal-dialog modal-lg flipInX animated">
		        <div class="modal-content">
		            <div class="modal-header">
		                <h4 class="modal-title" id="myModalLabel" >View Data</h4>
		                <button type="button" class="close" data-dismiss="modal" >
		                    <span aria-hidden="true">&times;</span>
		                    <span class="sr-only">Close</span>
		                </button>
		            </div>
		            <div class="modal-body">
		            	<div class="form-group">
		            		<label>ID Barang</label>
		            		<input type="text" id="id" class="form-control" readonly="">
		            	</div>
		            	<div class="form-group">
		            		<label>Nama Part</label>
		            		<input type="text" id="part_name" class="form-control" readonly="">
		            	</div>
		            	<div class="form-group">
		            		<label>stock</label>
		            		<input type="text" id="stock" class="form-control" readonly="">
		            	</div>
		            	<div class="form-group">
		            		<label>loc2</label>
		            		<input type="text" id="loc2" class="form-control" readonly="">
		            	</div>
		            	<div class="form-group">
		            		<label>Harga</label>
		            		<input type="text" id="harga" class="form-control" readonly="">
		            	</div>
		            	<div class="form-group">
		            		<label>Tanggal Masuk</label>
		            		<input type="text" id="status" class="form-control" readonly="">
		            	</div>
		            </div>
		            <div class="modal-footer">
		            	<button class="btn btn-default" data-dismiss="modal">
		            		Close
		            	</button>
		            </div>
		        </div>
		    </div>
		</div>
		 <script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
        <!-- fontawesome js -->
	    <script type="text/javascript" src="../assets/plugins/fontawesome-free-5.4.1-web/js/all.min.js"></script>
        <!-- DataTables js -->
	    <script type="text/javascript" src="../assets/plugins/DataTables/js/jquery.dataTables.min.js"></script>
	    <script type="text/javascript" src="../assets/plugins/DataTables/js/dataTables.bootstrap4.min.js"></script>
        <!-- datepicker js -->
        <script type="text/javascript" src="../assets/plugins/datepicker/js/bootstrap-datepicker.min.js"></script>
   <!--  </div> -->
	
    <!-- Untuk Keperluan Demo Saya Menggunakan JQuery Online, Jika sobat menggunakan untuk keperluan developmen/production maka download JQuery pada situs resminya -->
    <!-- JQuery -->
    <script src="js/jquery.min.js"></script>
	<!-- Bootstrap -->
    <!-- DataTable -->
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- ChartJS -->
<!-- AdminLTE for demo purposes -->
  	<script src="js/datatables.min.js"></script>

	<script type="text/javascript">
	    $(document).ready(function() {
	        let table = $('#data').DataTable();

	        $('#data tbody').on( 'click', '#detail', function () {
		        var current_row = $(this).parents('tr');
		        if (current_row.hasClass('child')) {
		            current_row = current_row.prev();
		        }
		        var data = table.row( current_row ).data();
		        console.log(data)

		        document.getElementById("id").value = data[0];
		        document.getElementById("part_name").value = data[1];
		        document.getElementById("stock").value = data[2];
		        document.getElementById("loc2").value = data[3];
		        document.getElementById("harga").value = data[4];
		        document.getElementById("status").value = data[5];

		        $("#viewModal").modal("show");
		    });

	    });
	</script>
</body>
</html>