<?php
include '../koneksi.php';
$id = $_GET['id'];

  $sql = pg_query($koneksi,"SELECT * FROM dbmaintenance.tbdaily_stopassy WHERE id = '$id' ");
  while ($data=pg_fetch_array($sql)) {
$tgl_key = $data['tgl_key'];
$shift = $data['shift'];
$bagian_machine = $data['bagian_machine'];
$kerusakan = $data['kerusakan'];
$analisa = $data['analisa'];
$action = $data['action'];
$pic_1 = $data['pic_1'];
$pic_2 = $data['pic_2'];
$pic_3 = $data['pic_3'];
$pic_4 = $data['pic_4'];
$pic_5 = $data['pic_5'];
$getshop = $data['shop'];
$getline = $data['line1'];
$getmachine = $data['machine'];
$getnomachine = $data['no_machine'];
$getime1 = $data['time_1'];
$getime2 = $data['time_2'];
$getime3 = $data['time_3'];
$cat_1 = $data['cat_1'];
$cat_2 = $data['cat_2'];
$wkt_kerja = $data['wkt_kerja'];
$foto = $data['foto'];
$foto1 = $data['foto1'];
$mttr_persiapan = $data['mttr_persiapan'];
$mttr_check = $data['mttr_check'];
$mttr_tunggu_part = $data['mttr_tunggu_part'];
$mttr_repair = $data['mttr_repair'];
$mttr_setting = $data['mttr_setting'];
$mttr_perapihan = $data['mttr_perapihan'];
$mttr_total = $mttr_persiapan + $mttr_check + $mttr_tunggu_part + $mttr_repair + $mttr_setting + $mttr_perapihan;
  }

  if ($getime1 > 0) {
  	$waktu_stop = $getime1;
  }elseif ($getime2 > 0) {
  	$waktu_stop = $getime2;
  }elseif ($getime3 > 0) {
  	$waktu_stop = $getime3;
  }
   ?>

 <!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../plugins/bs-stepper/css/bs-stepper.min.css">
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- /.card -->
        <!-- /.row -->

        <div class="row" style="align-middle">
          <div class="col-md-12" style="align-self: center;">
            <div class="card card-default">
              
                <div class="bs-stepper" >
                  <div class="bs-stepper-header" role="tablist">
                    <!-- your steps here -->
                    <!-- <div class="step" data-target="#logins-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="logins-part">
                        <span class="bs-stepper-circle">1</span>
                        <span class="bs-stepper-label">Step 1</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="information-part">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">Step 2</span>
                      </button>
                    </div> -->
                  </div>
                    <!-- your steps content here -->
                    <!-- <div id="logins-part" class="content" role="tabpanel" aria-labelledby="logins-part-trigger"> -->
			    	<form  method="post"  enctype="multipart/form-data" >
					  		<div class="col">
			<div class="form-group col-md-12" hidden="">
			<label>No</label>
			<input type="number" name="id" value="<?= $id ?>" hidden="">
		</div>
		<div class="form-group col-md-12">
			<label>Shop</label>
			<td>
					<select name="shop" class="form-control">
					<option selected="" value="<?=  $getshop ?>"><?=  $getshop ?></option>
					<?php while ($data = pg_fetch_array($sql2)) { ?>
            			<option value="<?=  $shop ?>"><?php echo $data['shop'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
								</div>
		<div class="form-group col-md-12">
			<label>Line</label>
				<select name="line" class="form-control" onchange="this.form.submit();">
					<option selected="" value="<?= $getline ?>"><?=  $getline ?></option>
					<?php 
					$sql1 = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 group by line1");
						while ($data = pg_fetch_array($sql1)) { ?>
            		<option value="<?=  $line1 ?>"><?php echo $data['line1'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Line tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Mesin</label>
			<select name="machine" class="form-control" onchange="this.form.submit();">
					<option selected="" value="<?=  $getmachine ?>"><?=  $getmachine ?></option>
					<?php 
					$viewww = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 where line1 = '$data1' group by mesin");
            			while ($drowa = pg_fetch_array($viewww)) { ?>
            			<option value="<?=  $machine ?>"><?php echo $drowa['mesin'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Mesin tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>No. Mesin</label>
				<select name="no_machine"  class="form-control" >
					<option selected="" value="<?=  $getnomachine ?>"><?=  $getnomachine ?></option>
					<?php 
						$viewwww = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 where mesin = '$data4' group by op");
            			while ($data55 = pg_fetch_array($viewwww)) {
            			$op = $data55['op']; ?>
            			<option value="<?=  $op ?>"><?php echo $data55['op'] ?></option>

        			<?php }  ?>
				</select>
			<div class="invalid-feedback">No. Mesin tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Tanggal</label>
			<input type="date" class="form-control" name="tgl_key" value="<?=$tgl_key?>" >
		</div>
		<div class="form-group col-md-12">
			<label>Shift</label>
					<select class="form-control" name="shift">
					<option value="<?=$shift?>"><?=$shift?></option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
			<div class="invalid-feedback">Shift tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 1</label>
			<select class="form-control" name="cat_1" autocomplete="off" >
				<option value="<?=$cat_1?>"><?=$cat_1?></option>
				<option value="Suddenly Trouble">1. Suddenly Trouble</option>
				<option value="Postpone Repair">2. Postpone Repair</option>
				<option value="Preventive MTC">3. Preventive MTC</option>
				<option value="MTC Prediction">4. MTC Prediction</option>
				<option value="Corective MTC">5. Corective MTC</option>
				<option value="Inspection MTC">6. Inspection MTC</option>
				<option value="Improvement">7. Improvement</option>
				<option value="Lay Out">8. Lay Out</option>
				<option value="Other">Other</option>
			</select>
		       <div class="invalid-feedback">Categori 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 2</label>
			<select class="form-control" name="cat_2" autocomplete="off" required>
				<option value="<?=$cat_2?>"><?=$cat_2?></option>
				<option value="(E) Electric">(E) Electric</option>
				<option value="(M) Mechanic">(M) Mechanic</option>
				<option value="(H) Hydroulic">(H) Hydroulic</option>
				<option value="(P) Pneumatic">(P) Pneumatic</option>
				<option value="Other">Other</option>
			</select>
	    <div class="invalid-feedback">Categori 2 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Item Trouble / Problem Masalah</label>
	      	<input type="text"  class="form-control" name="bagian_machine" value="<?= $bagian_machine?>">
	       <div class="invalid-feedback">Item  Trouble / Problem Masalah tidak boleh kosong.</div>
		</div>
	</div>
	
        	<!-- <button class="btn btn-primary" onclick="stepper.next()">Next</button> -->
	</div>
	<!-- <div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger"> -->
	 <div class="form-group">
    <div class="col">
				<div class="form-group col-md-12">
					<label>Analisa Penyebab</label>
				<input type="text" class="form-control" class="text" name="analisa" value="<?=$analisa?>" ></textarea>
					<div class="invalid-feedback">Analisa Penyebab tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Tindakan Perbaikan</label>
						<input type="text" class="form-control" class="text" name="kerusakan" value="<?= $kerusakan ?>"></textarea>
					<div class="invalid-feedback">Tindakan Perbaikan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Next Action</label>
					<input type="text" class="form-control" name="action" value="<?=$action?>">
					<div class="invalid-feedback">Next Action tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Stop Line</label>
						<td><input type="number" class="form-control" name="waktu_stop" value="<?= $waktu_stop ?>" >&nbspMenit</td>
				<div class="invalid-feedback">Stop Line tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Persiapan</label>
					<td><input type="number" id="txt1" onkeyup="sum();" class="form-control" name="mttr_persiapan" value="<?= $mttr_persiapan ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Persiapan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
				<label>MTTR Check</label>
			    <td><input type="number" id="txt2" onkeyup="sum();" class="form-control" name="mttr_check" value="<?= $mttr_check ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Check tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Tunggu Part</label>
						<td><input type="number" id="txt3" onkeyup="sum();" class="form-control" name="mttr_tunggu_part" value="<?= $mttr_tunggu_part ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Repair</label>
						<td><input type="number" id="txt4" onkeyup="sum();" class="form-control" name="mttr_repair" value="<?= $mttr_repair ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Repair tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
		     		<label>MTTR Setting</label>
		     		<td><input type="number" id="txt5" onkeyup="sum();" class="form-control" name="mttr_setting" value="<?= $mttr_setting ?>" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Setting tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Perapihan</label>
						<td><input type="number" id="txt6" onkeyup="sum();" class="form-control" name="mttr_perapihan" value="<?= $mttr_perapihan ?>" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Perapihan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
	     			<label>MTTR Total</label>
	           <td><input type="text" id="txt7" class="form-control" value="<?= $mttr_total ?>" readonly>&nbspMenit</td>
	      <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 1</label>
			<select name="pic_1" class="form-control" autocomplete="off" required>
			<option value="<?=  $pic_1 ?>"><?=  $pic_1 ?></option>
			<?php 
			$pic1 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($ddd = pg_fetch_array($pic1)) {
           	$nama = $ddd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $nama ?></option>
        	<?php }  ?>
			
			</select>
			<div class="invalid-feedback">Pic 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 2</label>
			<select name="pic_2" class="form-control">
			<option value="<?=  $pic_2 ?>"><?=  $pic_2 ?></option>
			<?php 
			$pic2 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($dd = pg_fetch_array($pic2)) {
           	$nama = $dd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $dd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 3</label>
			<select name="pic_3" class="form-control">
			<option value="<?=  $pic_3 ?>"><?=  $pic_3 ?></option>
			<?php 
			$pic3 = pg_query($koneksi, "SELECT nama FROM dbmaintenance.data_member where shop = 'ASSY' ");
           	while ($ddd = pg_fetch_array($pic3)) {
           	$nama = $ddd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $ddd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
	</div>
	<div class="form-group col-md-3">
				<label>Foto Sebelum</label>
				<input type="text" name="foto" value="<?=$foto?>" hidden="">
    		<input type="file" class="form-control-file mb-3" id="foto" name="foto" onchange="return validasiFile()" autocomplete="off" value="<?php echo $foto; ?>">
									<div id="imagePreview"><img class="foto-preview" src="foto/<?php echo $foto; ?>"/></div>
				<div class="invalid-feedback">Foto Perbaikan tidak boleh kosong.</div>
			</div>

			<div class="form-group col-md-3">
				<label>Foto Sesudah</label>
				<input type="text" name="foto1" value="<?=$foto1?>" hidden="">
    			<input type="file" class="form-control-file mb-3" id="foto1" name="foto1" onchange="return validasiFile()" autocomplete="off" value="<?php echo $foto1; ?>">
									<div id="imagePreview"><img class="foto-preview" name="foto1" src="foto/<?php echo $foto1; ?>"/></div>
				<div class="invalid-feedback">Foto Sesudah tidak boleh kosong.</div>`
			</div>
			<button class="btn btn-primary" onclick="stepper.previous()">Previous</button>
  <input type="submit" class="btn btn-primary btn-submit" name="kirim" value="Kirim"> 
  </div>
  
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </section>
  </div>
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
	<?php
	include '../koneksi.php';
	$waktu_default = 21600; //21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
    $tanggal_sekarang = date('H-i-s', time() + $waktu_default);
	$tgl = date('d', time() + $waktu_default);

	 if (isset($_POST['kirim'])) {
		// $inida = $_POST['id'];
		$shift = $_POST['shift'];
		$waktu_stop = $_POST['waktu_stop'];
		$bagian_machine = $_POST['bagian_machine'];
		$kerusakan = $_POST['kerusakan'];
		$analisa = $_POST['analisa'];
		$action = $_POST['action'];
		$tgl_key = $_POST['tgl_key'];
		$pic_1 = $_POST['pic_1'];
		$pic_2 = $_POST['pic_2'];
		$pic_3 = $_POST['pic_3'];
		$cat_1 = $_POST['cat_1'];
		$cat_2 = $_POST['cat_2'];
		$foto = $_POST['foto'];
		$poto = "foto/".$foto;
		$foto1 = $_POST['foto1'];
		$mttr_persiapan = $_POST['mttr_persiapan'];
		$mttr_check = $_POST['mttr_check'];
		$mttr_tunggu_part = $_POST['mttr_tunggu_part'];
		$mttr_repair = $_POST['mttr_repair'];
		$mttr_setting = $_POST['mttr_setting'];
		$mttr_perapihan = $_POST['mttr_perapihan'];
		$nama_file = $_FILES['foto']['name'];
		$tmp_file = $_FILES['foto']['tmp_name'];
		$nama_file1 = $_FILES['foto1']['name'];
		$tmp_file1 = $_FILES['foto1']['tmp_name'];
		$path = "foto/";
		$path1 = "foto/";
		// $aplot = $tmp_file.$path;
		// $aplot1 = $tmp_file1.$path;
    
	 move_uploaded_file($tmp_file, $path.$nama_file);
	move_uploaded_file($tmp_file1, $path.$nama_file1);

	if ($shift == '1') {
		$stopget1 = $waktu_stop;
		$stopget2 = '0';
		$stopget3 = '0';
	} elseif ($shift == '2') {
		$stopget1 = '0';
		$stopget2 = $waktu_stop;
		$stopget3 = '0';
	} elseif ($shift == '3') {
		$stopget1 = '0';
		$stopget2 = '0';
		$stopget3 = $waktu_stop;
	}

	if ($nama_file == NULL) {
		$nama_file = $foto;
	}
	if ($nama_file1 == NULL) {
		$nama_file1 = $foto1;
	}
	// $update = pg_query($koneksi, "UPDATE dbmaintenance.tbdaily_stopassy SET time_1= '$stopget1',time_2 = '$stopget2',time_3 = '$stopget3' ,pic_1='$pic_1'WHERE id = '$id' ");

			$update = pg_query($koneksi, "UPDATE dbmaintenance.tbdaily_stopassy SET time_1= '$stopget1',time_2 = '$stopget2',time_3 = '$stopget3', shift='$shift', bagian_machine = '$bagian_machine', kerusakan = '$kerusakan', analisa = '$analisa', action='$action', pic_1='$pic_1', pic_2='$pic_2', pic_3='$pic_3',tgl_key='$tgl_key', cat_1='$cat_1', cat_2='$cat_2', mttr_persiapan = '$mttr_persiapan', mttr_check = '$mttr_check', mttr_tunggu_part = '$mttr_tunggu_part', mttr_repair = '$mttr_repair', mttr_setting = '$mttr_setting', mttr_perapihan = '$mttr_perapihan' WHERE id = '$id' ");
			if ($update) {
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
				}
			
				}
    ?>
<script src="../../plugins/bs-stepper/js/bs-stepper.min.js"></script>
<script>
  // BS-Stepper Init
  document.addEventListener('DOMContentLoaded', function () {
    window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  })
  // DropzoneJS Demo Code End
  function sum(){
	var txtFirstNumberValue = document.getElementById('txt1').value;
	var txtSecondNumberValue = document.getElementById('txt2').value;
	var txtThirdNumberValue = document.getElementById('txt3').value;
	var txtFourthNumberValue = document.getElementById('txt4').value;
	var txtFifthNumberValue = document.getElementById('txt5').value;
	var txtSixthNumberValue = document.getElementById('txt6').value;
	var result = parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue) + parseInt(txtThirdNumberValue) + parseInt(txtFourthNumberValue) + parseInt(txtFifthNumberValue) + parseInt(txtSixthNumberValue);
if (!isNaN(result)){
		document.getElementById('txt7').value = result;
	}
}
</script>
</body>
</html>