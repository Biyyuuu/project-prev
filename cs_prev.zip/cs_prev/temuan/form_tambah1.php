<?php
error_reporting(0);
$waktu_default = 21600;//21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
$tanggal_sekarang = date('Y-m-d' ,time() + $waktu_default);
$bulan_sekarang = gmdate('m', $waktu_indonesia);
include '../../koneksi.php';
include 'config-input-stop.php';
$data1 = $_POST['line'];
$data2 = $_POST['no_machine'];
$data3 = $_POST['shop'];
$data4 = $_POST['machine'];
$no = pg_query($koneksi, "SELECT * FROM dbmaintenance.tbdaily_stopassy");
while ($d = pg_fetch_array($no)) {
	$no1 = $d['id'];
}


$ambil = substr($contoh, 8,2);
echo $ambil;

$number = $no1 + 1;
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../../plugins/bs-stepper/css/bs-stepper.min.css">
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- /.card -->
        <!-- /.row -->

        <div class="row" style="align-middle">
          <div class="col-md-12" style="align-self: center;">
            <div class="card card-default">
              
                <div class="bs-stepper" >
                  <div class="bs-stepper-header" role="tablist">
                    <!-- your steps here -->
                    <div class="step" data-target="#logins-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="logins-part">
                        <span class="bs-stepper-circle">1</span>
                        <span class="bs-stepper-label">Step 1</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="information-part">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">Step 2</span>
                      </button>
                    </div>
                  </div>
                    <!-- your steps content here -->
                    <div id="logins-part" class="content" role="tabpanel" aria-labelledby="logins-part-trigger">
			    	<form  method="post"  enctype="multipart/form-data" >
					  		<div class="col">
			<div class="form-group col-md-12" hidden="">
			<label>No</label>
			<input type="number" name="no" class="form-control" value="<?= $number ?>" readonly="readonly">
		</div>
		<div class="form-group col-md-12">
			<label>Shop</label>
			<td>
				<select name="shop" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data3 ?>"><?=  $data3 ?></option>
					<?php 
					$sql2 = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 group by shop");
            			while ($data = pg_fetch_array($sql2)) {
            			$shop = $data['shop']; ?>
            			<option value="<?=  $shop ?>"><?php echo $data['shop'] ?></option>

        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Shop tidak boleh kosong.</div>
								</div>
		<div class="form-group col-md-12">
			<label>Line</label>
				<select name="line" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data1 ?>"><?=  $data1 ?></option>
					<?php 
					$sql1 = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 where shop = '$data3' group by line1");
            			while ($data = pg_fetch_array($sql1)) {
            			$line1 = $data['line1']; ?>
            			<option value="<?=  $line1 ?>"><?php echo $data['line1'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Line tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Mesin</label>
				<select name="machine" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data4 ?>"><?=  $data4 ?></option>
					<?php 
					$viewww = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 where line1 = '$data1' group by mesin");
            			while ($drowa = pg_fetch_array($viewww)) {
            			$machine = $drowa['mesin']; ?>
            			<option value="<?=  $machine ?>"><?php echo $drowa['mesin'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">Mesin tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>No. Mesin</label>
				<select name="no_machine" class="form-control" onchange="this.form.submit();" autocomplete="off" required>
					<option value="<?=  $data2 ?>"><?=  $data2 ?></option>
					<?php 
						$viewwww = pg_query($koneksi, "SELECT * FROM dbmaintenance.no_mesin2 where mesin = '$data4' group by op");
            			while ($data55 = pg_fetch_array($viewwww)) {
            			$op = $data55['op']; ?>
            			<option value="<?=  $op ?>"><?php echo $data55['op'] ?></option>
        			<?php }  ?>
				</select>
			<div class="invalid-feedback">No. Mesin tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Tanggal</label>
			<td><input type="date" class="form-control" name="tanggal" value="" required=""></td>
		</div>
		<div class="form-group col-md-12">
			<label>Shift</label>
				<select class="form-control" name="shift">
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
				</select>
			<div class="invalid-feedback">Shift tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 1</label>
			<select class="form-control" name="cat_1" autocomplete="off" >
				<option value=""></option>
				<option value="Suddenly Trouble">1. Suddenly Trouble</option>
				<option value="Postpone Repair">2. Postpone Repair</option>
				<option value="Preventive MTC">3. Preventive MTC</option>
				<option value="MTC Prediction">4. MTC Prediction</option>
				<option value="Corective MTC">5. Corective MTC</option>
				<option value="Inspection MTC">6. Inspection MTC</option>
				<option value="Improvement">7. Improvement</option>
				<option value="Lay Out">8. Lay Out</option>
				<option value="Other">Other</option>
			</select>
		       <div class="invalid-feedback">Categori 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Categori 2</label>
			<select class="form-control" name="cat_2" autocomplete="off" >
				<option value=""></option>
				<option value="(E) Electric">(E) Electric</option>
				<option value="(M) Mechanic">(M) Mechanic</option>
				<option value="(H) Hydroulic">(H) Hydroulic</option>
				<option value="(P) Pneumatic">(P) Pneumatic</option>
				<option value="Other">Other</option>
			</select>
	    <div class="invalid-feedback">Categori 2 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Item Trouble / Problem Masalah</label>
	       <input type="text" name="bagian_machine" class="form-control"  autocomplete="off"  required>
	       <div class="invalid-feedback">Item  Trouble / Problem Masalah tidak boleh kosong.</div>
		</div>
	</div>
	
        	<button class="btn btn-primary" onclick="stepper.next()">Next</button>
	</div>
	<div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
	 <div class="form-group">
    <div class="col">
				<div class="form-group col-md-12">
					<label>Analisa Penyebab</label>
					<textarea class="form-control" rows="2" name="analisa" autocomplete="off" required></textarea>
					<div class="invalid-feedback">Analisa Penyebab tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Tindakan Perbaikan</label>
					<textarea class="form-control" rows="2" name="kerusakan" autocomplete="off" ></textarea>
					<div class="invalid-feedback">Tindakan Perbaikan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Next Action</label>
					<textarea class="form-control" rows="2" name="action" autocomplete="off" required></textarea>
					<div class="invalid-feedback">Next Action tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
					<label>Stop Line</label>
					<input type="number" class="form-control" name="waktu_stop"  autocomplete="off"  required>
				<div class="invalid-feedback">Stop Line tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Persiapan</label>
						<td><input type="number" id="txt1" onkeyup="sum();" class="form-control" name="mttr_persiapan" value="<?= $mttr_persiapan ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Persiapan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
				<label>MTTR Check</label>
			    <td><input type="number" id="txt2" onkeyup="sum();" class="form-control" name="mttr_check" value="<?= $mttr_check ?>" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Check tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Tunggu Part</label>
		        <td><input type="number" id="txt3" onkeyup="sum();" class="form-control" name="mttr_tunggu_part" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Repair</label>
		        <td><input type="number" id="txt4" onkeyup="sum();" class="form-control" name="mttr_repair" >&nbspMenit</td>
		        <div class="invalid-feedback">MTTR Repair tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
		     		<label>MTTR Setting</label>
		        <td><input type="number" id="txt5" onkeyup="sum();" class="form-control" name="mttr_setting" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Setting tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
						<label>MTTR Perapihan</label>
		        <td><input type="number" id="txt6" onkeyup="sum();" class="form-control" name="mttr_perapihan" >&nbspMenit</td>
	            <div class="invalid-feedback">MTTR Perapihan tidak boleh kosong.</div>
				</div>
				<div class="form-group col-md-12">
	     			<label>MTTR Total</label>
	           <td><input type="text" id="txt7" class="form-control" readonly>&nbspMenit</td>
	      <div class="invalid-feedback">MTTR Tunggu Part tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 1</label>
			<select name="pic_1" class="form-control" autocomplete="off" required>
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic1 = pg_query($koneksi, "SELECT * FROM daftar_member where shop = 'Assy' ");
           	while ($d = pg_fetch_array($pic1)) {
           	$nama = $d['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $d['nama'] ?></option>
        	<?php }  ?>
			</select>
			<div class="invalid-feedback">Pic 1 tidak boleh kosong.</div>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 2</label>
			<select name="pic_2" class="form-control">
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic2 = pg_query($koneksi, "SELECT * FROM daftar_member where shop = 'Assy' ");
           	while ($dd = pg_fetch_array($pic2)) {
           	$nama = $dd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $dd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
		<div class="form-group col-md-12">
			<label>Pic 3</label>
			<select name="pic_3" class="form-control">
			<option value="<?=  $data5 ?>"><?=  $data5 ?></option>
			<?php 
			$pic3 = pg_query($koneksi, "SELECT * FROM daftar_member where shop = 'Assy' ");
           	while ($ddd = pg_fetch_array($pic3)) {
           	$nama = $ddd['nama']; ?>
           	<option value="<?=  $nama ?>"><?php echo $ddd['nama'] ?></option>
        	<?php }  ?>
			</select>
		</div>
	</div>
	<div class="form-group col-md-3">
				<label>Foto Sebelum</label>
    			<input type="file" class="form-control-file mb-3" id="foto" name="foto" onchange="return validasiFile()" autocomplete="off" >
				<div id="imagePreview"><img class="foto-preview" src="foto/default_user.png"/></div>
				<div class="invalid-feedback">Foto Perbaikan tidak boleh kosong.</div>
			</div> 
			<div class="form-group col-md-3">
				<label>Foto Sesudah</label>
    			<input type="file" class="form-control-file mb-3" id="foto1" name="foto1" onchange="return validasiFile()" autocomplete="off" >
				<div id="imagePreview"><img class="foto-preview" src="foto/default_user.png"/></div>
				<div class="invalid-feedback">Foto Sesudah tidak boleh kosong.</div>`
			</div>
  </div>
  <button class="btn btn-primary" onclick="stepper.previous()">Previous</button>
  <input type="submit" class="btn btn-primary btn-submit" name="kirim" value="Kirim"> 
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </section>
  </div>
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<?php
require_once "config/config.php";
$waktu_default = 21600;//21600 adalah nilai untuk menambah jam default agar sesuai jam indonesia (dalam satuan detik)
$tanggal_sekarang = date('H-i-s' ,time() + $waktu_default);
$tgl = date('d' ,time() + $waktu_default);

$index_list = [
				'no','tanggal','shop','line','machine','no_machine','shift',
				'waktu_stop','bagian_machine','kerusakan','analisa','action',
				'pic_1','pic_2','pic_3','cat_1','cat_2','wkt_kerja','foto',
				'tgl_temu','shift_temu','foto1','mttr_persiapan','mttr_check',
				'mttr_tunggu_part','mttr_repair','mttr_setting','mttr_perapihan'
			];

if (isset($_POST['kirim'])) {
$tanggal_isi 			= $mysqli->real_escape_string(trim($_POST['tanggal']));
$isi 							= substr($tanggal_isi, 8,2);
$shop 						= $mysqli->real_escape_string(trim($_POST['shop']));
$line 						= $mysqli->real_escape_string(trim($_POST['line']));
$machine 					= $mysqli->real_escape_string(trim($_POST['machine']));
$no_machine 			= $mysqli->real_escape_string(trim($_POST['no_machine']));
$shift 						= $mysqli->real_escape_string(trim($_POST['shift']));
$bagian_machine 	= $mysqli->real_escape_string(trim($_POST['bagian_machine']));
$kerusakan 				= $mysqli->real_escape_string(trim($_POST['kerusakan']));
$analisa 					= $mysqli->real_escape_string(trim($_POST['analisa']));
$action 					= $mysqli->real_escape_string(trim($_POST['action']));
$pic_1 						= $mysqli->real_escape_string(trim($_POST['pic_1']));
$pic_2 						= $mysqli->real_escape_string(trim($_POST['pic_2']));
$pic_3 						= $mysqli->real_escape_string(trim($_POST['pic_3']));
$number1 					= $mysqli->real_escape_string(trim($_POST['no']));
$id 							= $mysqli->real_escape_string(trim($_POST['id']));
$cat_1 						= $mysqli->real_escape_string(trim($_POST['cat_1']));
$cat_2 						= $mysqli->real_escape_string(trim($_POST['cat_2']));
$wkt_kerja 				= $mysqli->real_escape_string(trim($_POST['wkt_kerja']));
$mttr_persiapan 	= $mysqli->real_escape_string(trim($_POST['mttr_persiapan']));
$mttr_check 	  	= $mysqli->real_escape_string(trim($_POST['mttr_check']));
$mttr_tunggu_part = $mysqli->real_escape_string(trim($_POST['mttr_tunggu_part']));
$mttr_repair 	  	= $mysqli->real_escape_string(trim($_POST['mttr_repair']));
$mttr_setting 	  = $mysqli->real_escape_string(trim($_POST['mttr_setting']));
$mttr_perapihan   = $mysqli->real_escape_string(trim($_POST['mttr_perapihan']));
$nama_file      	= $_FILES['foto']['name'];    
$tmp_file      		= $_FILES['foto']['tmp_name']; 
$nama_file1      	= $_FILES['foto1']['name'];    
$tmp_file1     		= $_FILES['foto1']['tmp_name']; 
// Set path folder tempat menyimpan filenya   
  $path             = "foto/";
  move_uploaded_file($tmp_file, $path.$nama_file);
  move_uploaded_file($tmp_file1, $path.$nama_file1);

for ($i=0; $i < count($index_list); $i++) { 
	$index_form[$i] = $_POST[$index_list[$i]];
	//echo $i.'='. $index_form[$i].'<br>';
}
echo $index_form[6].'--';

$waktu_1 = 0;
$waktu_2 = 0;
$waktu_3 = 0;

	if ($index_form[6] == '1') {
		$waktu_1 = $index_form[7];
	}
	elseif ($index_form[6] == '2') {
		$waktu_2 = $index_form[7];
	}
	elseif ($index_form[6] == '3') { 
		$waktu_3 = $index_form[7];
	}
		$result = $mysqli->query("SELECT id FROM dbmaintenance.tbdaily_stopassy WHERE id='$id'")
                              or die('Ada kesalahan pada query tampil data nik: '.$mysqli->error);
    $rows = $result->num_rows;
    // jika nik sudah ada
        if ($rows > 0) {
        // tampilkan pesan gagal simpan data
				echo '<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">';
    }
    // jika nik belum ada
    else {  
        // upload file
            $insert = $mysqli->query("INSERT INTO `dbmaintenance.tbdaily_stopassy`(`id`, `tanggal`, `time_1`, `time_2`, `time_3`, `no_id`, `shop`, `line1`, `machine`, `no_machine`, `shift`, `bagian_machine`, `kerusakan`, `analisa`, `action`, `pic_1`, `pic_2`, `pic_3`, `no`, `tgl_key`, `cat_1`, `cat_2`, `foto`,`foto1`,`mttr_persiapan`,`mttr_check`,`mttr_tunggu_part`,`mttr_repair`,`mttr_setting`,`mttr_perapihan`) VALUES ('$number',NOW(),'$waktu_1','$waktu_2','$waktu_3','$isi','$shop','$line','$machine','$no_machine','$shift','$bagian_machine','$kerusakan','$analisa','$action','$pic_1','$pic_2','$pic_3','$number1','$tanggal_isi','$cat_1','$cat_2','$nama_file','$nama_file1','$mttr_persiapan','$mttr_check','$mttr_tunggu_part','$mttr_repair','$mttr_setting','$mttr_perapihan')")or die('Ada kesalahan pada query insert : '.$mysqli->error); 
            // cek query
            if ($insert) {
            	$deletin = pg_query($koneksi,"DELETE FROM dbmaintenance.tbdaily_stopassy where shop = '' ");
                // jika berhasil tampilkan pesan berhasil simpan data
							echo '<META HTTP-EQUIV="Refresh" Content="0; URL=">';
        }   
      }
    }
// tutup koneksi
$mysqli->close();
?>
<!-- Tempusdominus Bootstrap 4 -->
<!-- Bootstrap Switch -->
<script src="../../plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<!-- Page specific script -->
<script>
  // BS-Stepper Init
  document.addEventListener('DOMContentLoaded', function () {
    window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  })
  // DropzoneJS Demo Code End
  function sum(){
	var txtFirstNumberValue = document.getElementById('txt1').value;
	var txtSecondNumberValue = document.getElementById('txt2').value;
	var txtThirdNumberValue = document.getElementById('txt3').value;
	var txtFourthNumberValue = document.getElementById('txt4').value;
	var txtFifthNumberValue = document.getElementById('txt5').value;
	var txtSixthNumberValue = document.getElementById('txt6').value;
	var result = parseInt(txtFirstNumberValue) + parseInt(txtSecondNumberValue) + parseInt(txtThirdNumberValue) + parseInt(txtFourthNumberValue) + parseInt(txtFifthNumberValue) + parseInt(txtSixthNumberValue);
	if (!isNaN(result)){
		document.getElementById('txt7').value = result;
	}
}
</script>
 <script type="text/javascript">
        $(document).ready(function() {
            // datepicker plugin
            $('.date-picker').datepicker({
                autoclose: true,
                todayHighlight: true
            });
        } );

        // Validasi Form
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // validasi image dan preview image sebelum upload
        function validasiFile() {
            var fileInput         = document.getElementById('foto');
            var filePath          = fileInput.value;
            var fileSize          = $('#foto')[0].files[0].size;
            // tentukan extension yang diperbolehkan
            var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
            // Jika tipe file yang diupload tidak sesuai dengan allowedExtensions, tampilkan pesan :
            if (!allowedExtensions.exec(filePath)) {
                alert('Tipe file foto tidak sesuai. Harap unggah file foto yang memiliki tipe *.jpg atau *.png');
                fileInput.value = '';
                document.getElementById('imagePreview').innerHTML = '<img class="foto-preview" src="foto/default_user.png"/>';
                return false;
            } 
            // jika ukuran file yang diupload lebih dari sama dengan 1 Mb
            else if (fileSize >= 1000000) {
                alert('Ukuran file foto lebih dari 1 Mb. Harap unggah file foto yang memiliki ukuran maksimal 1 Mb.');
                fileInput.value = '';
                document.getElementById('imagePreview').innerHTML = '<img class="foto-preview" src="foto/default_user.png"/>';
                return false;
            }
            // selain itu
            else {
                // Image preview
                if (fileInput.files && fileInput.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                    document.getElementById('imagePreview').innerHTML = '<img class="foto-preview" src="'+e.target.result+'"/>';
                };
            reader.readAsDataURL(fileInput.files[0]);
            }
        }}
        </script>
</body>
</html>
