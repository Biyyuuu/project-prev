<!DOCTYPE html>
<html>

<head>
	<title>Detail Preventive</title>
	<link rel="stylesheet" href="/iotmtc/plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="/iotmtc/dist/css/adminlte.min.css">
</head>

<body>

	<?php
	include '../koneksi.php';
	$no_check = $_GET['no_check'];

	$sql = pg_query($koneksi, "SELECT * FROM dbmaintenance_assy.aktual_cs WHERE no_check = '$no_check' ");
	while ($data = pg_fetch_array($sql)) {
		$id = $data['id'];
		$unit = $data['unit'];
		$item_check = $data['item_check'];
		$standart = $data['standart'];
		$metode = $data['metode'];
		$periode = $data['periode'];
		$shop = $data['shop'];
		$mesin = $data['mesin'];
		$no_mesin = $data['no_mesin'];
		$line = $data['line'];
		$hasil = $data['hasil'];
		$ket = $data['ket_sblm'];
		$hasil1 = $data['hasil_sdh'];
		$ket1 = $data['ket_sdh'];
		if($hasil1 == ''){
			$hasil_sdh = 'Belum Di Kerjakan';
			$color_hasil = 'red';
		}else{
			$hasil_sdh = $hasil1;
			$color_hasil = 'black';
		}
		if($ket1 == ''){
			$ket_sdh = 'Belum Di Kerjakan';
			$color_ket = 'red';
		}else{
			$ket_sdh = $ket1;
			$color_ket = 'black';
		}
		$tanggal = $data['tanggal'];
	}
	?>

	<div class="row" style="margin-right: -10px;">
		<div class="col-md-12">
			<div class="alert alert-info" role="alert">
				<i class="fas fa-info-circle"></i>Detail Preventive
			</div>
			<div class="card">
				<div class="card-body">
					<div id="wrapper">
						<form class="needs-validation" action="" method="post" enctype="multipart/form-data" novalidate>
							<div class="row">
								<div class="col">
									<div class="form-group col-md-12">
										<label>Tanggal</label>
										<input type="text" class="form-control" name="tgl_key" value="<?= $tanggal ?>" disabled>
										<div class="invalid-feedback">Tanggal tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Shop</label>
										<input type="text" class="form-control" name="tgl_key" value="<?= $shop ?>" disabled>
										<div class="invalid-feedback">Line tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Line</label>
										<input type="text" class="form-control" name="tgl_key" value="<?= $tanggal ?>" disabled>
										<div class="invalid-feedback">Mesin tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Mesin</label>
										<input type="text" class="form-control" name="tgl_key" value="<?= $mesin ?>" disabled>
										<div class="invalid-feedback">No.Mesin tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>No.Mesin</label>
										<input type="text" class="form-control" name="tgl_key" value="<?= $no_mesin ?>" disabled>
										<div class="invalid-feedback">No.Mesin tidak boleh kosong.</div>
									</div>
								</div>
								<div class="col">
									<div class="form-group col-md-12">
										<label>Standart</label>
										<input type="text" class="form-control" name="standart" value="<?= $standart ?>" disabled>
										<div class="invalid-feedback">Standart tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Unit</label>
										<input type="text" class="form-control" name="unit" value="<?= $unit ?>" disabled>
										<div class="invalid-feedback">Unit tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Item Check</label>
										<input type="text" class="form-control" name="item_cek" value="<?= $item_check ?>" disabled>
										<div class="invalid-feedback">Item Check tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Metode</label>
										<input type="text" class="form-control" name="metode" value="<?= $metode ?>" disabled>
										<div class="invalid-feedback">Metode tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Periode</label>
										<td><input type="text" class="form-control" name="periode" value="<?= $periode ?>" disabled></td>
									</div>
								</div>
								<div class="col">

									<div class="form-group col-md-12">
									<?php if($hasil == 'X'){ ?>
										<label>Hasil Sebelum Perbaikan</label>
										<?php }else{ ?>
										<label>Hasil</label>
											<?php } ?>
										<td><input type="text" class="form-control" name="hasil" value="<?= $hasil ?>" disabled></td>
										<div class="invalid-feedback">Hasil tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
									<?php if($hasil == 'X'){ ?>
										<label>Keterangan Sebelum Perbaikan</label>
										<?php }else{ ?>
										<label>Keterangan</label>
											<?php } ?>
										<td><input type="text" class="form-control" name="hasil" value="<?= $ket ?>" disabled></td>
										<div class="invalid-feedback">Hasil tidak boleh kosong.</div>
									</div>
									<?php if($hasil == 'X'){ ?>
									<div class="form-group col-md-12">
										<label>Hasil Setelah Perbaikan</label>
										<td><input type="text" class="form-control" style="color:<?=$color_hasil?>" name="hasil" value="<?= $hasil_sdh ?>" disabled></td>
										<div class="invalid-feedback">Hasil tidak boleh kosong.</div>
									</div>
									<div class="form-group col-md-12">
										<label>Keterangan Setelah Perbaikan</label>
										<td><input type="text" class="form-control" name="hasil" style="color:<?=$color_ket?>" value="<?= $ket_sdh ?>" disabled></td>
										<div class="invalid-feedback">Hasil tidak boleh kosong.</div>
									</div>
									<?php }else{ } ?>

								</div>
							</div>
					</div>
					<div class="form-group col-md-5">
					</div>
					<div class="my-md-4 pt-md-1 border-top">
						<input type="button" value="Back" class="btn btn-info btn-submit" onclick="history.back(-1)">
						</table>
						</form>
					</div>
</body>

</html>