<?php
include '../koneksi.php';

$waktu_indonesia = time() + (60 * 60 * 7);
$tanggal = gmdate('Y-m-d', $waktu_indonesia);
$bulan = gmdate('m', $waktu_indonesia);
$tahun = gmdate('Y-m', $waktu_indonesia);
$tahunan = gmdate('Y', $waktu_indonesia);
////////////////////////////////////////////////////////////////////////////////////////////////////////////
if (isset($_POST['cari'])) {
  $bulancari = $_POST['cari'];
} else {
  $bulancari = $tahun;
}
$blnx[1] = '01';
$blnx[2] = '02';
$blnx[3] = '03';
$blnx[4] = '04';
$blnx[5] = '05';
$blnx[6] = '06';
$blnx[7] = '07';
$blnx[8] = '08';
$blnx[9] = '09';
$blnx[10] = '10';
$blnx[11] = '11';
$blnx[12] = '12';
$blnz = substr($bulancari, 5);
$thnz = substr($bulancari, 0, 4);

$no_check_ambil = $_GET['no_check'];
$cariin_events  = pg_query($koneksi, "SELECT periode,shop,mesin,line,cat FROM dbmaintenance_assy.aktual_cs WHERE no_check2 ='$no_check_ambil'");
$wtfu           = pg_fetch_array($cariin_events);
$shop       = $wtfu['shop'];
$mesin       = $wtfu['mesin'];
$periode       = $wtfu['periode'];
$line       = $wtfu['line'];
$cat       = $wtfu['cat'];
