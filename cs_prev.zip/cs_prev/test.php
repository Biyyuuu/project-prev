<!DOCTYPE html>
<html lang="en">
<head>
  <title>Borcelle Menu</title>
  <style>
    html, body {
      height: 100%;
      width: 100%;
    }

    body {
      margin: 0;
      padding: 0;
      background-color: #000;
    }

    img {
      width: 50%;
      margin: 0 auto;
    }

    .menu {
      width: 100%;
      height: 50%;
      background-color: #fff;
      text-align: center;
    }

    .menu-item {
      margin: 0 10px;
      font-size: 18px;
      font-weight: bold;
    }

    .menu-item.discount {
      font-size: 24px;
      font-weight: normal;
      text-decoration: line-through;
    }

    .menu-item.active {
      background-color: #ccc;
    }
  </style>
</head>
<body>
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Bowl_of_noodles.jpg/1200px-Bowl_of_noodles.jpg" alt="Mangkok Mie">
  <div class="menu">
    <div class="menu-item active">
      Mie Telur
    </div>
    <div class="menu-item discount">
      Mie Pedas
    </div>
    <div class="menu-item">
      Mie Ayam
    </div>
    <div class="menu-item">
      Mie Jamur
    </div>
  </div>
</body>
</html>
