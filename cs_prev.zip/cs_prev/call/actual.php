<a href="/iotmtc/mch/cs_prev/cs_call/be/data.php?id='.$id.'">
           <li class="sidebar__list-item"><span class="list-item__time"><?=$i?></span><?='.$mesin.'-'.$no_mesin.' / '.$periode.'?></li>
            </a>