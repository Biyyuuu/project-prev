<?php
$dbhost = 'localhost';
$dbname = 'dbmaintenance';
$dbuser = 'postgres';
$dbpass = '12345';
$dbport = '5432'; // nomor port default PostgreSQL
$koneksi = pg_connect("host={$dbhost} port={$dbport} dbname={$dbname} user={$dbuser} password={$dbpass}");
// if(!$koneksi){
//     echo '0';
// }else{
//     echo '1';
// }
try {
   $db = new PDO("pgsql:host=$dbhost;port=$dbport;dbname=$dbname", $dbuser, $dbpass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
