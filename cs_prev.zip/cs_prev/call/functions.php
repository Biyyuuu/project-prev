
<style type="text/css">
  .table-responsive{
  height:200px; width:100%;
  overflow-y: auto;
  border:2px solid #444;
}.table-responsive:hover{
	border-color:orange;
}

.table-responsive1{
  height:200px; width:100%;
  overflow-y: auto;
  border:2px solid #444;
}.table-responsive1:hover{
	border-color:green;
}
table{width:100%;}
td{padding:24px; background:#eee;}
</style>

<script src="jquery.min.js"></script>

<?php
include_once 'dbConfig.php';

if(isset($_POST['func']) && !empty($_POST['func'])){
	switch($_POST['func']){
		case 'getCalender':
			getCalender($_POST['year'],$_POST['month']);
			break;
		case 'getEvents_weld':
			getEvents_weld($_POST['date']);
			break;
		default:
			break;
	}
}

function getCalender($year = '', $month = ''){
	$dateYear = ($year != '')?$year:date("Y");
	$dateMonth = ($month != '')?$month:date("m");
	$date = $dateYear.'-'.$dateMonth.'-01';


	$currentMonthFirstDay = date("N",strtotime($date));
	$totalDaysOfMonth = cal_days_in_month(CAL_GREGORIAN,$dateMonth,$dateYear);
	$totalDaysOfMonthDisplay = ($currentMonthFirstDay == 1)?($totalDaysOfMonth):($totalDaysOfMonth + ($currentMonthFirstDay - 1));
	$boxDisplay = ($totalDaysOfMonthDisplay <= 35)?35:42;
	
	$prevMonth = date("m", strtotime('-1 month', strtotime($date)));
	$prevYear = date("Y", strtotime('-1 month', strtotime($date)));
	$totalDaysOfMonth_Prev = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
?>
	<main class="calendar-contain">
		<section class="title-bar">
			<a href="javascript:void(0);" class="title-bar__prev" onclick="getCalendar('calendar_div','<?php echo date("Y",strtotime($date.' - 1 Month')); ?>','<?php echo date("m",strtotime($date.' - 1 Month')); ?>');"></a>
			<div class="title-bar__month">
				<select class="month-dropdown">
					<?php echo getMonthList($dateMonth); ?>
				</select>
			</div>
			<div class="title-bar__year">
				<select class="year-dropdown">
					<?php echo getYearList($dateYear); ?>
				</select>
			</div>
				<a href="javascript:void(0);" class="title-bar__next" onclick="getCalendar('calendar_div','<?php echo date("Y",strtotime($date.' + 1 Month')); ?>','<?php echo date("m",strtotime($date.' + 1 Month')); ?>');"></a>
			</section>

			<aside class="calendar__sidebar" id="event_list">
				<?php echo getEvents_weld(); ?>
			</aside>

			<section class="calendar__days">
				<section class="calendar__top-bar">
					<span class="top-bar__days">Mon</span>
					<span class="top-bar__days">Tue</span>
					<span class="top-bar__days">Wed</span>
					<span class="top-bar__days">Thu</span>
					<span class="top-bar__days">Fri</span>
					<span class="top-bar__days">Sat</span>
					<span class="top-bar__days">Sun</span>
				</section>

			<?php
				$dayCount = 1;
				$planing = 0;
				$actual = 0;

				echo '<section class="calendar__week">';
				for($cb=1;$cb<=$boxDisplay;$cb++){
					if(($cb >= $currentMonthFirstDay || $currentMonthFirstDay == 1) && $cb <= ($totalDaysOfMonthDisplay)){

						$currentDate = $dateYear.'-'.$dateMonth.'-'.$dayCount;

						global $db;
						include 'koneksi.php';
						$jml_plan = pg_query($koneksi,"SELECT count(id) as jmlh_plan FROM dbmaintenance_assy.tb_planing where tgl_plan = '".$currentDate."' ");
 							while ($row = pg_fetch_array($jml_plan)) {
 							 $jmlh_plan = $row['jmlh_plan'];
 							}
 						$jml_aktual = pg_query($koneksi,"SELECT SUM(jml_item) as jmlh_aktual FROM dbmaintenance_assy.tb_aktualprev where tgl_plan = '".$currentDate."'");
 							while ($row = pg_fetch_array($jml_aktual)) {
 							 $jmlh_aktual1 = $row['jmlh_aktual'];
 							}
 							if ($jmlh_aktual1 == NULL) {
 								$jmlh_aktual = '0';
 							}elseif($jmlh_aktual1 !== NULL) {
 								$jmlh_aktual = $jmlh_aktual1;
 							}
 							// if ($jmlh_plan1 == NULL) {
 							// 	$jmlh_plan = '0';
 							// 	}elseif($jmlh_plan1 !== NULL) {
 							// 	$jmlh_plan = $jmlh_plan1;
 							// }			
							
						// $result = $db->query("SELECT title FROM events_weld WHERE date = '".$currentDate."'");
						// $planing = $result->num_rows;
						// $result2 = $db->query("SELECT title FROM events_weld WHERE date = '".$currentDate."' AND status = 2");
						// $actual = $result2->num_rows;

						if(strtotime($currentDate) == strtotime(date("Y-m-d"))){
							echo '
								<div class="calendar__day today" onclick="getEvents_weld(\''.$currentDate.'\');">
									<span class="calendar__date">'.$dayCount.'</span>
									<span class="event2__task">'.$jmlh_aktual.' /&nbsp <a class="event1__task"> '.$jmlh_plan.'</a></span>
									<span class="calendar__task calendar__task--today">Now</span>
								</div>
							';
						}elseif($jmlh_aktual > 0){
							echo '
								<div class="calendar__day event" onclick="getEvents_weld(\''.$currentDate.'\');">
									<span class="calendar__date">'.$dayCount.'</span>
									<span class="calendar__task">'.$jmlh_aktual.' /&nbsp <a class="event1__task"> '.$jmlh_plan.'</a></span>
									<span class="event1__task"></span>
								</div>
							';
						}elseif($jmlh_plan > 0){
							echo '
								<div class="calendar__day event" onclick="getEvents_weld(\''.$currentDate.'\');">
									<span class="event1">'.$dayCount.'</span>
									<span class="calendar__task">'.$jmlh_aktual.' /&nbsp <a class="event1__task"> '.$jmlh_plan.'</a></span>
									<span class="event1__task"></span>
								</div>
							';
						}else{
							echo '
								<div class="calendar__day no-event" onclick="getEvents_weld(\''.$currentDate.'\');">
									<span class="calendar__date">'.$dayCount.'</span>
									<span class="calendar__task">'.$jmlh_plan.'</span>
								</div>
							';
						}
						$dayCount++;
					}else{
						if($cb < $currentMonthFirstDay){
							$inactiveCalendarDay = ((($totalDaysOfMonth_Prev-$currentMonthFirstDay)+1)+$cb);
							$inactiveLabel = '';
						}else{
							$inactiveCalendarDay = ($cb-$totalDaysOfMonthDisplay);
							$inactiveLabel = '';
						}
						echo '
							<div class="calendar__day inactive">
								<span class="calendar__date">'.$inactiveCalendarDay.'</span>
								<span class="calendar__task">'.$inactiveLabel.'</span>
							</div>
						';
					}
					echo ($cb%7 == 0 && $cb != $boxDisplay)?'</section><section class="calendar__week">':'';
				}
				echo '</section>';
			?>
		</section>
	</main>

	<script>
		function getCalendar(target_div, year, month){
			$.ajax({
				type:'POST',
				url:'functions.php',
				data:'func=getCalender&year='+year+'&month='+month,
				success:function(html){
					$('#'+target_div).html(html);
				}
			});
		}

		function getEvents_weld(date){
			$.ajax({
				type:'POST',
				url:'functions.php',
				data:'func=getEvents_weld&date='+date,
				success:function(html){
					$('#event_list').html(html);
				}
			});
		}

		$(document).ready(function(){
			$('.month-dropdown').on('change',function(){
				getCalendar('calendar_div', $('.year-dropdown').val(), $('.month-dropdown').val());
			});
			$('.year-dropdown').on('change',function(){
				getCalendar('calendar_div', $('.year-dropdown').val(), $('.month-dropdown').val());
			});
		});
	</script>
<?php
}

function getMonthList($selected = ''){
	$options = '';
	for($i=1;$i<=12;$i++)
	{
		$value = ($i < 10)?'0'.$i:$i;
		$selectedOpt = ($value == $selected)?'selected':'';
		$options .= '<option value="'.$value.'" '.$selectedOpt.' >'.date("F", mktime(0, 0, 0, $i+1, 0, 0)).'</option>';
	}
	return $options;
}

function getYearList($selected = ''){
	$yearInit = !empty($selected)?$selected:date("Y");
	$yearPrev = ($yearInit - 10);
	$yearNext = ($yearInit + 10);
	$options = '';
	for($i=$yearPrev;$i<=$yearNext;$i++){
		$selectedOpt = ($i == $selected)?'selected':'';
		$options .= '<option value="'.$i.'" '.$selectedOpt.' >'.$i.'</option>';
	}
	return $options;
}

function getEvents_weld($date = ''){
	$date = $date?$date:date("Y-m-d");

	$eventListPlani = '<h2 class="sidebar__heading">'.date("l", strtotime($date)).'<br>'.date("F d", strtotime($date)).'</h2>';
	$eventListPlan = '';

	global $db;
	$result = $db->query("SELECT shop,bagian,line,mesin,periode,no_check FROM dbmaintenance_assy.tb_planing WHERE tgl_plan = '".$date."'");
	if ($result->rowCount() >= 0) {
			$eventListPlan .= '<ul class="sidebar__list">';
			$eventListPlani .= '<li class="sidebar__list-item sidebar__list-item--complete">Plan</li>'; 
			$i = 1;
			while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
					$shop = $row['shop'];
					$bagian = $row['bagian'];
					$line = $row['line'];
					$periode = $row['periode'];
					$mesin = $row['mesin'];
					$no_check = $row['no_check'];
	
					$eventListPlan .= '
							<a href="/iotmtc/assy/cs_prev/input/input-cs.php?no_check='.$no_check.'">
									<li class="sidebar__list-item"><span class="list-item__time">'.$i.'.</span>'.$bagian.'/'.$shop.'/'.$line.'/'.$mesin.'/'.$periode.'</li>
							</a>';
					
					$i++;
			}
			$eventListPlan .= '</ul>';
	}

	$eventListActual = '';

	global $db;
	 
	$result = $db->query("SELECT DISTINCT shop, line, mesin, periode, no_mesin,no_check FROM dbmaintenance_assy.tb_aktualprev where tgl_plan = '".$date."' AND hasil != ''");

$m = 1;
if ($result->rowCount() >= 0) {
    $eventListActual .= '<ul class="sidebar__list">';
    $eventListActuali = '<li class="sidebar__list-item sidebar__list-item--complete">Actual</li>';

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $shop_act = $row['shop'];
        $line_act = $row['line'];
				$mesin_act = $row['mesin'];
        $periode_act = $row['periode'];
        $no_mesin_act = $row['no_mesin'];
        $no_check_act = $row['no_check'];

        $eventListActual .= '
            <a href="/iotmtc/assy/cs_prev/check-sheet.php?no_check='.$no_check_act.'">
                <li class="sidebar__list-item"><span class="list-item__time">'.$m++.'.</span>'.$line_act.'/'.$mesin_act.'/'.$no_mesin_act.' / '.$periode_act.'</li>
            </a>
        ';
    }

    $eventListActual .= '</ul>';
}

	?>
<?php echo $eventListPlani; ?>
<div class="table-responsive1">
  <table class="table table-bordered table-hover">
    <tbody>  
      <tr>	
       	<td>
			<?php echo $eventListPlan; ?>
		</td>
      </tr> 
    </tbody>
  </table>
</div>

<?php echo $eventListActuali;?>

<div class="table-responsive">
  <table class="table table-bordered table-hover">
    <tbody>  
      <tr>	
       	<td>
			<?php echo $eventListActual;?>
		</td>
      </tr> 
    </tbody>
  </table>
</div>
<?php
}
?>