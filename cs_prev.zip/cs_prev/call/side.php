		$eventListActual .= '<ul class="sidebar__list">';
		$eventListActual .= '<li class="sidebar__list-item sidebar__list-item--complete">Actual</li>'; 
		$i=0;
		while($row = $result->fetch_assoc()){ $i++;
			$no_mesin = $row['no_mesin'];
			$mesin = $row['mesin'];
			$id = $row['id'];
			$periode = $row['periode'];