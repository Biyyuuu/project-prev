<?php
include '../koneksi.php';
include 'pengaturan-be.php';
switch ($blnz) {
  case '01':
    $bln_se = 'Januari';
    break;
  case '02':
    $bln_se = 'Februari';
    break;
  case '03':
    $bln_se = 'Maret';
    break;
  case '04':
    $bln_se = 'April';
    break;
  case '05':
    $bln_se = 'Mei';
    break;
  case '06':
    $bln_se = 'Juni';
    break;
  case '07':
    $bln_se = 'Juli';
    break;
  case '08':
    $bln_se = 'Agustus';
    break;
  case '09':
    $bln_se = 'September';
    break;
  case '10':
    $bln_se = 'Oktober';
    break;
  case '11':
    $bln_se = 'November';
    break;
  case '12':
    $bln_se = 'Desember';
    break;
}
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Kontrol Preventive</title>
  <link rel="stylesheet" href="fix/bulma-with-sticky-table.css">
</head>
<style type="text/css">
  .tableFixHead {
    overflow-y: auto;
    height: 70%;
  }

  .col-id-no {
    left: 80px;
    position: sticky;
  }

  .col-first-name {
    left: 0;
    position: sticky;
  }

  .col-plan-cok {
    left: 80px;
    position: sticky;
  }

  .fixed-header {
    z-index: 99999999;
  }

  table {
    border-collapse: separate;
    width: 5%;

  }

  td {
    padding: 0;
    outline: 1px solid #ccc;
    border: none;
    outline-offset: -1px;
    padding-left: 5px;
  }

  th {
    background: #ffffff;
    padding: 0;
    outline: 1px solid #ccc;
    border: none;
    outline-offset: -1px;
    padding-left: 5px;
  }

  .footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 1000px;
    /* tinggi dari footer */
    background: #6cf;
  }
</style>

<body>
  <div class="wrapper theme-1-active pimary-color-blue">
    <div class="row">
      <div class="col-sm-12">
        <div class="panel panel-default card-view">
          <div class="panel-heading">
            <div class="panel-wrapper collapse in">
              <div class="panel-body">
                <div class="table-wrap">
                  <h1 style="text-align:center; font-size: x-large;">RENCANA AKTIVITAS HARIAN SHOP MAINTENANCE ASSY</h1>
                  <h3 style="text-align:center;  font-size: x-large;"><?= $shop_assy ?> Line <?= $line_assy ?></h3>
                  <h5 style="text-align:center;  font-size: x-large;">(2023)</h5><br />
                  <div id="cari">
                    <form method="post">
                      <input type="month" name="cari">
                      <input type="submit" name="" value="Cari">
                    </form>
                  </div>
                  <div class="table-wrap mt-1" style="margin-top:100px;">
                    <div class="table-responsive">
                      <div class="tableFixHead">
                        <table style="position: absolute;top: 15%;right: 1%;border: 1px solid #000; font-weight:bold; ">
                          <td style="text-align:center; color: white; background-color:blue;">1 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:LawnGreen;">3 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:orange; ">6 Bulanan</td>
                          <td style="text-align:center; color: black; background-color:cyan;">1 Tahunan</td>
                        </table>
                        <table class="table is-striped is-bordered is-narrow is-hoverable is-fullwidth has-sticky-header has-sticky-footer" id="demo-table">
                          <thead>
                            <tr>
                              <th rowspan="2" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">No</th>
                              <th rowspan="2" style="text-align: center; width:1px; height:1px; background-color:green; color:white;">Line</th>
                              <th rowspan="2" class="col-first-name fixed-header" style="text-align: center; width:5px; height:1px;background-color:green; color:white;">Item Pekerjaan</th>
                              <th rowspan="2" style="text-align: center; width:1px; height:1px; background-color:green; color:white;">Jml Mesin</th>
                              <th rowspan="2" style="text-align: center; width:1px; height:1px; background-color:green; color:white;">Jml Item</th>
                              <th rowspan="1" style="text-align: center; width:10px;">Plan </th>
                              <th colspan="31" style="text-align: center; width:10px; font-size:20px; font:bold;"> <?= $bln_se ?> <?= $thnz ?> </th>
                              <th rowspan="2" align="center" style="font-weight: bold;vertical-align: middle;" style="text-align: center; width:10px;">Total</th>
                            </tr>
                            <tr>
                              <th colspan="1" style="text-align: center; top:7%">Aktual</th>
                              <?php
                              for ($xi = 1; $xi <= 31; $xi++) {
                              ?>
                                <th rowspan="2" style="text-align: center; top:7%"><?= $xi ?> </th>
                              <?php
                              }
                              ?>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $z = 1;
                            for ($i = 1; $i <= $jml_id; $i++) {
                            ?>
                              <tr>
                                <td rowspan="2" align="center" style="font-weight: bold;font-size:20px;vertical-align: middle;"><?= $z++ ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold;font-size:25px;vertical-align: middle;"><?= $line_assy; ?></td>
                                <td rowspan="2" align="center" style="text-align: left; font-weight: bold;">Preventive <?= $periodeni[$i] ?> <?= $mesin[$i]; ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; font-size:20px; vertical-align: middle;"><?= $jml_mesin[$i]; ?></td>
                                <td rowspan="2" align="center" style="font-weight: bold; font-size:20px; vertical-align: middle;" style="text-align: left;"><?= $jumlah_itemnya[$i]; ?></td>
                                <td align="center" style="font-weight: bold; vertical-align: middle;">Plan</td><!------// PLAN  //------->
                                <?php
                                for ($x = 1; $x <= 31; $x++) {
                                  if ($periode_plan[$x][$i] == '1M') {
                                    $coloring[$x][$i] = 'blue';
                                    $fontnya[$x][$i] = 'white';
                                  } elseif ($periode_plan[$x][$i] == '3M') {
                                    $coloring[$x][$i] = 'LawnGreen';
                                    $fontnya[$x][$i] = 'black';
                                  } elseif ($periode_plan[$x][$i] == '6M') {
                                    $coloring[$x][$i] = 'orange';
                                    $fontnya[$x][$i] = 'black';
                                  } elseif ($periode_plan[$x][$i] == '1Y') {
                                    $coloring[$x][$i] = 'cyan';
                                    $fontnya[$x][$i] = 'black';
                                  }
                                ?>
                                  <td align="center" style="background-color:<?= $coloring[$x][$i] ?>; vertical-align: middle; "><a href="input/input-cs.php?no_check=<?= $no_check_plan[$x][$i] ?>" style="color:<?= $fontnya[$x][$i] ?>; vertical-align: middle; font-weight: bold; " target="_blank"><?= $jml_item_plan[$x][$i] ?></a></td>
                                <?php
                                }
                                ?>
                                <td rowspan="1" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $tot_plan_sat[$i] ?></td>
                              </tr>
                              <tr>
                                <td align="center" style="font-weight: bold; vertical-align: middle;">Aktual</td>
                                <?php
                                for ($x = 1; $x <= 31; $x++) {
                                ?>
                                  <td align="center" style="color:red; font-weight: bold; font-size:20px; vertical-align: middle;"><a style="color:red; font-weight: bold; font-size:20px; vertical-align: middle;" href="check-sheet.php?no_check=<?= $no_check_aktual[$x][$i] ?>"><?= $hasil_aktual[$x][$i] ?></a></td>
                                <?php
                                }
                                ?>
                                <td rowspan="1" align="center" style="font-weight: bold; vertical-align: middle; text-align: center;"><?= $tot_acto[$i] ?></td>
                              </tr>
                            <?php
                            }
                            ?>
                            <tr>
                              <th align="center" colspan="3" rowspan="2" style="font-weight: bold; font-size:50px; position:relative;">TOTAL</th>
                              <th align="center" colspan="1" rowspan="2" style="font-weight: bold; font-size:25px; vertical-align: middle; position:relative;"><?= $tot_mesin_bln ?></th>
                              <th align="center" colspan="1" rowspan="2" style="font-weight: bold; font-size:25px; vertical-align: middle; position:relative;"><?= $tot_item_bln ?></th>
                              <td align="center" style="font-weight: bolder; vertical-align: middle;">Plan</td>
                              <?php
                              for ($x = 1; $x <= 31; $x++) {
                              ?>
                                <td align="center" style="color:green; font-weight: bold; font-size:20px; vertical-align: middle;"><?= $tot_plan[$x] ?></td>
                              <?php
                              }
                              ?>
                              <th align="center" style="color: green;font-weight: bolder;font-style: italic; font-size:20px; vertical-align: middle;"><?= $tot_plan_tot ?></th>
                            </tr>
                            <tr>
                              <td align="center" style="text-align: left; font-weight: bolder; vertical-align: middle;">Aktual</td>
                              <?php
                              for ($x = 1; $x <= 31; $x++) {
                              ?>
                                <td align="center" style="color:red; font-weight: bold; font-size:20px; vertical-align: middle;"><?= $tot_aktual_bln[$x] ?></td>
                              <?php } ?>
                              <th align="center" style="color: red;font-weight: bolder;font-style: italic; font-size:20px; vertical-align: middle;"><?= $tot_actoti ?></th>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    const toggleClassFn = (clickEvent) => {
      const buttonElement = clickEvent.currentTarget;
      document.getElementById("demo-table").classList.toggle(buttonElement.dataset.toggleClass);
      buttonElement.classList.toggle("is-info");
    };
    const toggleButtons = document.getElementsByClassName("toggle-button");
    for (let index = 1; index < toggleButtons.length; index += 1) {
      toggleButtons[index].addEventListener("click", toggleClassFn);
    };
  </script>
</body>
</html>